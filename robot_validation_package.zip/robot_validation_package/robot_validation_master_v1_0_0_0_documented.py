#!/usr/bin/env python3
from __future__ import annotations

"""
ROBOT VALIDATION MASTER
Version: 1.0.0.0
Python: 3.10+
Dependencies: Python standard library only.

USER INTENT
-----------
Run Programs 1, 2 and 3 sequentially from one robot-ID command, preserve each
phase's terminal interaction and process ownership, and produce one consolidated
report and one master JSON result.

USER DEMAND -> AI-CONVERTED NEED -> REQUIREMENTS
------------------------------------------------
USER DEMAND:
Enable the complete validation workflow to run once on a go instead of manually
starting three separate Python programs and locating three separate reports.

AI-CONVERTED NEED:
Create a master orchestrator that performs preflight checks, invokes each
interactive phase in sequence, reads structured JSON results, controls
progression, records blocked phases and opens only the final report.

REQUIREMENTS CREATED:
M-FRAME-001:
The master shall execute three independently owned Phase programs sequentially.

M-TERM-001:
Each Phase shall inherit the current terminal so keyboard, q and Y/N/U input
remain functional.

M-RESULT-001:
The master shall use Phase JSON as the authoritative robot-test result and shall
not infer PASS from process exit code zero.

M-REPORT-001:
The master shall initialise one report, allow all phases to append to it, add a
final summary and open it once at the end.

M-PREFLIGHT-001:
Before Phase 1, the master shall verify scripts, workspaces, Python and result
directory access.

M-PROGRESS-001:
PASS and REVIEW shall continue; FAIL, ERROR or BLOCKED shall stop dependent
phases unless --continue-on-fail is supplied.

M-BLOCK-001:
Every unexecuted dependent phase shall be represented as BLOCKED.

M-EXIT-001:
The master process exit code shall describe framework execution separately from
the overall robot-validation status.

TECHNICAL DECISION REGISTER
---------------------------
TD-M-001:
Keep all three Phase programs as independent executables and use the master only
as an orchestrator.

TD-M-002:
Execute phases sequentially because they share ROS, serial, hardware and display
resources.

TD-M-003:
Allow interactive phases to inherit the current terminal instead of capturing
stdout or stdin.

TD-M-004:
Use Phase JSON as the source of truth and treat process return code only as
checker-execution evidence.

TD-M-005:
Pass explicit robot ID, workspace, result JSON, result root and shared-report
paths to every Phase.

TD-M-006:
Open only the final master report to avoid interrupting the operator between
phases.

TD-M-007:
Stop dependent phases after FAIL, ERROR or BLOCKED by default.

TD-M-008:
Append explicit BLOCKED sections for phases that were not executed.

TD-M-009:
Record every command and transition in a master event log.

TD-M-010:
Keep Master execution status separate from overall robot status.

TD-M-011:
Use a registry of PhaseSpec objects so future script versions can be replaced
without rewriting orchestration logic.

TD-M-012:
Use only Python standard-library components for the same deployment simplicity
as the Phase programs.

KNOWN LIMITATIONS
-----------------
KL-M-001:
The master depends on each Phase producing a valid common-contract JSON file.

KL-M-002:
The master does not own ROS nodes launched inside a Phase and therefore does not
perform broad ROS cleanup; each Phase remains responsible for its own processes.

KL-M-003:
A user Ctrl+C may signal both master and active Phase because they intentionally
share the interactive foreground terminal.

IMPROVEMENT HISTORY
-------------------
[270726 1700]
REASON OF FAIL:
The operator had to start three programs manually, repeat the robot ID, locate
separate outputs and remember which phase should run next.

IMPROVEMENT:
Added one-command sequential execution, common JSON validation, progression
policy, blocked-phase reporting, final summary and one final report opening.
"""

import argparse
import json
import os
import shlex
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

PROGRAM_NAME = "robot_validation_master"
PROGRAM_VERSION = "1.0.0.0"

VALID_STATUSES = {"PASS", "FAIL", "REVIEW", "ERROR", "BLOCKED", "SKIPPED"}
DISPLAY_STATUS = {
    "PASS": "COMPLETED",
    "FAIL": "FAILED",
    "REVIEW": "REVIEW REQUIRED",
    "ERROR": "PROGRAM ERROR",
    "BLOCKED": "BLOCKED",
    "SKIPPED": "SKIPPED",
}


@dataclass
class PhaseSpec:
    number: int
    total: int
    name: str
    script: Path
    workspace: Path
    extra_args: list[str]
    no_open_flag: str


@dataclass
class PhaseExecution:
    phase_number: int
    phase_name: str
    status: str
    return_code: int
    started_at: str
    ended_at: str
    script: str
    result_json: str
    detail: str = ""
    executed: bool = True


def now_iso() -> str:
    """
    OBJECTIVE:
    Produce one timezone-aware timestamp because every master transition must be
    traceable.

    USER DEMAND:
    Keep the entire run in one reliable record.

    AI-CONVERTED NEED:
    Use one timestamp format for report, event log and JSON.

    REQUIREMENT CREATED:
    M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-009, TD-M-010.

    INPUTS:
    None.

    OUTPUTS:
    ISO-8601 local timestamp.

    WORKFLOW:
    IN => [system clock] -localise/format-> [timestamp] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added one shared timestamp helper.
    """
    return datetime.now().astimezone().isoformat(timespec="seconds")


def format_line(label: str, value: str, width: int = 48) -> str:
    """
    OBJECTIVE:
    Format report metadata and summary lines because the final note must remain
    readable across all robots.

    USER DEMAND:
    Use dotted lines in one note.

    AI-CONVERTED NEED:
    Centralise alignment.

    REQUIREMENT CREATED:
    M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-006.

    INPUTS:
    Label, value and width.

    OUTPUTS:
    Dotted report line.

    WORKFLOW:
    IN => [label, value] -dot-fill-> [report line] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added common final-summary formatting.
    """
    return f"{label:.<{width}} {value}"


def event(log_path: Path, message: str) -> None:
    """
    OBJECTIVE:
    Record one master event because phase transitions and failures must remain
    reconstructable independently of terminal history.

    USER DEMAND:
    Remember what the unified program did.

    AI-CONVERTED NEED:
    Append timestamped events immediately.

    REQUIREMENT CREATED:
    M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-009.

    INPUTS:
    Event-log path and message.

    OUTPUTS:
    None; appends one line.

    WORKFLOW:
    IN => [message] -timestamp/append-> [event log] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added a separate orchestration event trail.
    """
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(f"{now_iso()} {message}\n")


def build_registry(args: argparse.Namespace) -> list[PhaseSpec]:
    """
    OBJECTIVE:
    Build a replaceable Phase registry because script versions and workspace
    paths should change without rewriting orchestration control flow.

    USER DEMAND:
    Run the three existing programs in order.

    AI-CONVERTED NEED:
    Store phase identity, script, workspace and phase-specific arguments as data.

    REQUIREMENT CREATED:
    M-FRAME-001.

    TECHNICAL DECISIONS:
    TD-M-001, TD-M-005, TD-M-011.

    INPUTS:
    Parsed master arguments.

    OUTPUTS:
    Ordered list of three PhaseSpec objects.

    WORKFLOW:
    IN => [paths/options] -construct phase specs-> [ordered registry] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Phase versions are now CLI-overridable.
    """
    return [
        PhaseSpec(
            number=1,
            total=3,
            name="ROS CHECK",
            script=args.phase1_script.expanduser().resolve(),
            workspace=args.phase1_workspace.expanduser().resolve(),
            extra_args=["--run-functional"],
            no_open_flag="--no-open-report",
        ),
        PhaseSpec(
            number=2,
            total=3,
            name="ROBOT CONTROL / LIDAR CHECK",
            script=args.phase2_script.expanduser().resolve(),
            workspace=args.yahboom_workspace.expanduser().resolve(),
            extra_args=[],
            no_open_flag="--no-open-report",
        ),
        PhaseSpec(
            number=3,
            total=3,
            name="NAVIGATION STACK CHECK",
            script=args.phase3_script.expanduser().resolve(),
            workspace=args.yahboom_workspace.expanduser().resolve(),
            extra_args=[],
            no_open_flag="--no-open-report",
        ),
    ]


def preflight(
    phases: list[PhaseSpec],
    result_root: Path,
    dry_run: bool,
) -> list[str]:
    """
    OBJECTIVE:
    Detect missing scripts, workspaces or output access before Phase 1 because
    partial execution should not fail for preventable setup errors.

    USER DEMAND:
    Run all phases once on a go without discovering missing files halfway.

    AI-CONVERTED NEED:
    Validate executable inputs and writable output location before orchestration.

    REQUIREMENT CREATED:
    M-PREFLIGHT-001.

    TECHNICAL DECISIONS:
    TD-M-005, TD-M-009.

    INPUTS:
    Phase registry, result root and dry-run flag.

    OUTPUTS:
    List of error strings; empty means preflight passed.

    WORKFLOW:
    IN => [registry/output] -check Python/scripts/workspaces/write access-> [errors] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added all-or-nothing preflight before real hardware execution.
    """
    errors: list[str] = []
    if not Path(sys.executable).exists():
        errors.append(f"Python executable not found: {sys.executable}")

    for phase in phases:
        if not phase.script.is_file():
            errors.append(f"Phase {phase.number} script missing: {phase.script}")
        if not dry_run and not phase.workspace.is_dir():
            errors.append(
                f"Phase {phase.number} workspace missing: {phase.workspace}"
            )

    try:
        result_root.mkdir(parents=True, exist_ok=True)
        probe = result_root / ".master_write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
    except OSError as exc:
        errors.append(f"Result root is not writable: {result_root}: {exc}")

    return errors


def initialise_report(
    report_path: Path,
    robot_id: str,
    phases: list[PhaseSpec],
    started_at: str,
) -> None:
    """
    OBJECTIVE:
    Initialise one canonical report before any phase because all later phase
    sections must append to the same execution record.

    USER DEMAND:
    Log all phases in the same note.

    AI-CONVERTED NEED:
    Write master metadata and selected phase versions before Phase 1 starts.

    REQUIREMENT CREATED:
    M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-005, TD-M-006.

    INPUTS:
    Report path, robot ID, phase registry and start time.

    OUTPUTS:
    None; creates/overwrites the master report.

    WORKFLOW:
    IN => [run metadata] -format/write header-> [master report] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added one report header identifying every selected script.
    """
    lines = [
        "ROBOT VALIDATION MASTER REPORT",
        "=" * 72,
        "",
        format_line("ROBOT ID", robot_id),
        format_line("MASTER VERSION", PROGRAM_VERSION),
        format_line("STARTED AT", started_at),
        "",
    ]
    for phase in phases:
        lines.append(
            format_line(
                f"PHASE {phase.number} SCRIPT",
                phase.script.name,
            )
        )
        lines.append(
            format_line(
                f"PHASE {phase.number} WORKSPACE",
                str(phase.workspace),
            )
        )
    lines.extend(["", "=" * 72, ""])
    report_path.write_text("\n".join(lines), encoding="utf-8")


def build_command(
    spec: PhaseSpec,
    robot_id: str,
    run_dir: Path,
    report_path: Path,
    dry_run: bool,
) -> tuple[list[str], Path]:
    """
    OBJECTIVE:
    Build one explicit Phase command because every phase must receive consistent
    robot, workspace and output paths.

    USER DEMAND:
    Enter the robot ID once and let the unified program pass it everywhere.

    AI-CONVERTED NEED:
    Construct a list-form subprocess command without shell re-parsing.

    REQUIREMENT CREATED:
    M-FRAME-001, M-TERM-001.

    TECHNICAL DECISIONS:
    TD-M-003, TD-M-005.

    INPUTS:
    PhaseSpec, robot ID, master run directory, shared report and dry-run flag.

    OUTPUTS:
    Command argument list and expected Phase result JSON path.

    WORKFLOW:
    IN => [phase configuration] -add common/phase args-> [command, JSON path] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    All paths are explicit and traceable.
    """
    result_json = run_dir / f"phase{spec.number}_result.json"
    phase_result_root = run_dir / "phase_runs"
    command = [
        sys.executable,
        str(spec.script),
        robot_id,
        "--workspace",
        str(spec.workspace),
        "--result-root",
        str(phase_result_root),
        "--result-json",
        str(result_json),
        "--append-report",
        str(report_path),
        spec.no_open_flag,
    ]
    command.extend(spec.extra_args)
    if dry_run:
        command.append("--dry-run")
    return command, result_json


def validate_phase_json(
    data: dict[str, Any],
    spec: PhaseSpec,
    robot_id: str,
) -> str:
    """
    OBJECTIVE:
    Validate one Phase JSON before trusting it because a stale or malformed file
    must not control master progression.

    USER DEMAND:
    Make the unified result reliable.

    AI-CONVERTED NEED:
    Confirm identity, robot ID and allowed status.

    REQUIREMENT CREATED:
    M-RESULT-001.

    TECHNICAL DECISIONS:
    TD-M-004.

    INPUTS:
    Parsed JSON dictionary, PhaseSpec and expected robot ID.

    OUTPUTS:
    Validated status string.

    WORKFLOW:
    IN => [phase JSON] -validate fields/identity/status-> [status or exception] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Rejects stale or cross-robot phase artifacts.
    """
    if data.get("phase_number") != spec.number:
        raise ValueError(
            f"Expected phase_number {spec.number}, got {data.get('phase_number')}"
        )
    if data.get("robot_id") != robot_id:
        raise ValueError(
            f"Expected robot_id {robot_id}, got {data.get('robot_id')}"
        )
    status = str(data.get("status", ""))
    if status not in VALID_STATUSES:
        raise ValueError(f"Invalid phase status: {status!r}")
    return status


def execute_phase(
    spec: PhaseSpec,
    robot_id: str,
    run_dir: Path,
    report_path: Path,
    event_log: Path,
    dry_run: bool,
) -> PhaseExecution:
    """
    OBJECTIVE:
    Execute one interactive Phase transaction because terminal ownership,
    execution return code and robot-test status must be handled separately.

    USER DEMAND:
    Run each program automatically while preserving keyboard and Y/N/U input.

    AI-CONVERTED NEED:
    Inherit the current terminal, wait for completion, load JSON and return a
    validated PhaseExecution.

    REQUIREMENT CREATED:
    M-FRAME-001, M-TERM-001, M-RESULT-001, M-EXIT-001.

    TECHNICAL DECISIONS:
    TD-M-002, TD-M-003, TD-M-004, TD-M-009, TD-M-010.

    INPUTS:
    PhaseSpec, robot ID, master paths and dry-run mode.

    OUTPUTS:
    PhaseExecution.

    WORKFLOW:
    IN => [phase spec] -build/log command-> [interactive subprocess]
       -wait/read/validate JSON-> [PhaseExecution] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Terminal is inherited; no capture_output is used.
    """
    command, result_json = build_command(
        spec,
        robot_id,
        run_dir,
        report_path,
        dry_run,
    )
    started_at = now_iso()
    command_text = shlex.join(command)
    event(event_log, f"PHASE_{spec.number}_START command={command_text}")

    print("\n" + "=" * 72)
    print(f"STARTING PHASE {spec.number}/{spec.total}: {spec.name}")
    print("=" * 72)
    print(command_text)
    print()

    try:
        completed = subprocess.run(command, check=False)
        return_code = completed.returncode
    except KeyboardInterrupt:
        event(event_log, f"PHASE_{spec.number}_MASTER_INTERRUPTED")
        return PhaseExecution(
            phase_number=spec.number,
            phase_name=spec.name,
            status="ERROR",
            return_code=130,
            started_at=started_at,
            ended_at=now_iso(),
            script=str(spec.script),
            result_json=str(result_json),
            detail="Master interrupted while the Phase owned the terminal",
        )
    except OSError as exc:
        event(event_log, f"PHASE_{spec.number}_EXEC_ERROR detail={exc}")
        return PhaseExecution(
            phase_number=spec.number,
            phase_name=spec.name,
            status="ERROR",
            return_code=1,
            started_at=started_at,
            ended_at=now_iso(),
            script=str(spec.script),
            result_json=str(result_json),
            detail=f"Unable to execute phase: {exc}",
        )

    if return_code != 0:
        detail = f"Phase checker exited with code {return_code}"
        event(event_log, f"PHASE_{spec.number}_NONZERO {detail}")
        return PhaseExecution(
            phase_number=spec.number,
            phase_name=spec.name,
            status="ERROR",
            return_code=return_code,
            started_at=started_at,
            ended_at=now_iso(),
            script=str(spec.script),
            result_json=str(result_json),
            detail=detail,
        )

    if not result_json.is_file():
        detail = "Phase completed without producing the required result JSON"
        event(event_log, f"PHASE_{spec.number}_MISSING_JSON")
        return PhaseExecution(
            phase_number=spec.number,
            phase_name=spec.name,
            status="ERROR",
            return_code=return_code,
            started_at=started_at,
            ended_at=now_iso(),
            script=str(spec.script),
            result_json=str(result_json),
            detail=detail,
        )

    try:
        data = json.loads(result_json.read_text(encoding="utf-8"))
        status = validate_phase_json(data, spec, robot_id)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        detail = f"Invalid Phase result JSON: {exc}"
        event(event_log, f"PHASE_{spec.number}_INVALID_JSON detail={exc}")
        return PhaseExecution(
            phase_number=spec.number,
            phase_name=spec.name,
            status="ERROR",
            return_code=return_code,
            started_at=started_at,
            ended_at=now_iso(),
            script=str(spec.script),
            result_json=str(result_json),
            detail=detail,
        )

    ended_at = now_iso()
    event(event_log, f"PHASE_{spec.number}_END status={status}")
    return PhaseExecution(
        phase_number=spec.number,
        phase_name=spec.name,
        status=status,
        return_code=return_code,
        started_at=started_at,
        ended_at=ended_at,
        script=str(spec.script),
        result_json=str(result_json),
        detail="Phase checker completed and JSON was validated",
    )


def append_blocked_phase(
    report_path: Path,
    spec: PhaseSpec,
    reason: str,
) -> PhaseExecution:
    """
    OBJECTIVE:
    Represent an unexecuted phase explicitly because a dependent phase must not
    disappear silently from the final report.

    USER DEMAND:
    Show all Phase 1/2/3 sections even when one cannot run.

    AI-CONVERTED NEED:
    Append a standard BLOCKED section and return a non-executed PhaseExecution.

    REQUIREMENT CREATED:
    M-BLOCK-001.

    TECHNICAL DECISIONS:
    TD-M-007, TD-M-008.

    INPUTS:
    Master report, PhaseSpec and blocking reason.

    OUTPUTS:
    BLOCKED PhaseExecution.

    WORKFLOW:
    IN => [phase, reason] -format/append-> [blocked section/execution] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Prevents ambiguous omission.
    """
    text = "\n".join(
        [
            "",
            "",
            f"[PHASE {spec.number}/{spec.total}: {spec.name}]",
            "",
            format_line(spec.name, "BLOCKED"),
            format_line("REASON", reason),
            "",
            f"PHASE {spec.number}: BLOCKED",
            "",
            f"(END OF PHASE {spec.number})",
            "",
        ]
    )
    with report_path.open("a", encoding="utf-8") as handle:
        handle.write(text)
    timestamp = now_iso()
    return PhaseExecution(
        phase_number=spec.number,
        phase_name=spec.name,
        status="BLOCKED",
        return_code=0,
        started_at=timestamp,
        ended_at=timestamp,
        script=str(spec.script),
        result_json="",
        detail=reason,
        executed=False,
    )


def calculate_overall_status(executions: list[PhaseExecution]) -> str:
    """
    OBJECTIVE:
    Derive one overall robot-validation status because the final report and
    future fleet summary require a single outcome.

    USER DEMAND:
    See one final result after all three phases.

    AI-CONVERTED NEED:
    Apply deterministic precedence across phase statuses.

    REQUIREMENT CREATED:
    M-RESULT-001.

    TECHNICAL DECISIONS:
    TD-M-004, TD-M-010.

    INPUTS:
    PhaseExecution list.

    OUTPUTS:
    Overall status string.

    WORKFLOW:
    IN => [phase statuses] -apply precedence-> [overall status] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Uses ERROR > FAIL > BLOCKED > REVIEW > SKIPPED > PASS.
    """
    statuses = {execution.status for execution in executions}
    for candidate in ("ERROR", "FAIL", "BLOCKED", "REVIEW"):
        if candidate in statuses:
            return candidate
    if statuses and statuses == {"SKIPPED"}:
        return "SKIPPED"
    return "PASS"


def append_final_summary(
    report_path: Path,
    executions: list[PhaseExecution],
    overall_status: str,
    ended_at: str,
    master_json: Path,
) -> None:
    """
    OBJECTIVE:
    Add one final summary because the operator should not search through raw
    phase evidence to determine the complete result.

    USER DEMAND:
    Finish the same note with Phase 1/2/3 and overall status.

    AI-CONVERTED NEED:
    Render each phase status and final metadata after orchestration completes.

    REQUIREMENT CREATED:
    M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-006, TD-M-010.

    INPUTS:
    Report path, executions, overall status, end time and master JSON path.

    OUTPUTS:
    None; appends final summary.

    WORKFLOW:
    IN => [executions/metadata] -format/append-> [final summary] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added one readable end-of-run decision surface.
    """
    lines = [
        "",
        "",
        "=" * 72,
        "FINAL SUMMARY",
        "=" * 72,
        "",
    ]
    for execution in executions:
        lines.append(
            format_line(
                f"PHASE {execution.phase_number} — {execution.phase_name}",
                DISPLAY_STATUS.get(execution.status, execution.status),
            )
        )
    lines.extend(
        [
            "",
            format_line(
                "OVERALL RESULT",
                {
                    "PASS": "SUCCESS",
                    "FAIL": "FAILED",
                    "REVIEW": "REVIEW REQUIRED",
                    "ERROR": "PROGRAM ERROR",
                    "BLOCKED": "BLOCKED",
                    "SKIPPED": "SKIPPED",
                }[overall_status],
            ),
            format_line("ENDED AT", ended_at),
            format_line("MASTER RESULT JSON", str(master_json)),
            "",
        ]
    )
    with report_path.open("a", encoding="utf-8") as handle:
        handle.write("\n".join(lines))


def write_master_json(
    path: Path,
    robot_id: str,
    started_at: str,
    ended_at: str,
    overall_status: str,
    report_path: Path,
    event_log: Path,
    executions: list[PhaseExecution],
) -> None:
    """
    OBJECTIVE:
    Write a machine-readable master result because multiple robots can later be
    summarised without parsing the human report.

    USER DEMAND:
    Finish all robots, then focus on the next task.

    AI-CONVERTED NEED:
    Preserve one compact result per robot for later fleet-level aggregation.

    REQUIREMENT CREATED:
    M-RESULT-001, M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-004, TD-M-009, TD-M-010.

    INPUTS:
    Master metadata and PhaseExecution list.

    OUTPUTS:
    None; writes JSON.

    WORKFLOW:
    IN => [master/phase results] -serialise-> [master JSON] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Enables future R21/R22/R23 summary generation.
    """
    payload = {
        "program": PROGRAM_NAME,
        "version": PROGRAM_VERSION,
        "robot_id": robot_id,
        "started_at": started_at,
        "ended_at": ended_at,
        "overall_status": overall_status,
        "master_report": str(report_path),
        "event_log": str(event_log),
        "phases": [asdict(execution) for execution in executions],
    }
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def open_report(path: Path) -> None:
    """
    OBJECTIVE:
    Open only the final master report because phase-level windows would interrupt
    the one-go workflow.

    USER DEMAND:
    Complete everything once and review the unified result.

    AI-CONVERTED NEED:
    Launch xdg-open after final summary only.

    REQUIREMENT CREATED:
    M-REPORT-001.

    TECHNICAL DECISIONS:
    TD-M-006.

    INPUTS:
    Final report path.

    OUTPUTS:
    None.

    WORKFLOW:
    IN => [report path] -xdg-open in new session-> [viewer] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Prevents four separate report windows.
    """
    try:
        subprocess.Popen(
            ["xdg-open", str(path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        print(f"Unable to open final report: {exc}", file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    """
    OBJECTIVE:
    Define the one-command interface because the operator should enter the robot
    ID once while retaining explicit path overrides.

    USER DEMAND:
    Run all three programs once on a go.

    AI-CONVERTED NEED:
    Expose script versions, workspaces, result root, dry run and progression
    policy without requiring code edits.

    REQUIREMENT CREATED:
    M-FRAME-001, M-PROGRESS-001.

    TECHNICAL DECISIONS:
    TD-M-005, TD-M-011.

    INPUTS:
    None.

    OUTPUTS:
    Configured ArgumentParser.

    WORKFLOW:
    IN => [master interface requirements] -declare defaults/options-> [parser] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Defaults resolve scripts relative to the master file directory.
    """
    tool_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(
        description="Run Phase 1, Phase 2 and Phase 3 as one robot-validation workflow."
    )
    parser.add_argument("robot_id", help="Robot number, for example R23")
    parser.add_argument(
        "--phase1-script",
        type=Path,
        default=tool_dir / "phase1_ros_quickcheck_v1_2_0_0_documented.py",
    )
    parser.add_argument(
        "--phase2-script",
        type=Path,
        default=tool_dir / "phase2_robot_ctrl_lidar_v1_1_0_1_documented.py",
    )
    parser.add_argument(
        "--phase3-script",
        type=Path,
        default=tool_dir / "phase3_navigation_stack_v1_0_0_0_documented.py",
    )
    parser.add_argument(
        "--phase1-workspace",
        type=Path,
        default=Path.home() / "ros2_ws",
    )
    parser.add_argument(
        "--yahboom-workspace",
        type=Path,
        default=Path.home() / "yahboomcar_ws",
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path.home() / "robot_check_results",
    )
    parser.add_argument("--continue-on-fail", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-open-report", action="store_true")
    return parser


def main() -> int:
    """
    OBJECTIVE:
    Execute the complete one-command validation workflow because the operator
    should focus on required hardware observations rather than phase management.

    USER DEMAND:
    Run all three programs once on a go.

    AI-CONVERTED NEED:
    Preflight, initialise artifacts, execute phases sequentially, apply
    progression policy, write blocked phases, summarise and open one report.

    REQUIREMENT CREATED:
    M-FRAME-001, M-TERM-001, M-RESULT-001, M-REPORT-001,
    M-PREFLIGHT-001, M-PROGRESS-001, M-BLOCK-001, M-EXIT-001.

    TECHNICAL DECISIONS:
    TD-M-001 through TD-M-012.

    INPUTS:
    Master command-line arguments.

    OUTPUTS:
    0 when master orchestration completes, 1 for framework/preflight error and
    130 for direct master interruption.

    WORKFLOW:
    IN => [robot ID/configuration] -preflight/header-> [phase registry]
       -execute/validate/progress-> [phase executions]
       -summary/JSON/open-> [master exit code] => OUTPUT

    IMPROVEMENTS MADE:
    Initial masterpiece implementation.

    REASON OF FAIL:
    Three independent manual launches prevented a single traceable workflow.

    IMPROVEMENT:
    Added one-command orchestration and one final result.
    """
    args = build_parser().parse_args()
    started_at = now_iso()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    result_root = args.result_root.expanduser().resolve()
    run_dir = result_root / args.robot_id / f"{timestamp}_master"
    run_dir.mkdir(parents=True, exist_ok=True)

    report_path = run_dir / "master_report.txt"
    master_json = run_dir / "master_result.json"
    event_log = run_dir / "master_event.log"

    phases = build_registry(args)
    errors = preflight(phases, result_root, args.dry_run)

    initialise_report(report_path, args.robot_id, phases, started_at)
    event(event_log, f"MASTER_START robot={args.robot_id}")

    if errors:
        with report_path.open("a", encoding="utf-8") as handle:
            handle.write("\nMASTER PREFLIGHT FAILED\n")
            for error in errors:
                handle.write(f"- {error}\n")
        event(event_log, f"PREFLIGHT_FAIL count={len(errors)}")
        print("Master preflight failed:")
        for error in errors:
            print(f"- {error}")
        if not args.no_open_report:
            open_report(report_path)
        return 1

    print(f"\n{PROGRAM_NAME} v{PROGRAM_VERSION}")
    print(f"Robot: {args.robot_id}")
    print(f"Master run directory: {run_dir}")
    print("All phases will use the current interactive terminal.\n")

    executions: list[PhaseExecution] = []
    framework_error = False
    stop_reason = ""

    for index, spec in enumerate(phases):
        execution = execute_phase(
            spec,
            args.robot_id,
            run_dir,
            report_path,
            event_log,
            args.dry_run,
        )
        executions.append(execution)

        if execution.status == "ERROR":
            framework_error = True

        should_stop = (
            execution.status in {"FAIL", "ERROR", "BLOCKED"}
            and not args.continue_on_fail
        )
        if should_stop:
            stop_reason = (
                f"Blocked because Phase {spec.number} ended with "
                f"{execution.status}: {execution.detail}"
            )
            event(event_log, f"MASTER_STOP_AFTER_PHASE_{spec.number} reason={stop_reason}")
            for remaining in phases[index + 1 :]:
                blocked_execution = append_blocked_phase(
                    report_path,
                    remaining,
                    stop_reason,
                )
                executions.append(blocked_execution)
                event(
                    event_log,
                    f"PHASE_{remaining.number}_BLOCKED reason={stop_reason}",
                )
            break

    # Defensive completion in case the loop ended without appending all phases.
    existing_numbers = {execution.phase_number for execution in executions}
    for spec in phases:
        if spec.number not in existing_numbers:
            reason = stop_reason or "Phase was not reached"
            executions.append(append_blocked_phase(report_path, spec, reason))

    executions.sort(key=lambda item: item.phase_number)
    overall_status = calculate_overall_status(executions)
    ended_at = now_iso()

    write_master_json(
        master_json,
        args.robot_id,
        started_at,
        ended_at,
        overall_status,
        report_path,
        event_log,
        executions,
    )
    append_final_summary(
        report_path,
        executions,
        overall_status,
        ended_at,
        master_json,
    )
    event(event_log, f"MASTER_END overall_status={overall_status}")

    print("\n" + "=" * 72)
    print("FINAL SUMMARY")
    print("=" * 72)
    for execution in executions:
        print(
            format_line(
                f"PHASE {execution.phase_number} — {execution.phase_name}",
                DISPLAY_STATUS.get(execution.status, execution.status),
            )
        )
    print(format_line("OVERALL RESULT", overall_status))
    print(f"Master report: {report_path}")
    print(f"Master JSON: {master_json}")

    if not args.no_open_report:
        open_report(report_path)

    return 1 if framework_error else 0


if __name__ == "__main__":
    raise SystemExit(main())
