# Known Limitations

1. Prototype maturity
   - Operator-assisted validation prototype, not a certified automated test system.

2. Test-case granularity
   - Individual checks remain grouped inside three larger phase programs.
   - Not every check can be invoked as an independent executable test case.

3. Human test oracle
   - Several physical/visual checks require Y/N/U judgement.
   - A running ROS process does not prove correct hardware behaviour.

4. Environment coupling
   - Depends on the current workspace structure, ROS packages, launch commands, device aliases, and expected command behaviour.

5. LiDAR alias inconsistency
   - Phase 2 default `--lidar-port` is `/dev/ydlidar`.
   - Phase 2 also inspects `/dev/rplidar` in some logic.
   - Phase 3 inspects `/dev/rplidar`.

6. USB / hardware faults
   - Missing-device evidence cannot by itself distinguish cable, hub, power, udev, driver, or hardware failure.

7. Repeatability
   - The workflow has not been exhaustively validated across every robot and failure mode.
   - Repeat testing on known-good and known-faulty robots is recommended.

8. Process-output assumptions
   - Some readiness/error detection depends on current command/output behaviour and may require updates if packages change.

9. Safe use
   - Motor/navigation checks involve physical movement. Maintain a safe test area and operator control.
