#!/usr/bin/env python3
"""
Phase 2 — Yahboom Robot Control and LiDAR Check

Version: 1.1.0.1
Python: 3.10+
Dependencies: Python standard library only.

USER INTENT
Automate the repetitive setup, execution and evidence logging of the motor and
LiDAR checks while preserving q-controlled completion, Y/N/U human judgement,
minimum concurrently active processes, and one-hardware-stage-at-a-time
execution.

PROGRAM OBJECTIVE
Orchestrate the USB, workspace, motor and LiDAR checks in a repeatable sequence
because initial hardware validation must be faster without pretending that
software output alone proves physical correctness.

DEMAND-TO-REQUIREMENT TRANSFORMATION
User demands:
- Check the expected USB serial structure before operating hardware.
- Start the motor driver and keyboard controller, then continue only after q.
- During the motor stage, record the ROS topic list and collect /voltage data for
  30 seconds while the operator performs the keyboard test.
- Treat approximately 11 to 12 volts as PASS and preserve other values as REVIEW.
- Ask the operator for Y/N/U instead of automatically judging motor behaviour.
- Close the motor stage before operating the LiDAR stage.
- Recheck the serial mappings and detect remaining serial users before LiDAR starts.
- Start the LiDAR driver first and RViz second, then continue only after q.
- Ask the operator for Y/N/U instead of automatically judging the LiDAR view.
- Use no third-party Python library.
- Return a structured result that a future three-phase master program can append
  to one consolidated note.

AI-converted engineering need:
Create a standard-library-only, sequential, human-in-the-loop orchestrator that
owns its child processes, records evidence, prevents invalid phase transitions,
and exposes a stable result contract to the master framework.

Requirements created:
- P2-SYS-001: The program shall use Python standard-library modules only.
- P2-SEQ-001: Motor resources shall be cleaned up before LiDAR resources start.
- P2-PROC-001: The checker shall terminate only processes that it started.
- P2-PROC-002: Owned processes shall be stopped by SIGINT, then SIGTERM, then
  SIGKILL only when gentler shutdown fails.
- P2-USB-001: /dev/myserial and /dev/rplidar shall resolve to ttyUSB character
  devices; metadata differences shall remain reviewable rather than hidden.
- P2-BUILD-001: The Yahboom workspace shall be built before dependent tests,
  unless the operator explicitly uses --skip-build.
- P2-MOTOR-001: The motor driver shall start before the keyboard controller.
- P2-TOPIC-001: While the motor driver is active, the checker shall record the
  ROS topic list and compare it with the expected Yahboom topic set.
- P2-VOLT-001: While the motor driver remains active, the checker shall wait
  until /voltage is discoverable and its message type can be resolved before
  collecting 30 seconds of evidence; samples within 11.0 to 12.0 shall PASS and
  unavailable, missing, zero or out-of-range samples shall remain REVIEW.
- P2-SERIAL-001: After motor cleanup and before LiDAR launch, the checker shall
  revalidate the launch port and detect processes still using relevant serial
  devices without killing processes it does not own.
- P2-HIL-001: q shall mean only that the operator has finished an operation or
  observation; q shall not itself mean PASS.
- P2-HIL-002: Y/N/U shall map to PASS/FAIL/REVIEW for physical judgement.
- P2-LIDAR-001: The LiDAR driver shall start before RViz.
- P2-BLOCK-001: A dependent test shall be BLOCKED when its prerequisite fails.
- P2-RESULT-001: Every check shall return status, detail, evidence and optional
  human input through a common CheckResult structure.
- P2-RESULT-002: The phase shall produce both JSON and a human-readable report.
- P2-FRAME-001: The phase shall accept result paths supplied by a master program.
- P2-TIME-001: Elapsed-time decisions shall use a monotonic clock.
- P2-CLI-001: Vendor commands and timeouts shall remain configurable by CLI.

TECHNICAL DECISION REGISTER
- TD-P2-001: Use Python standard-library components only to minimise deployment
  friction across Jetson systems.
- TD-P2-002: Implement Phase 2 as a sequential orchestrator because Motor and
  LiDAR stages share hardware, ROS and display resources.
- TD-P2-003: Stop every process owned by the current stage before starting the
  next stage to prevent resource conflicts and ambiguous evidence.
- TD-P2-004: Use subprocess.run() for commands expected to terminate and
  subprocess.Popen() through ManagedProcess for long-running ROS processes.
- TD-P2-005: Run the keyboard controller in the current real terminal so direct
  key input and q-based exit work without a third-party pseudo-terminal library.
- TD-P2-006: Treat q only as an operator-completion signal and Y/N/U as the
  actual PASS/FAIL/REVIEW judgement.
- TD-P2-007: Reserve Motor and LiDAR physical-function judgement for the human
  operator because process survival cannot prove physical behaviour.
- TD-P2-008: Inspect symbolic links and character-device metadata directly
  instead of parsing ls output because filesystem objects are more stable.
- TD-P2-009: Read long-running process output in a background thread so logging
  cannot block the main orchestration flow.
- TD-P2-010: Create a new process session for every owned background process so
  cleanup can target its process group without killing unrelated ROS nodes.
- TD-P2-011: Escalate cleanup from SIGINT to SIGTERM and finally SIGKILL so
  normal ROS shutdown is attempted before forced termination.
- TD-P2-012: Use readiness/error text only as limited software evidence and
  preserve REVIEW or human judgement where text cannot establish reality.
- TD-P2-013: Use time.monotonic() for elapsed-time and timeout decisions because
  wall-clock changes must not affect process-control behaviour.
- TD-P2-014: Represent every check as CheckResult so all three phases can share
  one result vocabulary.
- TD-P2-015: Separate checker exit codes from test outcomes so process execution
  and robot validation are not conflated.
- TD-P2-016: Write machine-readable JSON and a human-readable phase report so a
  single run supports automation, inspection and traceability.
- TD-P2-017: Allow the phase report to append to a shared note so Phase 1, 2 and
  3 can form one consolidated robot-validation record.
- TD-P2-018: Block dependent checks when prerequisites fail rather than running
  a hardware test under invalid conditions.
- TD-P2-019: Terminate only checker-owned processes because this program has no
  authority over manually launched or unrelated nodes.
- TD-P2-020: Keep vendor commands configurable so corrections do not require
  rewriting orchestration logic.
- TD-P2-021: Wait for the /voltage topic and message type before starting
  capture, then overlap the 30-second recording with topic inspection and the
  real keyboard-controlled motor-operation interval.
- TD-P2-022: Judge the topic list against an explicit configurable expected set
  because a raw list is useful evidence but cannot by itself state completeness.
- TD-P2-023: Parse numeric values only from ROS "data:" lines and keep any zero,
  missing or out-of-range voltage result as REVIEW rather than fabricating FAIL.
- TD-P2-024: Scan /proc file descriptors to detect serial-device users using
  Python standard-library facilities and avoid adding fuser/lsof dependencies.
- TD-P2-025: Never terminate an externally owned serial user; block LiDAR when
  its launch device remains occupied and report the conflict for human action.
- TD-P2-026: Treat serial-port readiness and ROS-interface readiness as separate
  states because "Rosmaster Serial Opened" does not prove that /voltage has
  already appeared in the ROS graph.

KNOWN LIMITATIONS
- The interactive keyboard screen is displayed directly and only session
  metadata is logged; the complete terminal screen is not captured.
- A running LiDAR process or RViz window is not proof of valid scan geometry;
  final physical/visual judgement remains Y/N/U.
- Readiness and error detection depend partly on vendor output text and must be
  revised when real evidence exposes a false result.
- The default LiDAR port and launch commands must be verified on the actual
  Yahboom image before being treated as final.
- The expected topic set is based on the supplied Yahboom example; additional
  valid topics do not fail the check, while missing expected topics cause REVIEW.
- Voltage acceptance uses the supplied approximate 11-to-12 range and does not
  yet compensate for sensor calibration, battery load or transient sag.
- Topic readiness is established through ROS CLI discovery and message-type
  resolution; it remains software-interface evidence rather than battery proof.

IMPROVEMENTS MADE
[270726 1347]
REASON OF FAIL:
N/A — this is a documentation and traceability revision made before verified
Program 2 hardware execution.

IMPROVEMENT:
Added user-intent traceability, requirement and technical-decision registers,
section motives, per-function contracts, known limitations and an evidence-led
improvement-history format.

[270726 1501]
REASON OF FAIL:
Program 2 v1.0.0.1 did not cover the updated motor-stage topic-list recording,
30-second voltage check, or the required pre-LiDAR serial-session recheck.

IMPROVEMENT:
Added concurrent topic/voltage diagnostics, explicit 11-to-12 voltage review
logic, post-motor serial mapping validation, lock detection and traceable logs.

[270726 1515]
REASON OF FAIL:
The voltage recorder started immediately after serial-port readiness, before
/voltage and its message type became discoverable; ros2 topic echo therefore
exited after about three seconds instead of collecting the intended 30 seconds.

IMPROVEMENT:
Added a bounded /voltage readiness gate while the motor driver remains active;
the checker now confirms topic discovery and message-type resolution before
starting the 30-second recorder, and reports REVIEW when readiness is absent.

The program only terminates processes that it started itself.
"""
from __future__ import annotations

import argparse
import grp
import json
import os
import pwd
import re
import shlex
import signal
import stat
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional, TextIO


PROGRAM_NAME = "phase2_robot_ctrl_lidar"
PROGRAM_VERSION = "1.1.0.1"
PHASE_NUMBER = 2
PHASE_TOTAL = 3
PHASE_NAME = "ROBOT CONTROL / LIDAR CHECK"

GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
RESET = "\033[0m"

DEFAULT_EXPECTED_MOTOR_TOPICS = (
    "/Buzzer",
    "/RGBLight",
    "/cmd_vel",
    "/edition",
    "/imu/data_raw",
    "/imu/mag",
    "/joint_states",
    "/parameter_events",
    "/rosout",
    "/vel_raw",
    "/voltage",
)


# -----------------------------------------------------------------------------
# SECTION: STATUS AND RESULT CONTRACT
# TECHNICAL DECISION: Use typed shared statuses and dataclasses so Phase 2 can
# report consistently to both the operator and the future three-phase master.
# -----------------------------------------------------------------------------
class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    REVIEW = "REVIEW"
    ERROR = "ERROR"
    SKIPPED = "SKIPPED"
    BLOCKED = "BLOCKED"


DISPLAY_STATUS = {
    Status.PASS: "SUCCESS",
    Status.FAIL: "FAILED",
    Status.REVIEW: "REVIEW REQUIRED",
    Status.ERROR: "PROGRAM ERROR",
    Status.SKIPPED: "SKIPPED",
    Status.BLOCKED: "BLOCKED",
}


@dataclass
class CheckResult:
    check_id: str
    label: str
    status: Status
    detail: str = ""
    evidence: str = ""
    human_input: str = ""


@dataclass
class PhaseResult:
    program: str
    version: str
    phase_number: int
    phase_total: int
    phase_name: str
    robot_id: str
    started_at: str
    ended_at: str
    status: Status
    checks: list[CheckResult] = field(default_factory=list)
    evidence_files: list[str] = field(default_factory=list)


def now_iso() -> str:
    """
    OBJECTIVE:
    Return a timezone-aware timestamp for evidence records because every check must be traceable to a real execution time.
    
    TRACEABILITY:
    USER DEMAND:
    Save the terminal data process and combine all phases into one note.
    
    AI-CONVERTED NEED:
    Every result and evidence record needs a consistent local timestamp.
    
    REQUIREMENT CREATED:
    P2-RESULT-002.
    
    TECHNICAL DECISIONS:
    TD-P2-016.
    
    INPUTS:
    None.
    
    OUTPUTS:
    A local ISO-8601 timestamp string with second precision.
    
    WORKFLOW:
    IN => [current local clock] -attach timezone/format-> [ISO timestamp] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Documented the evidence-time contract.
    """
    return datetime.now().astimezone().isoformat(timespec="seconds")


def safe_username(uid: int) -> str:
    """
    OBJECTIVE:
    Resolve a numeric user ID without allowing an unknown ID to abort USB inspection because metadata anomalies must remain reportable.
    
    TRACEABILITY:
    USER DEMAND:
    Check whether the USB result is structurally similar to root-owned device entries.
    
    AI-CONVERTED NEED:
    Device ownership must be converted into readable evidence with a safe fallback.
    
    REQUIREMENT CREATED:
    P2-USB-001.
    
    TECHNICAL DECISIONS:
    TD-P2-008, TD-P2-012.
    
    INPUTS:
    uid: Numeric Unix user ID obtained from file metadata.
    
    OUTPUTS:
    Username string, or the numeric ID as text when no account mapping exists.
    
    WORKFLOW:
    IN => [uid] -query password database-> [name or missing mapping] -fallback-> [display string] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Added an explicit non-fatal fallback for unknown user IDs.
    """
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def safe_groupname(gid: int) -> str:
    """
    OBJECTIVE:
    Resolve a numeric group ID without allowing an unknown group to abort USB inspection because the expected dialout group is evidence, not a crash condition.
    
    TRACEABILITY:
    USER DEMAND:
    Check for the dialout group in the serial-device structure.
    
    AI-CONVERTED NEED:
    Group metadata must be readable and safely preserved even when the mapping is unusual.
    
    REQUIREMENT CREATED:
    P2-USB-001.
    
    TECHNICAL DECISIONS:
    TD-P2-008, TD-P2-012.
    
    INPUTS:
    gid: Numeric Unix group ID obtained from file metadata.
    
    OUTPUTS:
    Group-name string, or the numeric ID as text when no group mapping exists.
    
    WORKFLOW:
    IN => [gid] -query group database-> [name or missing mapping] -fallback-> [display string] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Added an explicit non-fatal fallback for unknown group IDs.
    """
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return str(gid)


def show(label: str, status: Status, detail: str = "") -> None:
    """
    OBJECTIVE:
    Display one check result consistently because the operator must distinguish PASS, FAIL, REVIEW and framework states during live work.
    
    TRACEABILITY:
    USER DEMAND:
    Print success in green, failure in red and uncertain results visibly.
    
    AI-CONVERTED NEED:
    All checks need one human-readable console vocabulary aligned with structured statuses.
    
    REQUIREMENT CREATED:
    P2-RESULT-001.
    
    TECHNICAL DECISIONS:
    TD-P2-014, TD-P2-016.
    
    INPUTS:
    label: Human-readable check name; status: Status value; detail: Optional evidence summary.
    
    OUTPUTS:
    None; writes a colour-coded result line to the current terminal.
    
    WORKFLOW:
    IN => [label/status/detail] -map status to colour-> [formatted line] -print-> [operator display] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Centralised live status rendering to avoid inconsistent phase messages.
    """
    colour = {
        Status.PASS: GREEN,
        Status.FAIL: RED,
        Status.REVIEW: YELLOW,
        Status.ERROR: RED,
        Status.SKIPPED: YELLOW,
        Status.BLOCKED: YELLOW,
    }.get(status, "")
    suffix = f" - {detail}" if detail else ""
    print(f"{colour}{label}: {status.value}{RESET}{suffix}")


def format_result_line(label: str, status: Status, width: int = 48) -> str:
    """
    OBJECTIVE:
    Create fixed-width dotted report lines because all three phases must share a readable note format.
    
    TRACEABILITY:
    USER DEMAND:
    Log all tests in the same note using TEST...SUCCESS formatting.
    
    AI-CONVERTED NEED:
    The master-facing report needs deterministic alignment independent of label length.
    
    REQUIREMENT CREATED:
    P2-RESULT-002, P2-FRAME-001.
    
    TECHNICAL DECISIONS:
    TD-P2-014, TD-P2-016, TD-P2-017.
    
    INPUTS:
    label: Report label; status: Structured status; width: Dot-fill width.
    
    OUTPUTS:
    A formatted report line such as 'MOTOR DRIVER.... SUCCESS'.
    
    WORKFLOW:
    IN => [label/status/width] -translate status/fill dots-> [report line] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Implemented the shared dotted-line phase-report format.
    """
    return f"{label:.<{width}} {DISPLAY_STATUS[status]}"


def calculate_phase_status(checks: list[CheckResult]) -> Status:
    """
    OBJECTIVE:
    Reduce individual check states to one phase state because the master program needs a single Phase 2 outcome without losing per-check evidence.
    
    TRACEABILITY:
    USER DEMAND:
    Mark each phase completed, failed or review-required in the consolidated note.
    
    AI-CONVERTED NEED:
    Define deterministic status precedence across PASS, FAIL, REVIEW, ERROR, BLOCKED and SKIPPED.
    
    REQUIREMENT CREATED:
    P2-RESULT-001, P2-RESULT-002.
    
    TECHNICAL DECISIONS:
    TD-P2-014, TD-P2-015, TD-P2-018.
    
    INPUTS:
    checks: Completed CheckResult objects for this phase.
    
    OUTPUTS:
    One aggregate Status using ERROR > FAIL > REVIEW > BLOCKED > PASS precedence, excluding SKIPPED where possible.
    
    WORKFLOW:
    IN => [check statuses] -remove skipped/collect set-> [precedence evaluation] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Documented aggregate-status precedence for future master integration.
    """
    statuses = {check.status for check in checks if check.status != Status.SKIPPED}
    if not statuses:
        return Status.SKIPPED
    if Status.ERROR in statuses:
        return Status.ERROR
    if Status.FAIL in statuses:
        return Status.FAIL
    if Status.REVIEW in statuses:
        return Status.REVIEW
    if Status.BLOCKED in statuses:
        return Status.BLOCKED
    return Status.PASS


# -----------------------------------------------------------------------------
# SECTION: FINITE COMMAND EXECUTION AND ROS ENVIRONMENT
# TECHNICAL DECISION: Recreate the ROS environment inside every child shell so
# one terminal's sourced state is never mistaken for another process's state.
# -----------------------------------------------------------------------------
def shell_command(workspace: Path, command: str) -> str:
    """
    OBJECTIVE:
    Construct one Bash command with ROS and workspace environments sourced because each child shell starts without the caller's sourced ROS state.
    
    TRACEABILITY:
    USER DEMAND:
    Source install/setup.bash before every ROS command.
    
    AI-CONVERTED NEED:
    Every subprocess must recreate the ROS environment instead of relying on another terminal's state.
    
    REQUIREMENT CREATED:
    P2-BUILD-001, P2-MOTOR-001, P2-LIDAR-001.
    
    TECHNICAL DECISIONS:
    TD-P2-004, TD-P2-020.
    
    INPUTS:
    workspace: Yahboom workspace; command: Command to run after environment setup.
    
    OUTPUTS:
    A Bash command joined with && so later actions run only after successful sourcing.
    
    WORKFLOW:
    IN => [workspace/command] -add ROS setup-> [optional workspace setup] -append command-> [Bash chain] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Made environment reconstruction explicit for every child process.
    """
    parts = ["source /opt/ros/humble/setup.bash"]
    setup = workspace / "install" / "setup.bash"
    if setup.exists():
        parts.append(f"source {shlex.quote(str(setup))}")
    parts.append(command)
    return " && ".join(parts)


def run_command(
    workspace: Path,
    command: str,
    timeout: int,
) -> tuple[int, str]:
    """
    OBJECTIVE:
    Run a finite command and capture its complete output because build and diagnostic steps must terminate and leave evidence.
    
    TRACEABILITY:
    USER DEMAND:
    Build the workspace, record the terminal data and proceed only when the step succeeds.
    
    AI-CONVERTED NEED:
    Finite commands need return-code, timeout and merged stdout/stderr handling.
    
    REQUIREMENT CREATED:
    P2-BUILD-001, P2-RESULT-002.
    
    TECHNICAL DECISIONS:
    TD-P2-004, TD-P2-016.
    
    INPUTS:
    workspace: Working directory and ROS environment source; command: Bash command; timeout: Maximum seconds.
    
    OUTPUTS:
    A tuple of return code and captured output; timeout is represented as return code 124.
    
    WORKFLOW:
    IN => [workspace/command/timeout] -source/run/wait-> [completed or timeout] -collect output-> [(code,text)] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Standardised finite-command execution and timeout evidence.
    """
    try:
        completed = subprocess.run(
            ["bash", "-lc", shell_command(workspace, command)],
            cwd=workspace,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        return completed.returncode, completed.stdout + completed.stderr
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        return 124, stdout + stderr


# -----------------------------------------------------------------------------
# SECTION: OWNED LONG-RUNNING PROCESS MANAGEMENT
# TECHNICAL DECISION: Encapsulate process ownership, output draining and staged
# cleanup because hardware nodes must remain observable without blocking flow.
# -----------------------------------------------------------------------------
class ManagedProcess:
    """A process owned by this checker, with background output logging."""

    def __init__(
        self,
        name: str,
        workspace: Path,
        command: str,
        log_path: Path,
        echo: bool = False,
    ) -> None:
        """
        OBJECTIVE:
        Define an owned long-running process and its evidence channels because ROS drivers must remain active while the main phase continues.
        
        TRACEABILITY:
        USER DEMAND:
        Run only the minimum nodes needed and close the current node before operating another stage.
        
        AI-CONVERTED NEED:
        Long-running process ownership, command, logging and reader state must be grouped into one controllable object.
        
        REQUIREMENT CREATED:
        P2-PROC-001, P2-SEQ-001, P2-RESULT-002.
        
        TECHNICAL DECISIONS:
        TD-P2-002, TD-P2-009, TD-P2-010, TD-P2-019.
        
        INPUTS:
        name: Evidence label; workspace: ROS workspace; command: Long-running command; log_path: Evidence file; echo: Live output flag.
        
        OUTPUTS:
        Initialised ManagedProcess instance; no child process starts yet.
        
        WORKFLOW:
        IN => [process configuration] -store ownership/logging state-> [inactive ManagedProcess] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Separated process definition from process start to make ownership explicit.
        """
        self.name = name
        self.workspace = workspace
        self.command = command
        self.log_path = log_path
        self.echo = echo
        self.process: Optional[subprocess.Popen[str]] = None
        self._thread: Optional[threading.Thread] = None
        self._log_file: Optional[TextIO] = None
        self._lines: list[str] = []
        self._lock = threading.Lock()

    def start(self) -> None:
        """
        OBJECTIVE:
        Start one checker-owned background process and reader thread because ROS drivers must run continuously without blocking orchestration.
        
        TRACEABILITY:
        USER DEMAND:
        Start the required driver, record its log and keep the program available for the next controlled action.
        
        AI-CONVERTED NEED:
        Spawn the command in its own session and continuously drain stdout to evidence storage.
        
        REQUIREMENT CREATED:
        P2-PROC-001, P2-RESULT-002.
        
        TECHNICAL DECISIONS:
        TD-P2-004, TD-P2-009, TD-P2-010, TD-P2-019.
        
        INPUTS:
        Self configuration created by ManagedProcess.__init__.
        
        OUTPUTS:
        None; starts a child process, process group, log file and daemon reader thread.
        
        WORKFLOW:
        IN => [inactive ManagedProcess] -open log/spawn session-> [running process] -start reader-> [observable owned process] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Added background output draining and process-group ownership.
        """
        if self.process is not None:
            raise RuntimeError(f"{self.name} has already been started")

        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._log_file = self.log_path.open("w", encoding="utf-8", buffering=1)
        self._log_file.write(f"NAME={self.name}\n")
        self._log_file.write(f"STARTED_AT={now_iso()}\n")
        self._log_file.write(f"COMMAND={self.command}\n\n")

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"

        self.process = subprocess.Popen(
            ["bash", "-lc", shell_command(self.workspace, self.command)],
            cwd=self.workspace,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            start_new_session=True,
            bufsize=1,
        )

        self._thread = threading.Thread(
            target=self._read_output,
            name=f"{self.name}-reader",
            daemon=True,
        )
        self._thread.start()

    def _read_output(self) -> None:
        """
        OBJECTIVE:
        Continuously drain and record child output because a filled stdout pipe can block a long-running driver and destroy evidence.
        
        TRACEABILITY:
        USER DEMAND:
        Record each driver and RViz terminal process while it is operating.
        
        AI-CONVERTED NEED:
        The output reader must run independently, preserve ordered lines and close the log when the process ends.
        
        REQUIREMENT CREATED:
        P2-RESULT-002, P2-PROC-001.
        
        TECHNICAL DECISIONS:
        TD-P2-009, TD-P2-016.
        
        INPUTS:
        Self with an active process, stdout pipe and open log file.
        
        OUTPUTS:
        None; appends output to memory/log, optionally echoes it, and closes the log at end.
        
        WORKFLOW:
        IN => [child stdout stream] -read line/lock-> [memory + log] -optional echo-> [closed evidence file] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Documented pipe-draining as a reliability requirement, not merely a display feature.
        """
        process = self.process
        if process is None or process.stdout is None:
            return

        try:
            for line in process.stdout:
                with self._lock:
                    self._lines.append(line)
                if self._log_file is not None:
                    self._log_file.write(line)
                if self.echo:
                    print(f"[{self.name}] {line}", end="")
        finally:
            if self._log_file is not None:
                self._log_file.write(f"\nENDED_AT={now_iso()}\n")
                self._log_file.flush()
                self._log_file.close()
                self._log_file = None

    def output(self) -> str:
        """
        OBJECTIVE:
        Return a thread-safe snapshot of captured output because readiness checks must not race the background reader.
        
        TRACEABILITY:
        USER DEMAND:
        Use the driver output to decide whether the software has started or needs review.
        
        AI-CONVERTED NEED:
        Concurrent output access requires locking while preserving the complete text observed so far.
        
        REQUIREMENT CREATED:
        P2-PROC-001, P2-RESULT-001.
        
        TECHNICAL DECISIONS:
        TD-P2-009, TD-P2-012.
        
        INPUTS:
        Self containing captured output lines.
        
        OUTPUTS:
        One concatenated output string.
        
        WORKFLOW:
        IN => [captured lines] -lock/copy/join-> [text snapshot] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Added explicit thread-safe evidence access.
        """
        with self._lock:
            return "".join(self._lines)

    def is_running(self) -> bool:
        """
        OBJECTIVE:
        Report whether the owned child is still active because orchestration decisions must distinguish running from exited processes.
        
        TRACEABILITY:
        USER DEMAND:
        Ensure a driver is operating before proceeding.
        
        AI-CONVERTED NEED:
        Expose process liveness without changing process state.
        
        REQUIREMENT CREATED:
        P2-PROC-001.
        
        TECHNICAL DECISIONS:
        TD-P2-004, TD-P2-012.
        
        INPUTS:
        Self with an optional child process.
        
        OUTPUTS:
        True when a child exists and has not exited; otherwise False.
        
        WORKFLOW:
        IN => [process reference] -poll-> [running boolean] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Documented liveness as limited process evidence rather than physical validation.
        """
        return self.process is not None and self.process.poll() is None

    def wait(self, timeout: Optional[float] = None) -> Optional[int]:
        """
        OBJECTIVE:
        Wait for one owned process to finish and join its output reader because bounded diagnostic captures must complete without losing their final evidence.

        TRACEABILITY:
        USER DEMAND:
        Record voltage for 30 seconds while the motor test is running.

        AI-CONVERTED NEED:
        The orchestrator needs a non-destructive way to wait for a background diagnostic command and obtain its return code.

        REQUIREMENT CREATED:
        P2-VOLT-001, P2-PROC-001, P2-RESULT-002.

        TECHNICAL DECISIONS:
        TD-P2-009, TD-P2-021.

        INPUTS:
        timeout: Optional maximum wait in seconds.

        OUTPUTS:
        Child return code when completed, or None when it is not started or does not finish within the timeout.

        WORKFLOW:
        IN => [owned process/timeout] -wait-> [completed or timed out] -join reader if completed-> [return code or None] => OUTPUT

        IMPROVEMENTS MADE:
        [270726 1501]
        REASON OF FAIL:
        The earlier process wrapper could start and stop diagnostics but could not wait for a naturally bounded 30-second capture.

        IMPROVEMENT:
        Added a bounded wait operation that preserves normal command completion and final log draining.
        """
        if self.process is None:
            return None
        try:
            return_code = self.process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            return None
        if self._thread is not None:
            self._thread.join(timeout=2)
        return return_code

    def wait_for_state(
        self,
        ready_patterns: list[str],
        error_patterns: list[str],
        timeout: float,
    ) -> str:
        """
        OBJECTIVE:
        Classify startup as ready, error, exited or merely running because fixed sleep alone cannot explain what the process did.
        
        TRACEABILITY:
        USER DEMAND:
        Check the process result before allowing the next operation.
        
        AI-CONVERTED NEED:
        Observe captured output and liveness until a monotonic deadline while keeping uncertain states distinct.
        
        REQUIREMENT CREATED:
        P2-PROC-001, P2-TIME-001.
        
        TECHNICAL DECISIONS:
        TD-P2-012, TD-P2-013.
        
        INPUTS:
        ready_patterns: Accepted readiness regexes; error_patterns: Failure regexes; timeout: Observation window.
        
        OUTPUTS:
        State string: READY, ERROR_PATTERN, EXITED or RUNNING.
        
        WORKFLOW:
        IN => [patterns/process/timeout] -poll output+liveness-> [matched/exit/deadline state] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Replaced pure delay logic with evidence-aware startup classification.
        """
        ready_regexes = [re.compile(pattern, re.IGNORECASE) for pattern in ready_patterns]
        error_regexes = [re.compile(pattern, re.IGNORECASE) for pattern in error_patterns]
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            text = self.output()
            if any(pattern.search(text) for pattern in error_regexes):
                return "ERROR_PATTERN"
            if ready_regexes and any(pattern.search(text) for pattern in ready_regexes):
                return "READY"
            if self.process is not None and self.process.poll() is not None:
                return "EXITED"
            time.sleep(0.1)

        if self.process is not None and self.process.poll() is not None:
            return "EXITED"
        return "RUNNING"

    def stop(self) -> None:
        """
        OBJECTIVE:
        Stop only this checker's process group with escalating signals because ROS should receive a normal shutdown opportunity without affecting unrelated nodes.
        
        TRACEABILITY:
        USER DEMAND:
        Close one node/stage before operating another and never kill manually started programs.
        
        AI-CONVERTED NEED:
        Cleanup must target owned process groups, escalate only when needed and join the reader thread.
        
        REQUIREMENT CREATED:
        P2-PROC-001, P2-PROC-002, P2-SEQ-001.
        
        TECHNICAL DECISIONS:
        TD-P2-003, TD-P2-010, TD-P2-011, TD-P2-019.
        
        INPUTS:
        Self containing an optional owned process and reader thread.
        
        OUTPUTS:
        None; process group is stopped where possible and logging thread is joined.
        
        WORKFLOW:
        IN => [owned process] -SIGINT/wait-> [exit or timeout] -SIGTERM/SIGKILL if needed-> [cleaned process] => OUTPUT
        
        IMPROVEMENTS MADE:
        [270726 1347]
        REASON OF FAIL:
        N/A — no verified runtime failure has been recorded for this function.
        
        IMPROVEMENT:
        Implemented ownership-limited staged shutdown.
        """
        process = self.process
        if process is None:
            return

        if process.poll() is None:
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGINT)
            except ProcessLookupError:
                pass

            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                except ProcessLookupError:
                    pass

                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=2)

        if self._thread is not None:
            self._thread.join(timeout=2)


# -----------------------------------------------------------------------------
# SECTION: LIMITED SOFTWARE-EVIDENCE PATTERNS
# TECHNICAL DECISION: Treat text patterns as startup/error evidence only, never
# as a substitute for physical Motor or LiDAR validation.
# -----------------------------------------------------------------------------
COMMON_ERROR_PATTERNS = [
    r"permission denied",
    r"no such file or directory",
    r"failed to open",
    r"could not open",
    r"serial[^\n]*(?:fail|error|closed)",
    r"traceback \(most recent call last\)",
    r"uncaught exception",
]


# -----------------------------------------------------------------------------
# SECTION: USB AND SERIAL-DEVICE VALIDATION
# TECHNICAL DECISION: Inspect filesystem objects directly because ttyUSB numbers
# and ls formatting may vary while the device relationship must remain valid.
# -----------------------------------------------------------------------------
def inspect_serial_path(
    path: Path,
    check_id: str,
    label: str,
    evidence_file: TextIO,
    require_symlink: bool,
) -> CheckResult:
    """
    OBJECTIVE:
    Validate a serial alias and its resolved device structurally because USB numbering may change while the required device relationship must remain valid.
    
    TRACEABILITY:
    USER DEMAND:
    Ignore date and ttyUSB number, but verify symbolic-link, root/dialout, major 188 and ttyUSB structure.
    
    AI-CONVERTED NEED:
    Inspect filesystem metadata directly, preserve evidence and distinguish critical failure from metadata review.
    
    REQUIREMENT CREATED:
    P2-USB-001.
    
    TECHNICAL DECISIONS:
    TD-P2-008, TD-P2-012.
    
    INPUTS:
    path: Alias/device path; check_id: Stable result ID; label: Report label; evidence_file: Open evidence stream; require_symlink: Alias requirement.
    
    OUTPUTS:
    CheckResult containing PASS, FAIL or REVIEW and structural details.
    
    WORKFLOW:
    IN => [serial path] -exist/link/resolve-> [target metadata] -validate ttyUSB/character/ownership-> [CheckResult] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Converted the human ls comparison into stable filesystem-object validation.
    """
    evidence_file.write(f"\n[{check_id}]\nPATH={path}\n")

    if not os.path.lexists(path):
        detail = f"{path} does not exist"
        evidence_file.write(f"RESULT={detail}\n")
        return CheckResult(check_id, label, Status.FAIL, detail)

    is_symlink = path.is_symlink()
    if require_symlink and not is_symlink:
        detail = f"{path} exists but is not a symbolic link"
        evidence_file.write(f"RESULT={detail}\n")
        return CheckResult(check_id, label, Status.FAIL, detail)

    try:
        link_stat = path.lstat()
        target = path.resolve(strict=True)
        target_stat = target.stat()
    except OSError as exc:
        detail = f"Unable to resolve {path}: {exc}"
        evidence_file.write(f"RESULT={detail}\n")
        return CheckResult(check_id, label, Status.FAIL, detail)

    link_owner = safe_username(link_stat.st_uid)
    target_owner = safe_username(target_stat.st_uid)
    target_group = safe_groupname(target_stat.st_gid)
    is_character = stat.S_ISCHR(target_stat.st_mode)
    target_is_ttyusb = bool(re.fullmatch(r"ttyUSB\d+", target.name))
    major_number = os.major(target_stat.st_rdev) if is_character else None

    evidence_file.write(f"IS_SYMLINK={is_symlink}\n")
    evidence_file.write(f"LINK_OWNER={link_owner}\n")
    evidence_file.write(f"TARGET={target}\n")
    evidence_file.write(f"TARGET_OWNER={target_owner}\n")
    evidence_file.write(f"TARGET_GROUP={target_group}\n")
    evidence_file.write(f"TARGET_IS_CHARACTER_DEVICE={is_character}\n")
    evidence_file.write(f"TARGET_IS_TTYUSB={target_is_ttyusb}\n")
    evidence_file.write(f"MAJOR_NUMBER={major_number}\n")

    critical_ok = is_character and target_is_ttyusb
    metadata_ok = (
        link_owner == "root"
        and target_owner == "root"
        and target_group == "dialout"
        and major_number == 188
    )

    if not critical_ok:
        detail = f"{path} -> {target.name}; target is not a valid ttyUSB character device"
        status_value = Status.FAIL
    elif not metadata_ok:
        detail = (
            f"{path} -> {target.name}; device works structurally, "
            f"but metadata differs from root:dialout major 188"
        )
        status_value = Status.REVIEW
    else:
        detail = f"{path} -> {target.name} (root:dialout, major 188)"
        status_value = Status.PASS

    evidence_file.write(f"STATUS={status_value.value}\nDETAIL={detail}\n")
    return CheckResult(check_id, label, status_value, detail)


# -----------------------------------------------------------------------------
# SECTION: MOTOR-STAGE TOPIC AND VOLTAGE DIAGNOSTICS
# TECHNICAL DECISION: Collect software-state and battery evidence while the
# physical motor test is occurring so one stage produces a coherent record.
# -----------------------------------------------------------------------------
def parse_topic_list(output: str) -> list[str]:
    """
    OBJECTIVE:
    Normalise ROS topic-list output because comparison and reporting require stable unique topic names.

    TRACEABILITY:
    USER DEMAND:
    Run ros2 topic list, record it and compare it with the expected Yahboom output.

    AI-CONVERTED NEED:
    Convert arbitrary line ordering and whitespace into a deterministic topic set.

    REQUIREMENT CREATED:
    P2-TOPIC-001.

    TECHNICAL DECISIONS:
    TD-P2-022.

    INPUTS:
    output: Raw ros2 topic list stdout/stderr.

    OUTPUTS:
    Sorted unique topic names beginning with '/'.

    WORKFLOW:
    IN => [raw topic text] -split/strip/filter-> [topic set] -sort-> [topic list] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1501]
    REASON OF FAIL:
    Program 2 previously omitted the updated topic-list requirement.

    IMPROVEMENT:
    Added deterministic topic extraction for validation and evidence recording.
    """
    return sorted({line.strip() for line in output.splitlines() if line.strip().startswith("/")})


def check_topic_list(
    workspace: Path,
    command: str,
    timeout: int,
    expected_topics: list[str],
    log_path: Path,
) -> CheckResult:
    """
    OBJECTIVE:
    Record and assess the active Yahboom ROS topics because motor-driver readiness should include the expected communication interfaces.

    TRACEABILITY:
    USER DEMAND:
    Open another terminal during the motor test, run ros2 topic list and save the record.

    AI-CONVERTED NEED:
    Execute the diagnostic while the driver is active, preserve raw output and identify missing expected topics without rejecting extra valid topics.

    REQUIREMENT CREATED:
    P2-TOPIC-001, P2-RESULT-002.

    TECHNICAL DECISIONS:
    TD-P2-021, TD-P2-022.

    INPUTS:
    workspace: Yahboom workspace; command: Topic-list command; timeout: Maximum command time; expected_topics: Required set; log_path: Evidence file.

    OUTPUTS:
    CheckResult with PASS when all expected topics exist, REVIEW when some are missing, or FAIL when no usable list is produced.

    WORKFLOW:
    IN => [active driver/config] -run topic list-> [raw output] -normalise/compare/log-> [CheckResult] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1501]
    REASON OF FAIL:
    Program 2 v1.0.0.1 did not capture or assess the motor-stage topic list.

    IMPROVEMENT:
    Added a recorded expected-subset check while allowing additional topics.
    """
    code, output = run_command(workspace, command, timeout)
    topics = parse_topic_list(output)
    expected = sorted(set(expected_topics))
    missing = [topic for topic in expected if topic not in topics]
    log_path.write_text(
        "\n".join(
            [
                f"COMMAND={command}",
                f"RETURN_CODE={code}",
                f"EXPECTED_COUNT={len(expected)}",
                f"DETECTED_COUNT={len(topics)}",
                f"MISSING={','.join(missing) if missing else 'NONE'}",
                "",
                output,
            ]
        ),
        encoding="utf-8",
    )

    if not topics:
        status_value = Status.FAIL
        detail = f"No usable topic list detected; return code {code}"
    elif missing:
        status_value = Status.REVIEW
        detail = f"Detected {len(topics)} topics; missing expected: {', '.join(missing)}"
    else:
        status_value = Status.PASS
        detail = f"All {len(expected)} expected topics detected ({len(topics)} total)"
    return CheckResult("MOTOR_TOPIC_LIST", "MOTOR TOPIC LIST", status_value, detail, str(log_path))


ROS_INTERFACE_TYPE_PATTERN = re.compile(
    r"^\s*([A-Za-z][A-Za-z0-9_]*/(?:msg|srv|action)/[A-Za-z][A-Za-z0-9_]*)\s*$",
    flags=re.MULTILINE,
)


def extract_ros_interface_type(output: str) -> Optional[str]:
    """
    OBJECTIVE:
    Extract a valid ROS interface type from CLI output because warnings and unrelated text must not be mistaken for successful topic-type resolution.

    TRACEABILITY:
    USER DEMAND:
    Confirm that /voltage actually works while the motor driver is still active.

    AI-CONVERTED NEED:
    Distinguish a resolvable ROS message type from warning text such as "topic does not appear to be published yet".

    REQUIREMENT CREATED:
    P2-VOLT-001.

    TECHNICAL DECISIONS:
    TD-P2-023, TD-P2-026.

    INPUTS:
    output: Raw stdout/stderr from ros2 topic type.

    OUTPUTS:
    Resolved interface type such as std_msgs/msg/Float32, or None when no valid type is present.

    WORKFLOW:
    IN => [raw type output] -ROS-interface regex-> [matching type or none] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1515]

    REASON OF FAIL:
    ros2 topic echo was started while the CLI still could not determine the /voltage type.

    IMPROVEMENT:
    Added explicit interface-type extraction as part of the readiness gate.
    """
    match = ROS_INTERFACE_TYPE_PATTERN.search(output)
    return match.group(1) if match else None


def wait_for_topic_ready(
    workspace: Path,
    topic: str,
    topic_list_command: str,
    timeout: float,
    poll_interval: float,
    log_path: Path,
) -> tuple[bool, str, Optional[str]]:
    """
    OBJECTIVE:
    Wait until a ROS topic is discoverable and its message type is resolvable because serial-port readiness does not guarantee that the ROS publisher is ready.

    TRACEABILITY:
    USER DEMAND:
    The /voltage command works when the motor driver remains active, so the program must wait for that state before recording.

    AI-CONVERTED NEED:
    Add a bounded ROS-graph readiness gate between motor-driver serial startup and the 30-second voltage capture.

    REQUIREMENT CREATED:
    P2-VOLT-001, P2-TIME-001, P2-RESULT-002.

    TECHNICAL DECISIONS:
    TD-P2-013, TD-P2-021, TD-P2-026.

    INPUTS:
    workspace: Yahboom workspace; topic: Required topic name; topic_list_command: ROS discovery command; timeout: Maximum readiness wait; poll_interval: Delay between attempts; log_path: Evidence path.

    OUTPUTS:
    Tuple of readiness boolean, explanatory detail and resolved interface type when available.

    WORKFLOW:
    IN => [active motor driver/topic/timeout] -poll topic list-> [topic present?] -resolve type-> [ready or retry] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1515]

    REASON OF FAIL:
    Voltage capture began after "Rosmaster Serial Opened" but before /voltage was discoverable, causing immediate recorder exit.

    IMPROVEMENT:
    Added bounded polling with monotonic time, topic-list evidence and explicit message-type resolution before capture.
    """
    timeout = max(0.0, float(timeout))
    poll_interval = max(0.05, float(poll_interval))
    started = time.monotonic()
    deadline = started + timeout
    attempt = 0
    evidence: list[str] = [
        f"STARTED_AT={now_iso()}",
        f"TOPIC={topic}",
        f"TIMEOUT_SECONDS={timeout}",
        f"POLL_INTERVAL_SECONDS={poll_interval}",
        "",
    ]
    last_type: Optional[str] = None

    while True:
        attempt += 1
        list_code, list_output = run_command(workspace, topic_list_command, timeout=5)
        topics = parse_topic_list(list_output)
        present = topic in topics

        type_code: Optional[int] = None
        type_output = ""
        resolved_type: Optional[str] = None
        publisher_count: Optional[int] = None
        info_code: Optional[int] = None
        info_output = ""

        if present:
            type_command = f"ros2 topic type {shlex.quote(topic)}"
            type_code, type_output = run_command(workspace, type_command, timeout=5)
            resolved_type = extract_ros_interface_type(type_output)
            if resolved_type:
                last_type = resolved_type

            info_command = f"ros2 topic info {shlex.quote(topic)}"
            info_code, info_output = run_command(workspace, info_command, timeout=5)
            publisher_match = re.search(
                r"Publisher\s+count\s*:\s*(\d+)",
                info_output,
                flags=re.IGNORECASE,
            )
            if publisher_match:
                publisher_count = int(publisher_match.group(1))

        evidence.extend(
            [
                f"[ATTEMPT {attempt}]",
                f"ELAPSED_SECONDS={time.monotonic() - started:.3f}",
                f"TOPIC_LIST_RETURN_CODE={list_code}",
                f"TOPIC_PRESENT={present}",
                f"TYPE_RETURN_CODE={type_code}",
                f"RESOLVED_TYPE={resolved_type or 'NONE'}",
                f"TOPIC_INFO_RETURN_CODE={info_code}",
                f"PUBLISHER_COUNT={publisher_count if publisher_count is not None else 'UNKNOWN'}",
                "TOPIC_LIST_OUTPUT_BEGIN",
                list_output,
                "TOPIC_LIST_OUTPUT_END",
                "TYPE_OUTPUT_BEGIN",
                type_output,
                "TYPE_OUTPUT_END",
                "TOPIC_INFO_OUTPUT_BEGIN",
                info_output,
                "TOPIC_INFO_OUTPUT_END",
                "",
            ]
        )

        publisher_ready = publisher_count is None or publisher_count > 0
        if present and resolved_type and publisher_ready:
            detail = (
                f"{topic} ready after {attempt} attempt(s); type={resolved_type}"
                + (
                    f"; publishers={publisher_count}"
                    if publisher_count is not None
                    else "; publisher count unavailable"
                )
            )
            evidence.extend(["READY=True", f"DETAIL={detail}", f"ENDED_AT={now_iso()}"])
            log_path.write_text("\n".join(evidence) + "\n", encoding="utf-8")
            return True, detail, resolved_type

        now = time.monotonic()
        if now >= deadline:
            break
        time.sleep(min(poll_interval, max(0.0, deadline - now)))

    detail = (
        f"{topic} was not ready within {timeout:.1f}s; "
        f"last resolved type={last_type or 'NONE'}"
    )
    evidence.extend(["READY=False", f"DETAIL={detail}", f"ENDED_AT={now_iso()}"])
    log_path.write_text("\n".join(evidence) + "\n", encoding="utf-8")
    return False, detail, last_type


VOLTAGE_DATA_PATTERN = re.compile(
    r"^\s*data:\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?)\s*$",
    flags=re.MULTILINE,
)


def extract_voltage_samples(output: str) -> list[float]:
    """
    OBJECTIVE:
    Extract only ROS voltage data values because timestamps and unrelated numbers must not influence the battery judgement.

    TRACEABILITY:
    USER DEMAND:
    Record voltage output for 30 seconds and check whether the data is approximately 11 to 12.

    AI-CONVERTED NEED:
    Parse numeric values specifically from ROS 'data:' lines and ignore other terminal text.

    REQUIREMENT CREATED:
    P2-VOLT-001.

    TECHNICAL DECISIONS:
    TD-P2-023.

    INPUTS:
    output: Raw ros2 topic echo /voltage output.

    OUTPUTS:
    Ordered list of floating-point voltage samples.

    WORKFLOW:
    IN => [raw voltage text] -match data lines-> [numeric strings] -convert-> [float samples] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1501]
    REASON OF FAIL:
    Program 2 previously had no voltage-data parser.

    IMPROVEMENT:
    Added a ROS-message-specific numeric extractor supporting decimal and scientific notation.
    """
    return [float(match) for match in VOLTAGE_DATA_PATTERN.findall(output)]


def evaluate_voltage_samples(
    samples: list[float],
    minimum: float,
    maximum: float,
) -> tuple[Status, str]:
    """
    OBJECTIVE:
    Convert recorded voltage samples into PASS or REVIEW because the supplied procedure treats 11-to-12 as acceptable and every other result as requiring inspection.

    TRACEABILITY:
    USER DEMAND:
    If voltage is within 11 to 12 then PASS; zero or anything else requires further review.

    AI-CONVERTED NEED:
    Apply an inclusive range to every detected sample and never manufacture FAIL from an uncertain battery reading.

    REQUIREMENT CREATED:
    P2-VOLT-001.

    TECHNICAL DECISIONS:
    TD-P2-023.

    INPUTS:
    samples: Parsed voltage values; minimum: Inclusive lower limit; maximum: Inclusive upper limit.

    OUTPUTS:
    Tuple of PASS/REVIEW and a statistical detail string.

    WORKFLOW:
    IN => [samples/range] -validate presence/all values-> [within or review] -summarise min/max/average-> [(Status, detail)] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1501]
    REASON OF FAIL:
    Program 2 v1.0.0.1 omitted the voltage acceptance rule.

    IMPROVEMENT:
    Implemented inclusive 11-to-12 validation with REVIEW for missing, zero or out-of-range evidence.
    """
    if not samples:
        return Status.REVIEW, "No voltage samples were detected"
    sample_min = min(samples)
    sample_max = max(samples)
    average = sum(samples) / len(samples)
    all_within = all(minimum <= value <= maximum for value in samples)
    has_zero = any(value == 0 for value in samples)
    detail = (
        f"{len(samples)} sample(s); min={sample_min:.3f} V, "
        f"max={sample_max:.3f} V, avg={average:.3f} V"
    )
    if all_within and not has_zero:
        return Status.PASS, detail
    return Status.REVIEW, detail + f"; expected {minimum:.1f}-{maximum:.1f} V"


# -----------------------------------------------------------------------------
# SECTION: PRE-LIDAR SERIAL RELEASE AND LOCK DETECTION
# TECHNICAL DECISION: Verify cleanup through /proc evidence and never kill an
# unknown process merely because it holds a serial device.
# -----------------------------------------------------------------------------
def find_device_users(path: Path) -> list[tuple[int, str]]:
    """
    OBJECTIVE:
    Identify processes that still hold a serial device because LiDAR must not start against an occupied port after the motor stage.

    TRACEABILITY:
    USER DEMAND:
    Clear locked serial sessions and double-check the current port mappings before starting LiDAR.

    AI-CONVERTED NEED:
    Detect open file descriptors using standard-library filesystem access while preserving the rule that externally owned processes are not killed.

    REQUIREMENT CREATED:
    P2-SERIAL-001, P2-PROC-001.

    TECHNICAL DECISIONS:
    TD-P2-019, TD-P2-024, TD-P2-025.

    INPUTS:
    path: Serial alias or device path to inspect.

    OUTPUTS:
    Sorted list of (pid, process-name) pairs that currently reference the resolved device.

    WORKFLOW:
    IN => [serial path] -resolve-> [device] -scan /proc/*/fd links-> [matching processes] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1501]
    REASON OF FAIL:
    Program 2 previously assumed cleanup succeeded without checking the serial device after the motor stage.

    IMPROVEMENT:
    Added dependency-free /proc descriptor inspection and external-process preservation.
    """
    try:
        target = path.resolve(strict=True)
    except OSError:
        return []

    users: set[tuple[int, str]] = set()
    proc_root = Path("/proc")
    for process_dir in proc_root.iterdir():
        if not process_dir.name.isdigit():
            continue
        pid = int(process_dir.name)
        fd_dir = process_dir / "fd"
        try:
            fd_entries = list(fd_dir.iterdir())
        except (OSError, PermissionError):
            continue
        for fd_entry in fd_entries:
            try:
                linked = fd_entry.resolve(strict=True)
            except (OSError, PermissionError):
                continue
            if linked != target:
                continue
            try:
                name = (process_dir / "comm").read_text(encoding="utf-8").strip()
            except OSError:
                name = "unknown"
            users.add((pid, name))
            break
    return sorted(users)


def check_serial_release(paths: list[Path], log_path: Path) -> tuple[CheckResult, set[Path]]:
    """
    OBJECTIVE:
    Confirm that relevant serial devices are released and record any remaining users because LiDAR launch must not proceed into a known port conflict.

    TRACEABILITY:
    USER DEMAND:
    After closing motor terminals, clear locked serial sessions and double-check the current mappings before LiDAR.

    AI-CONVERTED NEED:
    Re-resolve each path, inspect open descriptors, report conflicts and identify exactly which launch devices remain occupied.

    REQUIREMENT CREATED:
    P2-SERIAL-001, P2-BLOCK-001.

    TECHNICAL DECISIONS:
    TD-P2-003, TD-P2-024, TD-P2-025.

    INPUTS:
    paths: Serial aliases/devices to inspect; log_path: Evidence file.

    OUTPUTS:
    Tuple of CheckResult and a set of occupied resolved device paths.

    WORKFLOW:
    IN => [serial paths] -resolve/scan users-> [per-device evidence] -classify-> [CheckResult, occupied devices] => OUTPUT

    IMPROVEMENTS MADE:
    [270726 1501]
    REASON OF FAIL:
    The earlier sequence stopped owned processes but did not prove that the LiDAR launch device was free.

    IMPROVEMENT:
    Added post-motor release evidence and a safe block condition for occupied LiDAR ports.
    """
    lines = [f"TIME={now_iso()}"]
    occupied: set[Path] = set()
    observed = 0
    for path in paths:
        lines.append(f"\nPATH={path}")
        try:
            resolved = path.resolve(strict=True)
        except OSError as exc:
            lines.append(f"RESOLVE_ERROR={exc}")
            continue
        observed += 1
        users = find_device_users(path)
        lines.append(f"RESOLVED={resolved}")
        if users:
            occupied.add(resolved)
            lines.append("USERS=" + ", ".join(f"{pid}:{name}" for pid, name in users))
        else:
            lines.append("USERS=NONE")
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    if observed == 0:
        status_value = Status.FAIL
        detail = "No requested serial path could be resolved during recheck"
    elif occupied:
        status_value = Status.REVIEW
        detail = "Serial user(s) remain: " + ", ".join(str(path) for path in sorted(occupied))
    else:
        status_value = Status.PASS
        detail = f"{observed} serial path(s) resolved with no remaining users"
    return (
        CheckResult("SERIAL_SESSION_RELEASE", "SERIAL SESSION RELEASE", status_value, detail, str(log_path)),
        occupied,
    )


# -----------------------------------------------------------------------------
# SECTION: HUMAN-IN-THE-LOOP CONTROL GATES
# TECHNICAL DECISION: Separate q-completion from Y/N/U judgement so the operator
# retains authority over physical and visual correctness.
# -----------------------------------------------------------------------------
def ask_ynu(prompt: str) -> tuple[Status, str]:
    """
    OBJECTIVE:
    Collect a constrained human judgement because motor and LiDAR physical correctness cannot be inferred safely from process output.
    
    TRACEABILITY:
    USER DEMAND:
    Ask Y/N/U and display Success, Fail or further-assistance status.
    
    AI-CONVERTED NEED:
    Accept only Y, N or U and map them consistently to PASS, FAIL or REVIEW.
    
    REQUIREMENT CREATED:
    P2-HIL-002, P2-RESULT-001.
    
    TECHNICAL DECISIONS:
    TD-P2-006, TD-P2-007, TD-P2-014.
    
    INPUTS:
    prompt: Question shown after the operator completes the physical or visual check.
    
    OUTPUTS:
    Tuple of mapped Status and the original normalised Y/N/U input.
    
    WORKFLOW:
    IN => [prompt] -read/normalise-> [Y/N/U or invalid] -repeat/map-> [(Status,input)] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Separated human judgement from automated process evidence.
    """
    mapping = {
        "Y": Status.PASS,
        "N": Status.FAIL,
        "U": Status.REVIEW,
    }

    while True:
        answer = input(prompt).strip().upper()
        if answer in mapping:
            return mapping[answer], answer
        print("Please enter Y, N or U.")


def wait_for_q(prompt: str) -> None:
    """
    OBJECTIVE:
    Pause phase progression until the operator explicitly finishes observation because human review duration cannot be predetermined.
    
    TRACEABILITY:
    USER DEMAND:
    Only when the user keys q, then continue.
    
    AI-CONVERTED NEED:
    Provide a completion gate that is separate from PASS/FAIL/REVIEW judgement.
    
    REQUIREMENT CREATED:
    P2-HIL-001.
    
    TECHNICAL DECISIONS:
    TD-P2-006, TD-P2-007.
    
    INPUTS:
    prompt: Completion instruction shown to the operator.
    
    OUTPUTS:
    None; control returns only after normalised input equals q.
    
    WORKFLOW:
    IN => [prompt] -read/normalise-> [operator input] -validate q-> [repeat or return] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Implemented q as a completion signal rather than a test result.
    """
    while True:
        answer = input(prompt).strip().lower()
        if answer == "q":
            return
        print("Enter q when the review is complete.")


def run_interactive_keyboard(
    workspace: Path,
    command: str,
    metadata_path: Path,
) -> tuple[int, float]:
    """
    OBJECTIVE:
    Run keyboard control in the current terminal because direct single-key operation and q exit must work without third-party dependencies.
    
    TRACEABILITY:
    USER DEMAND:
    Open keyboard control, let the user operate the robot, and continue after q while recording the process by available means.
    
    AI-CONVERTED NEED:
    The interactive command must inherit the real terminal and record metadata even though its full screen output is not captured.
    
    REQUIREMENT CREATED:
    P2-MOTOR-001, P2-HIL-001, P2-SYS-001.
    
    TECHNICAL DECISIONS:
    TD-P2-001, TD-P2-005, TD-P2-006, TD-P2-007.
    
    INPUTS:
    workspace: Yahboom workspace; command: Keyboard command; metadata_path: Session evidence file.
    
    OUTPUTS:
    Tuple of command return code and monotonic session duration; writes session metadata.
    
    WORKFLOW:
    IN => [workspace/command] -run in real terminal-> [human control until q/exit] -record metadata-> [(code,duration)] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Chose terminal inheritance as the minimum-dependency interactive solution and documented its logging limitation.
    """
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    started_at = now_iso()
    return_code = 1

    print(f"\n{CYAN}Keyboard control is now active.{RESET}")
    print("Operate the robot carefully. Press q inside the keyboard controller when finished.\n")

    try:
        completed = subprocess.run(
            ["bash", "-lc", shell_command(workspace, command)],
            cwd=workspace,
            check=False,
        )
        return_code = completed.returncode
    except KeyboardInterrupt:
        return_code = 130
        print("\nKeyboard controller interrupted.")

    duration = time.monotonic() - started
    metadata_path.write_text(
        "\n".join(
            [
                f"STARTED_AT={started_at}",
                f"ENDED_AT={now_iso()}",
                f"COMMAND={command}",
                f"RETURN_CODE={return_code}",
                f"DURATION_SECONDS={duration:.2f}",
                "NOTE=Interactive terminal output was displayed directly and was not captured.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return return_code, duration


def write_build_log(path: Path, command: str, code: int, output: str) -> None:
    """
    OBJECTIVE:
    Persist the exact build command, return code and output because a PASS/FAIL label alone is insufficient for diagnosis.
    
    TRACEABILITY:
    USER DEMAND:
    Save the terminal data process before proceeding.
    
    AI-CONVERTED NEED:
    Build execution must leave a self-contained evidence file.
    
    REQUIREMENT CREATED:
    P2-BUILD-001, P2-RESULT-002.
    
    TECHNICAL DECISIONS:
    TD-P2-016.
    
    INPUTS:
    path: Evidence path; command: Executed build command; code: Return code; output: Captured text.
    
    OUTPUTS:
    None; writes the build evidence file.
    
    WORKFLOW:
    IN => [command/code/output/path] -format/write-> [build log] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Standardised build evidence content.
    """
    path.write_text(
        f"COMMAND={command}\nRETURN_CODE={code}\n\n{output}",
        encoding="utf-8",
    )


def block_check(check_id: str, label: str, reason: str) -> CheckResult:
    """
    OBJECTIVE:
    Create a BLOCKED result because a dependent test must not run when its prerequisite is invalid.
    
    TRACEABILITY:
    USER DEMAND:
    Do not operate the next node or hardware step when the previous required setup failed.
    
    AI-CONVERTED NEED:
    Represent prevented execution explicitly instead of omitting the check or misreporting it as FAIL.
    
    REQUIREMENT CREATED:
    P2-BLOCK-001.
    
    TECHNICAL DECISIONS:
    TD-P2-018.
    
    INPUTS:
    check_id: Stable ID; label: Report name; reason: Failed prerequisite.
    
    OUTPUTS:
    A CheckResult with BLOCKED status.
    
    WORKFLOW:
    IN => [check identity/reason] -construct-> [BLOCKED CheckResult] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Added explicit dependency-state reporting.
    """
    return CheckResult(check_id, label, Status.BLOCKED, reason)


def skip_check(check_id: str, label: str, reason: str) -> CheckResult:
    """
    OBJECTIVE:
    Create a SKIPPED result because an operator-requested omission must remain visible in the report.
    
    TRACEABILITY:
    USER DEMAND:
    Allow selective dry-run or skip options while preserving a complete phase note.
    
    AI-CONVERTED NEED:
    Represent intentional non-execution separately from failure and blocking.
    
    REQUIREMENT CREATED:
    P2-RESULT-001, P2-CLI-001.
    
    TECHNICAL DECISIONS:
    TD-P2-014, TD-P2-020.
    
    INPUTS:
    check_id: Stable ID; label: Report name; reason: Skip rationale.
    
    OUTPUTS:
    A CheckResult with SKIPPED status.
    
    WORKFLOW:
    IN => [check identity/reason] -construct-> [SKIPPED CheckResult] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Added explicit operator-directed skip reporting.
    """
    return CheckResult(check_id, label, Status.SKIPPED, reason)


# -----------------------------------------------------------------------------
# SECTION: FRAMEWORK RESULT AND REPORT GENERATION
# TECHNICAL DECISION: Produce JSON for orchestration and text for review from the
# same structured result so neither representation becomes the hidden truth.
# -----------------------------------------------------------------------------
def phase_result_to_dict(result: PhaseResult) -> dict[str, object]:
    """
    OBJECTIVE:
    Convert typed phase results into JSON-safe primitive values because the master framework cannot rely on Python Enum objects.
    
    TRACEABILITY:
    USER DEMAND:
    Return Program 2 results so the later master can run Phase 1, 2 and 3 together.
    
    AI-CONVERTED NEED:
    Serialise Status values while preserving the common result contract.
    
    REQUIREMENT CREATED:
    P2-RESULT-001, P2-RESULT-002, P2-FRAME-001.
    
    TECHNICAL DECISIONS:
    TD-P2-014, TD-P2-015, TD-P2-016.
    
    INPUTS:
    result: Completed PhaseResult object.
    
    OUTPUTS:
    Dictionary containing only JSON-serialisable values.
    
    WORKFLOW:
    IN => [PhaseResult/dataclasses/enums] -asdict/normalise statuses-> [JSON-safe dictionary] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Created the machine-readable phase interface.
    """
    data = asdict(result)
    data["status"] = result.status.value
    for check_data, check in zip(data["checks"], result.checks):
        check_data["status"] = check.status.value
    return data


def build_phase_text(result: PhaseResult, include_raw_evidence: bool = True) -> str:
    """
    OBJECTIVE:
    Render one complete Phase 2 note section because the user requires all phases to share one readable report format.
    
    TRACEABILITY:
    USER DEMAND:
    Write each phase header, dotted test results, phase completion line and evidence in the same note.
    
    AI-CONVERTED NEED:
    Translate structured results into a deterministic human-readable section without changing the underlying statuses.
    
    REQUIREMENT CREATED:
    P2-RESULT-002, P2-FRAME-001.
    
    TECHNICAL DECISIONS:
    TD-P2-014, TD-P2-016, TD-P2-017.
    
    INPUTS:
    result: PhaseResult; include_raw_evidence: Whether to include trace details and evidence paths.
    
    OUTPUTS:
    Formatted Phase 2 report text.
    
    WORKFLOW:
    IN => [PhaseResult] -format checks/status/evidence-> [phase section] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Implemented the consolidated-note section contract.
    """
    lines = [
        f"[PHASE {result.phase_number}/{result.phase_total}: {result.phase_name}]",
        "",
    ]

    for check in result.checks:
        lines.append(format_result_line(check.label, check.status))

    lines.append("")
    phase_display = {
        Status.PASS: f"PHASE {result.phase_number}: COMPLETED",
        Status.FAIL: f"PHASE {result.phase_number}: FAILED",
        Status.REVIEW: f"PHASE {result.phase_number}: REVIEW REQUIRED",
        Status.ERROR: f"PHASE {result.phase_number}: PROGRAM ERROR",
        Status.BLOCKED: f"PHASE {result.phase_number}: BLOCKED",
        Status.SKIPPED: f"PHASE {result.phase_number}: SKIPPED",
    }[result.status]
    lines.extend([phase_display, "", f"(END OF PHASE {result.phase_number})", ""])

    if include_raw_evidence:
        lines.extend(
            [
                "=" * 72,
                f"RAW EVIDENCE — PHASE {result.phase_number}",
                "=" * 72,
                "",
            ]
        )
        for check in result.checks:
            lines.append(f"[{check.check_id}]")
            lines.append(f"STATUS={check.status.value}")
            if check.detail:
                lines.append(f"DETAIL={check.detail}")
            if check.human_input:
                lines.append(f"HUMAN_INPUT={check.human_input}")
            if check.evidence:
                lines.append(f"EVIDENCE={check.evidence}")
            lines.append("")

        lines.append("EVIDENCE FILES")
        for evidence in result.evidence_files:
            lines.append(evidence)
        lines.append("")

    return "\n".join(lines)


def open_report(path: Path) -> None:
    """
    OBJECTIVE:
    Open the generated report with the desktop default application because immediate human review is part of the check workflow.
    
    TRACEABILITY:
    USER DEMAND:
    After the run, show the saved note without requiring the operator to locate it manually.
    
    AI-CONVERTED NEED:
    Report opening must be optional and must not invalidate a completed phase when the desktop opener fails.
    
    REQUIREMENT CREATED:
    P2-RESULT-002.
    
    TECHNICAL DECISIONS:
    TD-P2-016.
    
    INPUTS:
    path: Generated report path.
    
    OUTPUTS:
    None; starts xdg-open or prints a REVIEW warning on launch failure.
    
    WORKFLOW:
    IN => [report path] -launch desktop opener-> [viewer process or warning] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Kept report viewing separate from test status.
    """
    try:
        subprocess.Popen(
            ["xdg-open", str(path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        show("OPEN_REPORT", Status.REVIEW, str(exc))


# -----------------------------------------------------------------------------
# SECTION: PHASE 2 ORCHESTRATION STATE MACHINE
# TECHNICAL DECISION: Run USB/build/Motor/LiDAR sequentially, block invalid
# dependencies and clean each hardware stage before the next stage begins.
# -----------------------------------------------------------------------------
def run_phase(args: argparse.Namespace) -> tuple[PhaseResult, Path, Path]:
    """
    OBJECTIVE:
    Execute the full Phase 2 state machine because USB, build, motor and LiDAR checks must be ordered, gated, logged and cleaned up as one traceable operation.
    
    TRACEABILITY:
    USER DEMAND:
    Check USB, build, run motor with concurrent topic/voltage evidence until q and Y/N/U, verify serial release, then run LiDAR/RViz until q and Y/N/U and return one phase result.
    
    AI-CONVERTED NEED:
    Orchestrate prerequisites, blocking, human gates, process ownership, evidence output and framework result generation.
    
    REQUIREMENT CREATED:
    P2-SEQ-001, P2-USB-001, P2-BUILD-001, P2-MOTOR-001, P2-TOPIC-001, P2-VOLT-001, P2-SERIAL-001, P2-HIL-001, P2-HIL-002, P2-LIDAR-001, P2-BLOCK-001, P2-RESULT-001, P2-RESULT-002, P2-FRAME-001.
    
    TECHNICAL DECISIONS:
    TD-P2-002, TD-P2-003, TD-P2-007, TD-P2-012, TD-P2-014, TD-P2-016, TD-P2-017, TD-P2-018, TD-P2-019, TD-P2-021, TD-P2-022, TD-P2-023, TD-P2-024, TD-P2-025.
    
    INPUTS:
    args: Parsed CLI/framework configuration including robot ID, paths, commands, skips and timeouts.
    
    OUTPUTS:
    Tuple of PhaseResult, JSON path and text-report path.
    
    WORKFLOW:
    IN => [configuration] -USB/build-> [motor + topic/voltage stage] -cleanup/serial recheck-> [LiDAR/RViz stage] -cleanup/report-> [PhaseResult + files] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Consolidated the user-defined sequential hardware procedure into one guarded phase state machine.
    """
    started_at = now_iso()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    workspace = args.workspace.expanduser().resolve()

    run_dir = args.result_root.expanduser() / args.robot_id / f"{timestamp}_phase2"
    run_dir.mkdir(parents=True, exist_ok=True)

    usb_log = run_dir / "usb_check.log"
    build_log = run_dir / "workspace_build.log"
    motor_driver_log = run_dir / "motor_driver.log"
    keyboard_log = run_dir / "keyboard_session.log"
    topic_list_log = run_dir / "motor_topic_list.log"
    voltage_readiness_log = run_dir / "motor_voltage_readiness.log"
    voltage_log = run_dir / "motor_voltage_30s.log"
    serial_release_log = run_dir / "serial_session_release.log"
    lidar_recheck_log = run_dir / "lidar_serial_recheck.log"
    lidar_driver_log = run_dir / "lidar_driver.log"
    rviz_log = run_dir / "rviz.log"

    result_json = args.result_json.expanduser() if args.result_json else run_dir / "phase2_result.json"
    phase_report = run_dir / "phase2_report.txt"

    checks: list[CheckResult] = []
    evidence_files: list[str] = []
    active_processes: list[ManagedProcess] = []

    if args.dry_run:
        checks.extend(
            [
                CheckResult(
                    "PROGRAM_INTERFACE",
                    "PROGRAM INTERFACE",
                    Status.PASS,
                    "Dry-run interface completed",
                ),
                CheckResult(
                    "DRY_RUN_MODE",
                    "HARDWARE EXECUTION",
                    Status.REVIEW,
                    "Dry run did not validate physical hardware",
                ),
                skip_check("USB_MYSERIAL", "MOTOR SERIAL LINK", "Dry run"),
                skip_check("USB_RPLIDAR", "LIDAR SERIAL LINK", "Dry run"),
                skip_check("WORKSPACE_BUILD", "WORKSPACE BUILD", "Dry run"),
                skip_check("MOTOR_DRIVER", "MOTOR DRIVER", "Dry run"),
                skip_check("MOTOR_TOPIC_LIST", "MOTOR TOPIC LIST", "Dry run"),
                skip_check("MOTOR_VOLTAGE", "MOTOR VOLTAGE", "Dry run"),
                skip_check("MOTOR_OPERATION", "MOTOR OPERATION", "Dry run"),
                skip_check("SERIAL_SESSION_RELEASE", "SERIAL SESSION RELEASE", "Dry run"),
                skip_check("LIDAR_SERIAL_RECHECK", "LIDAR SERIAL RECHECK", "Dry run"),
                skip_check("LIDAR_DRIVER", "LIDAR DRIVER", "Dry run"),
                skip_check("RVIZ_DISPLAY", "RVIZ DISPLAY", "Dry run"),
                skip_check("LIDAR_OPERATION", "LIDAR OPERATION", "Dry run"),
            ]
        )
    else:
        if not workspace.exists():
            checks.append(
                CheckResult(
                    "WORKSPACE_EXISTS",
                    "YAHBOOM WORKSPACE",
                    Status.FAIL,
                    f"Workspace not found: {workspace}",
                )
            )
        else:
            checks.append(
                CheckResult(
                    "WORKSPACE_EXISTS",
                    "YAHBOOM WORKSPACE",
                    Status.PASS,
                    str(workspace),
                )
            )

        with usb_log.open("w", encoding="utf-8") as usb_evidence:
            usb_evidence.write(f"ROBOT_ID={args.robot_id}\nTIME={now_iso()}\n")
            myserial_result = inspect_serial_path(
                Path("/dev/myserial"),
                "USB_MYSERIAL",
                "MOTOR SERIAL LINK",
                usb_evidence,
                require_symlink=True,
            )
            rplidar_result = inspect_serial_path(
                Path("/dev/rplidar"),
                "USB_RPLIDAR",
                "LIDAR SERIAL LINK",
                usb_evidence,
                require_symlink=True,
            )
            checks.extend([myserial_result, rplidar_result])

            lidar_port = Path(args.lidar_port)
            if lidar_port not in (Path("/dev/rplidar"), Path("/dev/myserial")):
                lidar_port_result = inspect_serial_path(
                    lidar_port,
                    "LIDAR_LAUNCH_PORT",
                    "LIDAR LAUNCH PORT",
                    usb_evidence,
                    require_symlink=False,
                )
                checks.append(lidar_port_result)
            else:
                lidar_port_result = rplidar_result

        evidence_files.append(str(usb_log))
        for check in checks:
            if check.check_id.startswith("USB_") or check.check_id == "LIDAR_LAUNCH_PORT":
                check.evidence = str(usb_log)

        workspace_ok = any(
            check.check_id == "WORKSPACE_EXISTS" and check.status == Status.PASS
            for check in checks
        )

        if not workspace_ok:
            checks.append(block_check("WORKSPACE_BUILD", "WORKSPACE BUILD", "Workspace missing"))
            build_ok = False
        elif args.skip_build:
            checks.append(skip_check("WORKSPACE_BUILD", "WORKSPACE BUILD", "--skip-build used"))
            build_ok = True
        else:
            build_command = "colcon build --symlink-install"
            print(f"\n{CYAN}Building workspace: {workspace}{RESET}")
            code, output = run_command(workspace, build_command, args.build_timeout)
            write_build_log(build_log, build_command, code, output)
            evidence_files.append(str(build_log))

            if code == 0:
                build_status = Status.PASS
                build_detail = "colcon build completed successfully"
                build_ok = True
            elif code == 124:
                build_status = Status.ERROR
                build_detail = f"colcon build exceeded {args.build_timeout} seconds"
                build_ok = False
            else:
                build_status = Status.FAIL
                build_detail = f"colcon build returned code {code}"
                build_ok = False

            checks.append(
                CheckResult(
                    "WORKSPACE_BUILD",
                    "WORKSPACE BUILD",
                    build_status,
                    build_detail,
                    str(build_log),
                )
            )
            show("WORKSPACE_BUILD", build_status, build_detail)

        # ----------------------------- Motor phase -----------------------------
        # TECHNICAL DECISION: Keep the motor driver active, wait for /voltage
        # ROS-interface readiness, then overlap the 30-second capture and topic
        # diagnostics with the operator's keyboard-controlled motor test.
        myserial_check = next(check for check in checks if check.check_id == "USB_MYSERIAL")
        if args.skip_motor:
            checks.extend(
                [
                    skip_check("MOTOR_DRIVER", "MOTOR DRIVER", "--skip-motor used"),
                    skip_check("MOTOR_TOPIC_LIST", "MOTOR TOPIC LIST", "--skip-motor used"),
                    skip_check("MOTOR_VOLTAGE", "MOTOR VOLTAGE", "--skip-motor used"),
                    skip_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "--skip-motor used"),
                    skip_check("MOTOR_OPERATION", "MOTOR OPERATION", "--skip-motor used"),
                ]
            )
        elif not build_ok:
            checks.extend(
                [
                    block_check("MOTOR_DRIVER", "MOTOR DRIVER", "Workspace build unavailable"),
                    block_check("MOTOR_TOPIC_LIST", "MOTOR TOPIC LIST", "Motor driver unavailable"),
                    block_check("MOTOR_VOLTAGE", "MOTOR VOLTAGE", "Motor driver unavailable"),
                    block_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Motor driver unavailable"),
                    block_check("MOTOR_OPERATION", "MOTOR OPERATION", "Motor driver unavailable"),
                ]
            )
        elif myserial_check.status == Status.FAIL:
            checks.extend(
                [
                    block_check("MOTOR_DRIVER", "MOTOR DRIVER", "Motor serial link failed"),
                    block_check("MOTOR_TOPIC_LIST", "MOTOR TOPIC LIST", "Motor driver unavailable"),
                    block_check("MOTOR_VOLTAGE", "MOTOR VOLTAGE", "Motor driver unavailable"),
                    block_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Motor driver unavailable"),
                    block_check("MOTOR_OPERATION", "MOTOR OPERATION", "Motor driver unavailable"),
                ]
            )
        else:
            motor_driver = ManagedProcess(
                "motor-driver",
                workspace,
                args.motor_driver_command,
                motor_driver_log,
                echo=args.echo_process_output,
            )
            voltage_monitor: Optional[ManagedProcess] = None
            active_processes.append(motor_driver)
            try:
                print(f"\n{CYAN}Starting motor driver...{RESET}")
                motor_driver.start()
                state = motor_driver.wait_for_state(
                    ready_patterns=[r"Rosmaster\s+Serial\s+Opened"],
                    error_patterns=COMMON_ERROR_PATTERNS,
                    timeout=args.startup_timeout,
                )
                evidence_files.append(str(motor_driver_log))

                if state == "READY":
                    motor_status = Status.PASS
                    motor_detail = "Rosmaster Serial Opened detected"
                elif state == "RUNNING":
                    motor_status = Status.REVIEW
                    motor_detail = "Driver remains active, but readiness text was not detected"
                elif state == "ERROR_PATTERN":
                    motor_status = Status.FAIL
                    motor_detail = "Driver output contains an error pattern"
                else:
                    motor_status = Status.FAIL
                    motor_detail = "Motor driver exited before becoming ready"

                checks.append(
                    CheckResult(
                        "MOTOR_DRIVER",
                        "MOTOR DRIVER",
                        motor_status,
                        motor_detail,
                        str(motor_driver_log),
                    )
                )
                show("MOTOR_DRIVER", motor_status, motor_detail)

                if motor_status == Status.FAIL:
                    checks.extend(
                        [
                            block_check("MOTOR_TOPIC_LIST", "MOTOR TOPIC LIST", "Motor driver failed"),
                            block_check("MOTOR_VOLTAGE", "MOTOR VOLTAGE", "Motor driver failed"),
                            block_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Motor driver failed"),
                            block_check("MOTOR_OPERATION", "MOTOR OPERATION", "Motor driver failed"),
                        ]
                    )
                else:
                    print(
                        f"\n{CYAN}Waiting for {args.voltage_topic} ROS interface "
                        f"before voltage capture...{RESET}"
                    )
                    voltage_ready, voltage_ready_detail, _voltage_type = wait_for_topic_ready(
                        workspace,
                        args.voltage_topic,
                        args.topic_list_command,
                        args.voltage_ready_timeout,
                        args.voltage_ready_poll,
                        voltage_readiness_log,
                    )
                    evidence_files.append(str(voltage_readiness_log))

                    if voltage_ready:
                        voltage_command = args.voltage_command.format(
                            duration=args.voltage_duration,
                            topic=shlex.quote(args.voltage_topic),
                        )
                        voltage_monitor = ManagedProcess(
                            "motor-voltage",
                            workspace,
                            voltage_command,
                            voltage_log,
                            echo=args.echo_process_output,
                        )
                        active_processes.append(voltage_monitor)
                        print(
                            f"\n{CYAN}Recording {args.voltage_topic} for "
                            f"{args.voltage_duration} seconds during the motor test...{RESET}"
                        )
                        voltage_monitor.start()
                        evidence_files.append(str(voltage_log))
                    else:
                        voltage_status = Status.REVIEW
                        voltage_detail = voltage_ready_detail
                        checks.append(
                            CheckResult(
                                "MOTOR_VOLTAGE",
                                "MOTOR VOLTAGE",
                                voltage_status,
                                voltage_detail,
                                str(voltage_readiness_log),
                            )
                        )
                        show("MOTOR_VOLTAGE", voltage_status, voltage_detail)

                    expected_topics = (
                        args.expected_topic
                        if args.expected_topic
                        else list(DEFAULT_EXPECTED_MOTOR_TOPICS)
                    )
                    topic_result = check_topic_list(
                        workspace,
                        args.topic_list_command,
                        args.topic_timeout,
                        expected_topics,
                        topic_list_log,
                    )
                    checks.append(topic_result)
                    evidence_files.append(str(topic_list_log))
                    show(topic_result.check_id, topic_result.status, topic_result.detail)

                    keyboard_code, keyboard_duration = run_interactive_keyboard(
                        workspace,
                        args.keyboard_command,
                        keyboard_log,
                    )
                    evidence_files.append(str(keyboard_log))

                    if keyboard_code == 0:
                        keyboard_status = Status.PASS
                        keyboard_detail = "Keyboard controller exited normally after user operation"
                    elif keyboard_duration < 2.0:
                        keyboard_status = Status.FAIL
                        keyboard_detail = (
                            f"Keyboard controller exited quickly with code {keyboard_code}"
                        )
                    else:
                        keyboard_status = Status.REVIEW
                        keyboard_detail = (
                            f"Keyboard controller ended with code {keyboard_code}; review session"
                        )

                    checks.append(
                        CheckResult(
                            "KEYBOARD_CONTROLLER",
                            "KEYBOARD CONTROLLER",
                            keyboard_status,
                            keyboard_detail,
                            str(keyboard_log),
                        )
                    )
                    show("KEYBOARD_CONTROLLER", keyboard_status, keyboard_detail)

                    if voltage_monitor is not None:
                        voltage_code = voltage_monitor.wait(
                            timeout=max(5.0, float(args.voltage_duration) + 5.0)
                        )
                        if voltage_code is None:
                            voltage_monitor.stop()
                            voltage_code = (
                                voltage_monitor.process.returncode
                                if voltage_monitor.process is not None
                                else None
                            )
                        if voltage_monitor in active_processes:
                            active_processes.remove(voltage_monitor)

                        voltage_samples = extract_voltage_samples(voltage_monitor.output())
                        voltage_status, voltage_detail = evaluate_voltage_samples(
                            voltage_samples,
                            args.voltage_min,
                            args.voltage_max,
                        )
                        voltage_detail += f"; command return code={voltage_code}"
                        checks.append(
                            CheckResult(
                                "MOTOR_VOLTAGE",
                                "MOTOR VOLTAGE",
                                voltage_status,
                                voltage_detail,
                                str(voltage_log),
                            )
                        )
                        show("MOTOR_VOLTAGE", voltage_status, voltage_detail)

                    if keyboard_status == Status.FAIL:
                        checks.append(
                            block_check(
                                "MOTOR_OPERATION",
                                "MOTOR OPERATION",
                                "Keyboard controller failed before a valid motor test",
                            )
                        )
                    else:
                        motor_human_status, motor_human_input = ask_ynu(
                            "Is the motor running under normal circumstances [Y/N/U]? "
                        )
                        motor_human_detail = {
                            Status.PASS: "User confirmed normal motor operation",
                            Status.FAIL: "User reported abnormal motor operation",
                            Status.REVIEW: "User requested further motor assistance/checkup",
                        }[motor_human_status]
                        checks.append(
                            CheckResult(
                                "MOTOR_OPERATION",
                                "MOTOR OPERATION",
                                motor_human_status,
                                motor_human_detail,
                                str(keyboard_log),
                                motor_human_input,
                            )
                        )
                        show("MOTOR_OPERATION", motor_human_status, motor_human_detail)
            finally:
                if voltage_monitor is not None and voltage_monitor.is_running():
                    print("Stopping voltage recorder...")
                    voltage_monitor.stop()
                if voltage_monitor is not None and voltage_monitor in active_processes:
                    active_processes.remove(voltage_monitor)
                print("Stopping motor driver...")
                motor_driver.stop()
                if motor_driver in active_processes:
                    active_processes.remove(motor_driver)

        # ----------------------- Pre-LiDAR serial recheck -----------------------
        # TECHNICAL DECISION: The motor stage is fully cleaned before mapping and
        # lock evidence is collected; external processes are reported, not killed.
        if args.skip_lidar:
            checks.extend(
                [
                    skip_check("SERIAL_SESSION_RELEASE", "SERIAL SESSION RELEASE", "--skip-lidar used"),
                    skip_check("LIDAR_SERIAL_RECHECK", "LIDAR SERIAL RECHECK", "--skip-lidar used"),
                ]
            )
            lidar_serial_ready = False
            occupied_devices: set[Path] = set()
        elif not build_ok:
            checks.extend(
                [
                    block_check("SERIAL_SESSION_RELEASE", "SERIAL SESSION RELEASE", "Workspace build unavailable"),
                    block_check("LIDAR_SERIAL_RECHECK", "LIDAR SERIAL RECHECK", "Workspace build unavailable"),
                ]
            )
            lidar_serial_ready = False
            occupied_devices = set()
        else:
            serial_paths = [Path("/dev/myserial"), Path(args.lidar_port)]
            release_result, occupied_devices = check_serial_release(
                serial_paths,
                serial_release_log,
            )
            checks.append(release_result)
            evidence_files.append(str(serial_release_log))
            show(release_result.check_id, release_result.status, release_result.detail)

            with lidar_recheck_log.open("w", encoding="utf-8") as lidar_recheck_evidence:
                lidar_recheck_evidence.write(
                    f"ROBOT_ID={args.robot_id}\nTIME={now_iso()}\n"
                )
                lidar_recheck_result = inspect_serial_path(
                    Path(args.lidar_port),
                    "LIDAR_SERIAL_RECHECK",
                    "LIDAR SERIAL RECHECK",
                    lidar_recheck_evidence,
                    require_symlink=False,
                )
            lidar_recheck_result.evidence = str(lidar_recheck_log)
            checks.append(lidar_recheck_result)
            evidence_files.append(str(lidar_recheck_log))
            show(
                lidar_recheck_result.check_id,
                lidar_recheck_result.status,
                lidar_recheck_result.detail,
            )
            try:
                resolved_lidar_port = Path(args.lidar_port).resolve(strict=True)
            except OSError:
                resolved_lidar_port = Path(args.lidar_port)
            lidar_serial_ready = (
                lidar_recheck_result.status != Status.FAIL
                and resolved_lidar_port not in occupied_devices
            )

        # ----------------------------- LiDAR phase -----------------------------
        if args.skip_lidar:
            checks.extend(
                [
                    skip_check("LIDAR_DRIVER", "LIDAR DRIVER", "--skip-lidar used"),
                    skip_check("RVIZ_DISPLAY", "RVIZ DISPLAY", "--skip-lidar used"),
                    skip_check("LIDAR_OPERATION", "LIDAR OPERATION", "--skip-lidar used"),
                ]
            )
        elif not build_ok:
            checks.extend(
                [
                    block_check("LIDAR_DRIVER", "LIDAR DRIVER", "Workspace build unavailable"),
                    block_check("RVIZ_DISPLAY", "RVIZ DISPLAY", "LiDAR driver unavailable"),
                    block_check("LIDAR_OPERATION", "LIDAR OPERATION", "LiDAR driver unavailable"),
                ]
            )
        elif not lidar_serial_ready:
            checks.extend(
                [
                    block_check("LIDAR_DRIVER", "LIDAR DRIVER", "LiDAR serial recheck failed or launch port remains occupied"),
                    block_check("RVIZ_DISPLAY", "RVIZ DISPLAY", "LiDAR driver unavailable"),
                    block_check("LIDAR_OPERATION", "LIDAR OPERATION", "LiDAR driver unavailable"),
                ]
            )
        elif lidar_port_result.status == Status.FAIL:
            checks.extend(
                [
                    block_check("LIDAR_DRIVER", "LIDAR DRIVER", "LiDAR launch port failed"),
                    block_check("RVIZ_DISPLAY", "RVIZ DISPLAY", "LiDAR driver unavailable"),
                    block_check("LIDAR_OPERATION", "LIDAR OPERATION", "LiDAR driver unavailable"),
                ]
            )
        else:
            lidar_command = args.lidar_driver_command.format(
                lidar_port=shlex.quote(args.lidar_port)
            )
            lidar_driver = ManagedProcess(
                "lidar-driver",
                workspace,
                lidar_command,
                lidar_driver_log,
                echo=args.echo_process_output,
            )
            active_processes.append(lidar_driver)

            try:
                print(f"\n{CYAN}Starting LiDAR driver...{RESET}")
                lidar_driver.start()
                lidar_state = lidar_driver.wait_for_state(
                    ready_patterns=[],
                    error_patterns=COMMON_ERROR_PATTERNS,
                    timeout=args.lidar_startup_wait,
                )
                evidence_files.append(str(lidar_driver_log))

                if lidar_state == "RUNNING":
                    lidar_status = Status.PASS
                    lidar_detail = "LiDAR launch remained active without a detected error"
                elif lidar_state == "ERROR_PATTERN":
                    lidar_status = Status.FAIL
                    lidar_detail = "LiDAR output contains an error pattern"
                else:
                    lidar_status = Status.FAIL
                    lidar_detail = "LiDAR launch exited during startup"

                checks.append(
                    CheckResult(
                        "LIDAR_DRIVER",
                        "LIDAR DRIVER",
                        lidar_status,
                        lidar_detail,
                        str(lidar_driver_log),
                    )
                )
                show("LIDAR_DRIVER", lidar_status, lidar_detail)

                if lidar_status == Status.FAIL:
                    checks.extend(
                        [
                            block_check("RVIZ_DISPLAY", "RVIZ DISPLAY", "LiDAR driver failed"),
                            block_check(
                                "LIDAR_OPERATION",
                                "LIDAR OPERATION",
                                "LiDAR driver failed",
                            ),
                        ]
                    )
                else:
                    rviz = ManagedProcess(
                        "rviz",
                        workspace,
                        args.rviz_command,
                        rviz_log,
                        echo=args.echo_process_output,
                    )
                    active_processes.append(rviz)
                    try:
                        print(f"\n{CYAN}Starting RViz...{RESET}")
                        rviz.start()
                        rviz_state = rviz.wait_for_state(
                            ready_patterns=[],
                            error_patterns=COMMON_ERROR_PATTERNS,
                            timeout=args.rviz_startup_wait,
                        )
                        evidence_files.append(str(rviz_log))

                        if rviz_state == "RUNNING":
                            rviz_status = Status.PASS
                            rviz_detail = "RViz launch remained active"
                        elif rviz_state == "ERROR_PATTERN":
                            rviz_status = Status.FAIL
                            rviz_detail = "RViz output contains an error pattern"
                        else:
                            rviz_status = Status.FAIL
                            rviz_detail = "RViz launch exited during startup"

                        checks.append(
                            CheckResult(
                                "RVIZ_DISPLAY",
                                "RVIZ DISPLAY",
                                rviz_status,
                                rviz_detail,
                                str(rviz_log),
                            )
                        )
                        show("RVIZ_DISPLAY", rviz_status, rviz_detail)

                        if rviz_status == Status.FAIL:
                            checks.append(
                                block_check(
                                    "LIDAR_OPERATION",
                                    "LIDAR OPERATION",
                                    "RViz did not remain active",
                                )
                            )
                        else:
                            wait_for_q(
                                "Observe the LiDAR display. Enter q here when review is complete: "
                            )
                    finally:
                        print("Stopping RViz...")
                        rviz.stop()
                        if rviz in active_processes:
                            active_processes.remove(rviz)

                    rviz_check = next(
                        check for check in reversed(checks) if check.check_id == "RVIZ_DISPLAY"
                    )
                    if rviz_check.status != Status.FAIL:
                        lidar_human_status, lidar_human_input = ask_ynu(
                            "Is the LiDAR operating and displaying scan data normally [Y/N/U]? "
                        )
                        lidar_human_detail = {
                            Status.PASS: "User confirmed normal LiDAR operation",
                            Status.FAIL: "User reported abnormal LiDAR operation",
                            Status.REVIEW: "User requested further LiDAR assistance/checkup",
                        }[lidar_human_status]
                        checks.append(
                            CheckResult(
                                "LIDAR_OPERATION",
                                "LIDAR OPERATION",
                                lidar_human_status,
                                lidar_human_detail,
                                str(rviz_log),
                                lidar_human_input,
                            )
                        )
                        show("LIDAR_OPERATION", lidar_human_status, lidar_human_detail)
            finally:
                print("Stopping LiDAR driver...")
                lidar_driver.stop()
                if lidar_driver in active_processes:
                    active_processes.remove(lidar_driver)

    phase_status = calculate_phase_status(checks)
    result = PhaseResult(
        program=PROGRAM_NAME,
        version=PROGRAM_VERSION,
        phase_number=PHASE_NUMBER,
        phase_total=PHASE_TOTAL,
        phase_name=PHASE_NAME,
        robot_id=args.robot_id,
        started_at=started_at,
        ended_at=now_iso(),
        status=phase_status,
        checks=checks,
        evidence_files=sorted(set(evidence_files)),
    )

    result_json.parent.mkdir(parents=True, exist_ok=True)
    result_json.write_text(
        json.dumps(phase_result_to_dict(result), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    phase_text = build_phase_text(result, include_raw_evidence=True)
    phase_report.write_text(phase_text, encoding="utf-8")

    if args.append_report:
        append_path = args.append_report.expanduser()
        append_path.parent.mkdir(parents=True, exist_ok=True)
        with append_path.open("a", encoding="utf-8") as shared_report:
            if append_path.stat().st_size > 0:
                shared_report.write("\n\n")
            shared_report.write(phase_text)

    return result, result_json, phase_report


# -----------------------------------------------------------------------------
# SECTION: STANDALONE AND MASTER-FRAMEWORK INTERFACE
# TECHNICAL DECISION: Keep paths, commands and timeouts configurable so the same
# phase can be tested alone and later controlled by the consolidated master.
# -----------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    """
    OBJECTIVE:
    Define the command-line and master-framework interface because Program 2 must be runnable alone and configurable when orchestrated by another program.
    
    TRACEABILITY:
    USER DEMAND:
    Use one command now, then allow the same phase to join the future three-program framework.
    
    AI-CONVERTED NEED:
    Expose stable robot, path, command, timeout, topic-readiness, voltage, skip, dry-run and shared-report parameters.
    
    REQUIREMENT CREATED:
    P2-FRAME-001, P2-CLI-001.
    
    TECHNICAL DECISIONS:
    TD-P2-017, TD-P2-020.
    
    INPUTS:
    None.
    
    OUTPUTS:
    Configured argparse.ArgumentParser.
    
    WORKFLOW:
    IN => [program interface requirements] -declare arguments/defaults-> [parser] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Added master-supplied JSON/report paths and configurable vendor commands.
    """
    parser = argparse.ArgumentParser(
        description="Phase 2 Yahboom robot control and LiDAR checker (standard library only)."
    )
    parser.add_argument("robot_id", help="Robot number, for example R23")
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path.home() / "yahboomcar_ws",
        help="Yahboom ROS 2 workspace",
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path.home() / "robot_check_results",
        help="Root directory for results",
    )
    parser.add_argument(
        "--result-json",
        type=Path,
        help="Optional JSON result path supplied by the master framework",
    )
    parser.add_argument(
        "--append-report",
        type=Path,
        help="Append this Phase 2 section to a shared master report",
    )
    parser.add_argument("--skip-build", action="store_true")
    parser.add_argument("--skip-motor", action="store_true")
    parser.add_argument("--skip-lidar", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-open-report", action="store_true")
    parser.add_argument("--echo-process-output", action="store_true")

    parser.add_argument("--build-timeout", type=int, default=900)
    parser.add_argument("--startup-timeout", type=float, default=15.0)
    parser.add_argument("--lidar-startup-wait", type=float, default=8.0)
    parser.add_argument("--rviz-startup-wait", type=float, default=8.0)
    parser.add_argument("--topic-timeout", type=int, default=10)
    parser.add_argument("--voltage-topic", default="/voltage")
    parser.add_argument("--voltage-ready-timeout", type=float, default=15.0)
    parser.add_argument("--voltage-ready-poll", type=float, default=0.5)
    parser.add_argument("--voltage-duration", type=int, default=30)
    parser.add_argument("--voltage-min", type=float, default=11.0)
    parser.add_argument("--voltage-max", type=float, default=12.0)

    parser.add_argument("--lidar-port", default="/dev/ydlidar")
    parser.add_argument(
        "--motor-driver-command",
        default="ros2 run yahboomcar_bringup Mcnamu_driver_X3",
    )
    parser.add_argument(
        "--keyboard-command",
        default="ros2 run yahboomcar_ctrl yahboom_keyboard",
    )
    parser.add_argument(
        "--topic-list-command",
        default="ros2 topic list",
    )
    parser.add_argument(
        "--expected-topic",
        action="append",
        help="Expected motor-stage topic; repeat to replace the built-in expected set",
    )
    parser.add_argument(
        "--voltage-command",
        default="timeout --signal=INT {duration}s ros2 topic echo {topic}",
        help=(
            "Use {duration} and {topic} as placeholders for --voltage-duration "
            "and --voltage-topic"
        ),
    )
    parser.add_argument(
        "--lidar-driver-command",
        default=(
            "ros2 launch sllidar_ros2 view_sllidar_s2_launch.py "
            "serial_port:={lidar_port}"
        ),
        help="Use {lidar_port} as a placeholder for --lidar-port",
    )
    parser.add_argument(
        "--rviz-command",
        default="ros2 launch sllidar_ros2 view_sllidar_s2_launch.py",
    )
    return parser


def main() -> int:
    """
    OBJECTIVE:
    Provide a safe executable entry point because framework execution errors and robot test outcomes must be reported separately.
    
    TRACEABILITY:
    USER DEMAND:
    Run Program 2 simply, save the output, and allow later use by the master program.
    
    AI-CONVERTED NEED:
    Parse configuration, invoke the phase, handle top-level interruption/error, print paths and return an execution-only exit code.
    
    REQUIREMENT CREATED:
    P2-FRAME-001, P2-RESULT-002.
    
    TECHNICAL DECISIONS:
    TD-P2-015, TD-P2-016, TD-P2-019.
    
    INPUTS:
    Command-line arguments supplied through sys.argv.
    
    OUTPUTS:
    Integer process exit code: 0 for completed checker execution, 1 for unexpected error, 130 for user interruption.
    
    WORKFLOW:
    IN => [CLI arguments] -parse/run phase-> [result files] -display/open-> [execution exit code] => OUTPUT
    
    IMPROVEMENTS MADE:
    [270726 1347]
    REASON OF FAIL:
    N/A — no verified runtime failure has been recorded for this function.
    
    IMPROVEMENT:
    Separated framework execution status from PASS/FAIL/REVIEW robot outcomes.
    """
    parser = build_parser()
    args = parser.parse_args()

    print(f"\n{CYAN}{PROGRAM_NAME} v{PROGRAM_VERSION}{RESET}")
    print(f"Robot: {args.robot_id}")
    print(f"Workspace: {args.workspace.expanduser()}")
    print("Standard-library-only build\n")

    try:
        result, result_json, phase_report = run_phase(args)
    except KeyboardInterrupt:
        print("\nInterrupted by user. Active owned processes were cleaned up where possible.")
        return 130
    except Exception as exc:  # Top-level guard for a recoverable framework result.
        print(f"\nUnexpected program error: {exc}", file=sys.stderr)
        return 1

    print("\n" + build_phase_text(result, include_raw_evidence=False))
    print(f"JSON result: {result_json}")
    print(f"Phase report: {phase_report}")

    if not args.no_open_report:
        open_report(phase_report)

    # Exit code reports whether the checker itself completed, not PASS/FAIL/REVIEW.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
