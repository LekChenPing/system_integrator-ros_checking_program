#!/usr/bin/env python3
"""
PROGRAM 3 — NAVIGATION STACK CHECK
Version: 1.0.0.0
Python: 3.10+
Dependencies: Python standard library only.

USER INTENT
-----------
Verify that the Cartographer mapping stack and the DWA navigation stack can
launch and operate as coordinated three-process systems, while preserving the
human operator's authority to inspect RViz and decide whether each stack is
good to go.

SOURCE-DERIVED OPERATING SCOPE
------------------------------
MAPPING SUBPHASE:
1. Inspect USB port bindings and pause five seconds for operator review.
2. Start map_cartographer_launch.py.
3. Start display_map_launch.py.
4. Start yahboom_keyboard so the operator can move the robot.
5. Keep Cartographer, RViz and keyboard control active concurrently.
6. Continue only after the operator ends keyboard control with q.
7. Ask the operator whether the mapping stack is good to go.

NAVIGATION SUBPHASE:
1. Start laser_bringup_launch.py with pub_odom_tf:=true.
2. Start display_nav_launch.py.
3. Start navigation_dwa_launch.py.
4. Keep laser/odom bring-up, RViz and DWA navigation active concurrently.
5. Wait until the operator enters q in the checker terminal.
6. Ask the operator whether the navigation stack is good to go.

EXPLICIT USER SCOPE CLARIFICATIONS
----------------------------------
1. The program does not save a map; it only verifies that the mapping programs
   operate and display through RViz.
2. The program does not require a navigation goal or route completion; the
   operator visually checks RViz and decides whether the stack is good to go.
3. "Three terminals" is implemented as three concurrently owned child
   processes; the checker does not depend on automating Terminator panes.

USER DEMANDS -> AI-CONVERTED NEEDS -> REQUIREMENTS
--------------------------------------------------
USER DEMAND:
Run the three corresponding programs at the same time for each subphase, let
the human user inspect RViz, and ask Y/N/U whether the system is good to go.

AI-CONVERTED NEED:
Program 3 must coordinate two sequential integration subphases, keep three ROS
processes alive concurrently in each subphase, collect their logs, pause for
human observation, preserve q as a completion signal, preserve Y/N/U as the
functional judgement, and clean up every owned process before moving on.

REQUIREMENTS CREATED:
P3-ENV-001:
The checker shall source ROS 2 Humble and the selected yahboomcar_ws setup for
every child command when the workspace setup file exists.

P3-ENV-002:
The checker shall verify workspace existence and optionally build it with
colcon build --symlink-install before running the integration checks.

P3-PORT-001:
The checker shall inspect /dev/myserial and /dev/rplidar, display their resolved
ttyUSB bindings, pause for five seconds by default, and request Y/N/U operator
confirmation.

P3-MAP-001:
The mapping subphase shall run map_cartographer_launch.py,
display_map_launch.py and yahboom_keyboard concurrently.

P3-MAP-002:
The mapping subphase shall continue only after the keyboard controller exits,
normally through the operator pressing q.

P3-MAP-003:
The final MAPPING STACK OPERATION status shall come from the operator's Y/N/U
judgement rather than from process survival alone.

P3-NAV-001:
The navigation subphase shall run laser_bringup_launch.py with
pub_odom_tf:=true, display_nav_launch.py and navigation_dwa_launch.py
concurrently.

P3-NAV-002:
The navigation observation shall continue until the operator enters q in the
checker terminal.

P3-NAV-003:
The final NAVIGATION STACK OPERATION status shall come from the operator's
Y/N/U judgement rather than from process survival alone.

P3-PROC-001:
Every background process shall run in a checker-owned process group, write its
combined stdout/stderr to an evidence file, and be stopped in reverse order.

P3-PROC-002:
The checker shall attempt SIGINT, then SIGTERM, then SIGKILL only when required
to stop an owned process.

P3-PROC-003:
The checker shall not terminate manually launched or unrelated ROS processes.

P3-READY-001:
A launch check may report SUCCESS when the process remains active without a
detected fatal error, but this software evidence shall not replace the human
RViz judgement.

P3-SERIAL-001:
After mapping cleanup, the checker shall verify that the serial devices are no
longer held before starting the navigation subphase.

P3-EVID-001:
The checker shall save mapping and navigation ROS graph snapshots as supporting
evidence without using undocumented topic names as mandatory PASS criteria.

P3-REPORT-001:
Each check shall produce a structured status, detail and evidence reference,
and the program shall write both JSON and a formatted Phase 3 report.

P3-FRAMEWORK-001:
Program 3 shall run independently or accept result paths supplied by a future
master framework.

P3-SCOPE-001:
Program 3 shall not claim map persistence, route completion, autonomous goal
execution or navigation performance because those operations are outside the
user-defined test scope.

TECHNICAL DECISION REGISTER
---------------------------
TD-P3-001:
Use Python standard-library components only to minimise deployment friction on
each Jetson system.

TD-P3-002:
Implement Phase 3 as two sequential integration subphases—Mapping followed by
Navigation—so each stack receives a clean hardware and process state.

TD-P3-003:
Run exactly three relevant ROS processes concurrently in each subphase because
the user's acceptance test concerns their combined operation.

TD-P3-004:
Treat the three requested terminals as three managed child processes rather
than automating Terminator panes, because process ownership and logging are
more reliable than terminal-window automation.

TD-P3-005:
Do not save a map because the user defined Program 3 as an operation/display
check rather than a map-persistence test.

TD-P3-006:
Do not set a navigation goal because the user defined success as visual RViz
inspection rather than route execution.

TD-P3-007:
Use subprocess.run() for bounded commands and ManagedProcess/Popen for ROS
launches that must remain active.

TD-P3-008:
Run every ROS command through bash -lc so ROS 2 Humble and workspace setup can
be sourced inside each child shell.

TD-P3-009:
Capture long-running process output with a background reader thread so the
main orchestration flow remains available for human input and process control.

TD-P3-010:
Create a new process session for every owned background process so cleanup can
target only that process group.

TD-P3-011:
Escalate cleanup from SIGINT to SIGTERM and finally SIGKILL so normal ROS
shutdown is attempted before forced termination.

TD-P3-012:
Use process survival and fatal-error patterns only as software launch evidence,
not as proof that mapping or navigation is physically correct.

TD-P3-013:
Reserve the final mapping and navigation judgements for the human operator
because RViz interpretation is outside the reliable scope of text-only process
inspection.

TD-P3-014:
Keep q as a completion signal and Y/N/U as the actual PASS/FAIL/REVIEW
judgement so ending observation does not automatically imply success.

TD-P3-015:
Run the mapping keyboard controller in the current real terminal so direct key
control works without a third-party pseudo-terminal dependency.

TD-P3-016:
Inspect serial aliases and character-device metadata directly instead of
parsing ls formatting as the authoritative test.

TD-P3-017:
Pause for a configurable five-second port-binding review because the source
workflow explicitly gives the operator time to inspect the mapping.

TD-P3-018:
Stop mapping processes before navigation and verify serial release because
both subphases may use the same physical serial devices.

TD-P3-019:
Report external serial users but never kill them because the checker only owns
processes that it started.

TD-P3-020:
Collect ros2 node list and ros2 topic list snapshots as evidence only because
the source does not define a mandatory ROS-interface whitelist.

TD-P3-021:
Normalise the source typo "display_map_launch .py" to
"display_map_launch.py" because ROS launch filenames cannot contain that
unintended separating space.

TD-P3-022:
Make all launch commands configurable through CLI arguments so vendor package
changes can be handled without rewriting orchestration logic.

TD-P3-023:
Write both machine-readable JSON and a human-readable Phase report so the same
execution supports framework integration and operator review.

TD-P3-024:
Keep checker exit codes separate from PASS/FAIL/REVIEW outcomes; exit code zero
means the workflow completed and the report contains the test result.

TD-P3-025:
Block dependent operations when their prerequisite launch or serial condition
fails rather than running a misleading partial integration test.

KNOWN LIMITATIONS
-----------------
KL-P3-001:
Program 3 does not save or reload a map.

KL-P3-002:
Program 3 does not set a navigation goal or verify route completion.

KL-P3-003:
A process remaining active does not prove ROS semantic correctness; the final
acceptance decision depends on the operator's RViz observation.

KL-P3-004:
The keyboard controller's complete interactive terminal output is displayed
directly and is not fully captured; metadata and the operator judgement are
saved.

KL-P3-005:
Startup readiness uses bounded process observation because the source does not
define exact mandatory topic, node, service or TF criteria.

KL-P3-006:
The first hardware run may reveal vendor-specific warnings or launch timing
that require evidence-based refinement.

IMPROVEMENT HISTORY
-------------------
[270726 1631]
REASON OF FAIL:
N/A — this is the initial Program 3 implementation based on the clarified
operational scope.

IMPROVEMENT:
Removed inferred map-save and navigation-goal requirements, preserved the
three-process concurrent operation requested for each subphase, and assigned
the final good-to-go judgement to the human operator.

DOCUMENTATION PRINCIPLE
-----------------------
Each function records its objective, user-derived need, created requirement,
technical decisions, inputs, outputs, workflow and evidence-based improvement
history.
"""

from __future__ import annotations

import argparse
import grp
import json
import os
import pwd
import re
import shlex
import signal
import stat
import subprocess
import sys
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional, TextIO


PROGRAM_NAME = "phase3_navigation_stack"
PROGRAM_VERSION = "1.0.0.0"
PHASE_NUMBER = 3
PHASE_TOTAL = 3
PHASE_NAME = "NAVIGATION STACK CHECK"

GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
RESET = "\033[0m"


class Status(str, Enum):
    """
    OBJECTIVE:
    Define one controlled status vocabulary because every subphase and report
    must interpret outcomes consistently.

    TRACEABILITY:
    USER DEMAND:
    Show success, failure or need for further assistance after each check.

    AI-CONVERTED NEED:
    Represent automatic and human outcomes with one serialisable enum.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023, TD-P3-024.

    INPUTS:
    N/A.

    OUTPUTS:
    Enum members PASS, FAIL, REVIEW, ERROR, SKIPPED and BLOCKED.

    WORKFLOW:
    IN => [status concept] -normalise vocabulary-> [enum member] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Phase 2 status contract for master-framework compatibility.
    """

    PASS = "PASS"
    FAIL = "FAIL"
    REVIEW = "REVIEW"
    ERROR = "ERROR"
    SKIPPED = "SKIPPED"
    BLOCKED = "BLOCKED"


DISPLAY_STATUS = {
    Status.PASS: "SUCCESS",
    Status.FAIL: "FAILED",
    Status.REVIEW: "REVIEW REQUIRED",
    Status.ERROR: "PROGRAM ERROR",
    Status.SKIPPED: "SKIPPED",
    Status.BLOCKED: "BLOCKED",
}


@dataclass
class CheckResult:
    """
    OBJECTIVE:
    Preserve one check's judgement and evidence because the master report must
    remain traceable to the actual execution.

    TRACEABILITY:
    USER DEMAND:
    Record every check in one common note.

    AI-CONVERTED NEED:
    Use a common result object for automatic checks, human decisions and logs.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    check_id, label, status, optional detail, evidence and human input.

    OUTPUTS:
    A serialisable record representing one verification result.

    WORKFLOW:
    IN => [check data] -store consistently-> [CheckResult] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Phase 2 contract so the future master program can aggregate it.
    """

    check_id: str
    label: str
    status: Status
    detail: str = ""
    evidence: str = ""
    human_input: str = ""


@dataclass
class PhaseResult:
    """
    OBJECTIVE:
    Aggregate every Program 3 check into one Phase 3 result because the future
    master framework needs a single structured output.

    TRACEABILITY:
    USER DEMAND:
    Keep Phase 1, Phase 2 and Phase 3 in the same reporting framework.

    AI-CONVERTED NEED:
    Return stable phase metadata, status, checks and evidence paths.

    REQUIREMENT CREATED:
    P3-REPORT-001 and P3-FRAMEWORK-001.

    TECHNICAL DECISIONS:
    TD-P3-023, TD-P3-024.

    INPUTS:
    Program metadata, robot ID, timestamps, phase status and check records.

    OUTPUTS:
    One complete PhaseResult.

    WORKFLOW:
    IN => [metadata + checks] -aggregate-> [PhaseResult] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Preserved compatibility with the Program 2 result format.
    """

    program: str
    version: str
    phase_number: int
    phase_total: int
    phase_name: str
    robot_id: str
    started_at: str
    ended_at: str
    status: Status
    checks: list[CheckResult] = field(default_factory=list)
    evidence_files: list[str] = field(default_factory=list)

# SECTION DECISION: Use one timezone-aware timestamp format across evidence and reports.
def now_iso() -> str:
    """
    OBJECTIVE:
    Create a timezone-aware timestamp because evidence must identify when each
    action occurred.

    TRACEABILITY:
    USER DEMAND:
    Record the terminal process and test history.

    AI-CONVERTED NEED:
    Attach stable timestamps to logs and result metadata.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    None.

    OUTPUTS:
    Current local ISO-8601 timestamp to second precision.

    WORKFLOW:
    IN => [current time] -attach timezone/format-> [ISO timestamp] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 timestamp convention.
    """
    return datetime.now().astimezone().isoformat(timespec="seconds")


# SECTION DECISION: Convert Unix IDs to readable names without allowing missing entries to break evidence collection.
def safe_username(uid: int) -> str:
    """
    OBJECTIVE:
    Convert a UID into readable evidence because serial-device ownership should
    be understandable in the report.

    TRACEABILITY:
    USER DEMAND:
    Inspect root ownership in the port-binding state.

    AI-CONVERTED NEED:
    Resolve numeric UID values safely while preserving a fallback.

    REQUIREMENT CREATED:
    P3-PORT-001.

    TECHNICAL DECISIONS:
    TD-P3-016.

    INPUTS:
    uid: Unix user identifier.

    OUTPUTS:
    Username when resolvable, otherwise the numeric UID as text.

    WORKFLOW:
    IN => [uid] -pwd lookup-> [name or numeric fallback] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added a fallback so unusual system accounts cannot crash the checker.
    """
    try:
        return pwd.getpwuid(uid).pw_name
    except KeyError:
        return str(uid)


def safe_groupname(gid: int) -> str:
    """
    OBJECTIVE:
    Convert a GID into readable evidence because the dialout relationship is
    part of the serial-port inspection.

    TRACEABILITY:
    USER DEMAND:
    Check the device group and binding state before running the stack.

    AI-CONVERTED NEED:
    Resolve the Unix group safely for human-readable reporting.

    REQUIREMENT CREATED:
    P3-PORT-001.

    TECHNICAL DECISIONS:
    TD-P3-016.

    INPUTS:
    gid: Unix group identifier.

    OUTPUTS:
    Group name when resolvable, otherwise the numeric GID as text.

    WORKFLOW:
    IN => [gid] -grp lookup-> [name or numeric fallback] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added a safe fallback for unknown group IDs.
    """
    try:
        return grp.getgrgid(gid).gr_name
    except KeyError:
        return str(gid)


# SECTION DECISION: Present every judgement through one stable terminal format.
def show(label: str, status: Status, detail: str = "") -> None:
    """
    OBJECTIVE:
    Display one colour-coded result because the operator must identify the
    current stack state quickly.

    TRACEABILITY:
    USER DEMAND:
    Print success in green and failure in red, with review when uncertain.

    AI-CONVERTED NEED:
    Convert a structured status into a consistent terminal line.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    label: Check name; status: Status enum; detail: Optional explanation.

    OUTPUTS:
    None; writes one terminal line.

    WORKFLOW:
    IN => [label, status, detail] -select colour/format-> [terminal line] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 display vocabulary.
    """
    colour = {
        Status.PASS: GREEN,
        Status.FAIL: RED,
        Status.REVIEW: YELLOW,
        Status.ERROR: RED,
        Status.SKIPPED: YELLOW,
        Status.BLOCKED: YELLOW,
    }.get(status, "")
    suffix = f" - {detail}" if detail else ""
    print(f"{colour}{label}: {status.value}{RESET}{suffix}")


def format_result_line(label: str, status: Status, width: int = 48) -> str:
    """
    OBJECTIVE:
    Produce the dotted report line because all three phase reports must use one
    readable note format.

    TRACEABILITY:
    USER DEMAND:
    Format results as TEST.....SUCCESS in the shared note.

    AI-CONVERTED NEED:
    Map internal statuses to fixed human-readable labels with dotted alignment.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    label: Report label; status: Internal status; width: Dotted field width.

    OUTPUTS:
    One formatted result line.

    WORKFLOW:
    IN => [label, status, width] -map/display/pad-> [formatted line] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Preserved the Program 2 report format.
    """
    return f"{label:.<{width}} {DISPLAY_STATUS[status]}"


def calculate_phase_status(checks: list[CheckResult]) -> Status:
    """
    OBJECTIVE:
    Calculate one Phase 3 outcome because the master framework needs a single
    result with deterministic precedence.

    TRACEABILITY:
    USER DEMAND:
    Mark the phase completed, failed or requiring review.

    AI-CONVERTED NEED:
    Reduce all non-skipped check statuses using a fixed worst-case order.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-024, TD-P3-025.

    INPUTS:
    checks: All Phase 3 CheckResult objects.

    OUTPUTS:
    Aggregate Status.

    WORKFLOW:
    IN => [check statuses] -ignore skipped/apply precedence-> [phase status] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused ERROR > FAIL > REVIEW > BLOCKED > PASS precedence.
    """
    statuses = {check.status for check in checks if check.status != Status.SKIPPED}
    if not statuses:
        return Status.SKIPPED
    if Status.ERROR in statuses:
        return Status.ERROR
    if Status.FAIL in statuses:
        return Status.FAIL
    if Status.REVIEW in statuses:
        return Status.REVIEW
    if Status.BLOCKED in statuses:
        return Status.BLOCKED
    return Status.PASS


def worst_status(*statuses: Status) -> Status:
    """
    OBJECTIVE:
    Combine automatic and human port judgements because neither should erase a
    more severe observed condition.

    TRACEABILITY:
    USER DEMAND:
    Inspect the binding and then ask whether it is within expectations.

    AI-CONVERTED NEED:
    Preserve the worse status when machine evidence and operator judgement are
    combined.

    REQUIREMENT CREATED:
    P3-PORT-001.

    TECHNICAL DECISIONS:
    TD-P3-013, TD-P3-016.

    INPUTS:
    One or more Status values.

    OUTPUTS:
    The highest-severity status.

    WORKFLOW:
    IN => [statuses] -rank severity-> [worst status] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Prevented a human Y from overriding an objectively missing serial device.
    """
    order = {
        Status.ERROR: 6,
        Status.FAIL: 5,
        Status.REVIEW: 4,
        Status.BLOCKED: 3,
        Status.PASS: 2,
        Status.SKIPPED: 1,
    }
    return max(statuses, key=lambda item: order[item])


# SECTION DECISION: Reconstruct the ROS environment inside every child shell.
def shell_command(workspace: Path, command: str) -> str:
    """
    OBJECTIVE:
    Build a ROS-aware shell command because each child process starts in a fresh
    shell that does not inherit prior source commands reliably.

    TRACEABILITY:
    USER DEMAND:
    Run source install/setup.bash before every documented ROS command.

    AI-CONVERTED NEED:
    Prepend ROS 2 Humble and workspace setup to each child command.

    REQUIREMENT CREATED:
    P3-ENV-001.

    TECHNICAL DECISIONS:
    TD-P3-008.

    INPUTS:
    workspace: Yahboom workspace; command: ROS or shell command.

    OUTPUTS:
    One bash command string.

    WORKFLOW:
    IN => [workspace, command] -add setup commands-> [ordered parts] -join with &&-> [shell command] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Centralised environment construction to avoid inconsistent shell setup.
    """
    parts = ["source /opt/ros/humble/setup.bash"]
    setup = workspace / "install" / "setup.bash"
    if setup.exists():
        parts.append(f"source {shlex.quote(str(setup))}")
    parts.append(command)
    return " && ".join(parts)


def run_command(
    workspace: Path,
    command: str,
    timeout: int,
) -> tuple[int, str]:
    """
    OBJECTIVE:
    Execute a bounded command and capture evidence because build and ROS graph
    queries must not hang the orchestration flow.

    TRACEABILITY:
    USER DEMAND:
    Run repeated setup/check commands automatically and record their output.

    AI-CONVERTED NEED:
    Use a synchronous subprocess with timeout and combined stdout/stderr.

    REQUIREMENT CREATED:
    P3-ENV-002 and P3-EVID-001.

    TECHNICAL DECISIONS:
    TD-P3-007, TD-P3-008.

    INPUTS:
    workspace: Execution directory; command: Shell command; timeout: Seconds.

    OUTPUTS:
    Return-code/output tuple; timeout returns code 124 with partial evidence.

    WORKFLOW:
    IN => [workspace, command, timeout] -prepare ROS shell/run-> [completed or timed out] -collect-> [code, output] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the bounded Program 2 command runner.
    """
    try:
        completed = subprocess.run(
            ["bash", "-lc", shell_command(workspace, command)],
            cwd=workspace,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        return completed.returncode, completed.stdout + completed.stderr
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        return 124, stdout + stderr

# SECTION DECISION: Own long-running ROS processes, logs and cleanup through one reusable abstraction.
class ManagedProcess:
    """
    OBJECTIVE:
    Manage one long-running ROS process because mapping and navigation require
    several concurrent processes with independent logs and reliable cleanup.

    TRACEABILITY:
    USER DEMAND:
    Run three programs at the same time and close them after the human check.

    AI-CONVERTED NEED:
    Start each process asynchronously, capture output continuously, observe
    startup state and stop only its owned process group.

    REQUIREMENT CREATED:
    P3-PROC-001, P3-PROC-002 and P3-PROC-003.

    TECHNICAL DECISIONS:
    TD-P3-007, TD-P3-009, TD-P3-010, TD-P3-011, TD-P3-019.

    INPUTS:
    Process name, workspace, command, log path and optional live echo flag.

    OUTPUTS:
    A lifecycle object exposing start, output, startup observation and stop.

    WORKFLOW:
    IN => [process configuration] -start session/read thread-> [live process]
       -observe/log-> [state] -signal escalation-> [clean process end] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the process-ownership model validated in Program 2.
    """

    def __init__(
        self,
        name: str,
        workspace: Path,
        command: str,
        log_path: Path,
        echo: bool = False,
    ) -> None:
        """
        OBJECTIVE:
        Store process configuration and lifecycle state because startup and
        cleanup must use the same ownership record.

        TRACEABILITY:
        USER DEMAND:
        Keep each terminal role distinguishable.

        AI-CONVERTED NEED:
        Assign a name, command and evidence path to each child process.

        REQUIREMENT CREATED:
        P3-PROC-001.

        TECHNICAL DECISIONS:
        TD-P3-004, TD-P3-009.

        INPUTS:
        name, workspace, command, log_path and echo flag.

        OUTPUTS:
        Initialised ManagedProcess with no process started.

        WORKFLOW:
        IN => [configuration] -store lifecycle fields-> [idle ManagedProcess] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Added explicit names matching the conceptual terminal roles.
        """
        self.name = name
        self.workspace = workspace
        self.command = command
        self.log_path = log_path
        self.echo = echo
        self.process: Optional[subprocess.Popen[str]] = None
        self._thread: Optional[threading.Thread] = None
        self._log_file: Optional[TextIO] = None
        self._lines: list[str] = []
        self._lock = threading.Lock()

    def start(self) -> None:
        """
        OBJECTIVE:
        Start the configured ROS command in an owned session because the caller
        must continue launching the other concurrent stack processes.

        TRACEABILITY:
        USER DEMAND:
        Run the three terminal commands at the same time.

        AI-CONVERTED NEED:
        Launch asynchronously and begin background output capture immediately.

        REQUIREMENT CREATED:
        P3-PROC-001.

        TECHNICAL DECISIONS:
        TD-P3-003, TD-P3-009, TD-P3-010.

        INPUTS:
        Stored process configuration.

        OUTPUTS:
        None; creates a live Popen process and output-reader thread.

        WORKFLOW:
        IN => [idle process configuration] -open log/Popen/new session-> [live process]
           -start reader thread-> [managed concurrent process] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Uses line-buffered evidence writing while the process remains active.
        """
        if self.process is not None:
            raise RuntimeError(f"{self.name} has already been started")

        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._log_file = self.log_path.open("w", encoding="utf-8", buffering=1)
        self._log_file.write(f"NAME={self.name}\n")
        self._log_file.write(f"STARTED_AT={now_iso()}\n")
        self._log_file.write(f"COMMAND={self.command}\n\n")

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"

        self.process = subprocess.Popen(
            ["bash", "-lc", shell_command(self.workspace, self.command)],
            cwd=self.workspace,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            start_new_session=True,
            bufsize=1,
        )

        self._thread = threading.Thread(
            target=self._read_output,
            name=f"{self.name}-reader",
            daemon=True,
        )
        self._thread.start()

    def _read_output(self) -> None:
        """
        OBJECTIVE:
        Drain and preserve process output because an unread pipe can block a
        verbose ROS process and erase diagnostic evidence.

        TRACEABILITY:
        USER DEMAND:
        Record each terminal process.

        AI-CONVERTED NEED:
        Read stdout continuously in a background thread and write it to disk.

        REQUIREMENT CREATED:
        P3-PROC-001.

        TECHNICAL DECISIONS:
        TD-P3-009.

        INPUTS:
        The live process stdout stream.

        OUTPUTS:
        None; appends output to memory and the evidence file.

        WORKFLOW:
        IN => [stdout stream] -read line-> [memory + file + optional echo]
           -repeat until EOF-> [closed evidence log] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Reused the non-blocking log reader from Program 2.
        """
        process = self.process
        if process is None or process.stdout is None:
            return

        try:
            for line in process.stdout:
                with self._lock:
                    self._lines.append(line)
                if self._log_file is not None:
                    self._log_file.write(line)
                if self.echo:
                    print(f"[{self.name}] {line}", end="")
        finally:
            if self._log_file is not None:
                self._log_file.write(f"\nENDED_AT={now_iso()}\n")
                self._log_file.flush()
                self._log_file.close()
                self._log_file = None

    def output(self) -> str:
        """
        OBJECTIVE:
        Return a thread-safe output snapshot because startup checks must inspect
        evidence while the background reader continues.

        TRACEABILITY:
        USER DEMAND:
        Determine whether the launched program is operating.

        AI-CONVERTED NEED:
        Expose current accumulated text without racing the reader thread.

        REQUIREMENT CREATED:
        P3-READY-001.

        TECHNICAL DECISIONS:
        TD-P3-009, TD-P3-012.

        INPUTS:
        Internal output buffer.

        OUTPUTS:
        Current combined process output as text.

        WORKFLOW:
        IN => [shared line buffer] -lock/copy/join-> [output snapshot] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Uses a lock to avoid inconsistent reads.
        """
        with self._lock:
            return "".join(self._lines)

    def is_running(self) -> bool:
        """
        OBJECTIVE:
        Report whether the child remains active because early process exit is a
        direct launch failure.

        TRACEABILITY:
        USER DEMAND:
        Check that each program operates while the three commands are active.

        AI-CONVERTED NEED:
        Query the Popen return state without blocking.

        REQUIREMENT CREATED:
        P3-READY-001.

        TECHNICAL DECISIONS:
        TD-P3-012.

        INPUTS:
        Managed process state.

        OUTPUTS:
        True when started and not exited; otherwise False.

        WORKFLOW:
        IN => [Popen state] -poll-> [running boolean] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Provides a simple readiness observation without inventing ROS semantics.
        """
        return self.process is not None and self.process.poll() is None

    def wait_for_state(
        self,
        ready_patterns: list[str],
        error_patterns: list[str],
        timeout: float,
    ) -> str:
        """
        OBJECTIVE:
        Observe bounded startup evidence because a launch should not be accepted
        immediately before it has had time to fail.

        TRACEABILITY:
        USER DEMAND:
        Run the programs and determine whether they appear operational.

        AI-CONVERTED NEED:
        Poll output and process state for fatal text, optional readiness text,
        early exit or continued survival.

        REQUIREMENT CREATED:
        P3-READY-001.

        TECHNICAL DECISIONS:
        TD-P3-012.

        INPUTS:
        ready_patterns, error_patterns and observation timeout.

        OUTPUTS:
        READY, ERROR_PATTERN, EXITED or RUNNING.

        WORKFLOW:
        IN => [process + patterns + timeout] -poll output/state-> [matched/exit/deadline]
           => [state label] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Leaves undocumented ROS interfaces to human review instead of guessing.
        """
        ready_regexes = [re.compile(pattern, re.IGNORECASE) for pattern in ready_patterns]
        error_regexes = [re.compile(pattern, re.IGNORECASE) for pattern in error_patterns]
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            text = self.output()
            if any(pattern.search(text) for pattern in error_regexes):
                return "ERROR_PATTERN"
            if ready_regexes and any(pattern.search(text) for pattern in ready_regexes):
                return "READY"
            if self.process is not None and self.process.poll() is not None:
                return "EXITED"
            time.sleep(0.1)

        if self.process is not None and self.process.poll() is not None:
            return "EXITED"
        return "RUNNING"

    def stop(self) -> None:
        """
        OBJECTIVE:
        Stop only this owned process group because each subphase must release
        shared resources without affecting unrelated ROS work.

        TRACEABILITY:
        USER DEMAND:
        Close the running terminals at the end of each stack check.

        AI-CONVERTED NEED:
        Attempt graceful group shutdown, escalate only when required, and join
        the output reader.

        REQUIREMENT CREATED:
        P3-PROC-001, P3-PROC-002 and P3-PROC-003.

        TECHNICAL DECISIONS:
        TD-P3-010, TD-P3-011, TD-P3-019.

        INPUTS:
        Managed process state.

        OUTPUTS:
        None; owned process group is stopped and reader thread is joined.

        WORKFLOW:
        IN => [owned live process] -SIGINT/wait-> [stopped or timeout]
           -SIGTERM/wait-> [stopped or timeout] -SIGKILL-> [closed process] => OUTPUT

        IMPROVEMENTS MADE:
        Initial implementation.

        REASON OF FAIL:
        N/A.

        IMPROVEMENT:
        Uses reverse-order cleanup at the orchestration level.
        """
        process = self.process
        if process is None:
            return

        if process.poll() is None:
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGINT)
            except ProcessLookupError:
                pass

            try:
                process.wait(timeout=4)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                except ProcessLookupError:
                    pass

                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    process.wait(timeout=2)

        if self._thread is not None:
            self._thread.join(timeout=2)


COMMON_ERROR_PATTERNS = [
    r"\bpermission denied\b",
    r"\bpackage ['\"]?.+['\"]? not found\b",
    r"\bexecutable ['\"]?.+['\"]? not found\b",
    r"\bfailed to open\b",
    r"\bcould not open\b",
    r"\bserial[^\n]*(?:fail|error|closed)\b",
    r"\btraceback \(most recent call last\)\b",
    r"\buncaught exception\b",
    r"\bprocess has died\b",
    r"\b[Ff][Aa][Tt][Aa][Ll]\b",
]

# SECTION DECISION: Inspect the filesystem object directly and preserve the human port review requested by the source.
def inspect_serial_path(
    path: Path,
    check_id: str,
    label: str,
    evidence_file: TextIO,
    require_symlink: bool = True,
) -> CheckResult:
    """
    OBJECTIVE:
    Inspect one serial alias and resolved device because the stack should not
    begin from an invalid or missing USB binding.

    TRACEABILITY:
    USER DEMAND:
    Run ll /dev | grep ttyUSB*, inspect myserial/rplidar and decide whether the
    binding is within expectations.

    AI-CONVERTED NEED:
    Validate the alias, ttyUSB target, character-device type and metadata using
    stable filesystem APIs while saving equivalent evidence.

    REQUIREMENT CREATED:
    P3-PORT-001.

    TECHNICAL DECISIONS:
    TD-P3-016.

    INPUTS:
    path, check identifier, display label, evidence stream and symlink policy.

    OUTPUTS:
    CheckResult with PASS, REVIEW or FAIL.

    WORKFLOW:
    IN => [serial path] -exist/symlink/resolve-> [target]
       -inspect type/name/owner/group/major-> [status + evidence] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 structural USB check.
    """
    evidence_file.write(f"\n[{check_id}]\nPATH={path}\n")

    if not os.path.lexists(path):
        detail = f"{path} does not exist"
        evidence_file.write(f"RESULT={detail}\n")
        return CheckResult(check_id, label, Status.FAIL, detail)

    is_symlink = path.is_symlink()
    if require_symlink and not is_symlink:
        detail = f"{path} exists but is not a symbolic link"
        evidence_file.write(f"RESULT={detail}\n")
        return CheckResult(check_id, label, Status.FAIL, detail)

    try:
        link_stat = path.lstat()
        target = path.resolve(strict=True)
        target_stat = target.stat()
    except OSError as exc:
        detail = f"Unable to resolve {path}: {exc}"
        evidence_file.write(f"RESULT={detail}\n")
        return CheckResult(check_id, label, Status.FAIL, detail)

    link_owner = safe_username(link_stat.st_uid)
    target_owner = safe_username(target_stat.st_uid)
    target_group = safe_groupname(target_stat.st_gid)
    is_character = stat.S_ISCHR(target_stat.st_mode)
    target_is_ttyusb = bool(re.fullmatch(r"ttyUSB\d+", target.name))
    major_number = os.major(target_stat.st_rdev) if is_character else None

    evidence_file.write(f"IS_SYMLINK={is_symlink}\n")
    evidence_file.write(f"LINK_OWNER={link_owner}\n")
    evidence_file.write(f"TARGET={target}\n")
    evidence_file.write(f"TARGET_OWNER={target_owner}\n")
    evidence_file.write(f"TARGET_GROUP={target_group}\n")
    evidence_file.write(f"TARGET_IS_CHARACTER_DEVICE={is_character}\n")
    evidence_file.write(f"TARGET_IS_TTYUSB={target_is_ttyusb}\n")
    evidence_file.write(f"MAJOR_NUMBER={major_number}\n")

    critical_ok = is_character and target_is_ttyusb
    metadata_ok = (
        link_owner == "root"
        and target_owner == "root"
        and target_group == "dialout"
        and major_number == 188
    )

    if not critical_ok:
        detail = f"{path} -> {target.name}; target is not a valid ttyUSB character device"
        status_value = Status.FAIL
    elif not metadata_ok:
        detail = (
            f"{path} -> {target.name}; structurally valid, "
            f"but metadata differs from root:dialout major 188"
        )
        status_value = Status.REVIEW
    else:
        detail = f"{path} -> {target.name} (root:dialout, major 188)"
        status_value = Status.PASS

    evidence_file.write(f"STATUS={status_value.value}\nDETAIL={detail}\n")
    return CheckResult(check_id, label, status_value, detail)


def find_device_users(paths: list[Path]) -> dict[str, list[str]]:
    """
    OBJECTIVE:
    Identify processes holding serial devices because navigation should not
    start while mapping or an external process still owns the same port.

    TRACEABILITY:
    USER DEMAND:
    Close the prior stack before running the next set of programs.

    AI-CONVERTED NEED:
    Inspect /proc file descriptors using only the standard library and report
    users without killing external processes.

    REQUIREMENT CREATED:
    P3-SERIAL-001 and P3-PROC-003.

    TECHNICAL DECISIONS:
    TD-P3-018, TD-P3-019.

    INPUTS:
    paths: Serial aliases or concrete device paths.

    OUTPUTS:
    Mapping from resolved device path to process-description strings.

    WORKFLOW:
    IN => [device paths] -resolve-> [targets] -scan /proc/*/fd-> [matching PIDs]
       -read cmdline-> [device users] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 /proc strategy without adding lsof or fuser.
    """
    targets: dict[str, Path] = {}
    for path in paths:
        try:
            targets[str(path.resolve(strict=True))] = path
        except OSError:
            continue

    users: dict[str, list[str]] = {target: [] for target in targets}

    proc_root = Path("/proc")
    for proc_dir in proc_root.iterdir():
        if not proc_dir.name.isdigit():
            continue
        fd_dir = proc_dir / "fd"
        try:
            fd_entries = list(fd_dir.iterdir())
        except (OSError, PermissionError):
            continue

        matched_targets: set[str] = set()
        for fd in fd_entries:
            try:
                linked = str(fd.resolve(strict=True))
            except (OSError, PermissionError):
                continue
            if linked in users:
                matched_targets.add(linked)

        if not matched_targets:
            continue

        try:
            cmdline_raw = (proc_dir / "cmdline").read_bytes()
            cmdline = cmdline_raw.replace(b"\x00", b" ").decode(errors="replace").strip()
        except (OSError, PermissionError):
            cmdline = ""
        description = f"pid={proc_dir.name} command={cmdline or '[unavailable]'}"
        for target in matched_targets:
            users[target].append(description)

    return users


def check_serial_release(paths: list[Path], evidence_path: Path) -> CheckResult:
    """
    OBJECTIVE:
    Verify serial release after mapping because the navigation bring-up must
    begin from a clean device state.

    TRACEABILITY:
    USER DEMAND:
    Close the mapping terminals before running the navigation commands.

    AI-CONVERTED NEED:
    Confirm that no remaining process holds myserial or rplidar after cleanup.

    REQUIREMENT CREATED:
    P3-SERIAL-001.

    TECHNICAL DECISIONS:
    TD-P3-018, TD-P3-019.

    INPUTS:
    paths: Devices to inspect; evidence_path: Output log.

    OUTPUTS:
    PASS when no users remain, BLOCKED when a device is still held, REVIEW when
    no path can be resolved.

    WORKFLOW:
    IN => [serial paths] -scan users-> [usage map] -classify/log-> [CheckResult] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added a concrete transition gate between the two subphases.
    """
    usage = find_device_users(paths)
    lines = [f"TIME={now_iso()}"]
    held: list[str] = []

    for target, process_list in usage.items():
        lines.append(f"\nDEVICE={target}")
        if process_list:
            held.append(target)
            lines.extend(process_list)
        else:
            lines.append("USERS=NONE")

    evidence_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    if not usage:
        return CheckResult(
            "SERIAL_RELEASE_BEFORE_NAV",
            "SERIAL RELEASE BEFORE NAVIGATION",
            Status.REVIEW,
            "No serial path could be resolved for release inspection",
            str(evidence_path),
        )
    if held:
        return CheckResult(
            "SERIAL_RELEASE_BEFORE_NAV",
            "SERIAL RELEASE BEFORE NAVIGATION",
            Status.BLOCKED,
            f"Serial device still held: {', '.join(held)}",
            str(evidence_path),
        )
    return CheckResult(
        "SERIAL_RELEASE_BEFORE_NAV",
        "SERIAL RELEASE BEFORE NAVIGATION",
        Status.PASS,
        "No process holds the resolved serial devices",
        str(evidence_path),
    )


# SECTION DECISION: Keep completion input separate from the operator's functional judgement.
def ask_ynu(prompt: str) -> tuple[Status, str]:
    """
    OBJECTIVE:
    Obtain the human good-to-go judgement because RViz interpretation remains
    an operator responsibility.

    TRACEABILITY:
    USER DEMAND:
    Ask whether the mapping or navigation stack is good to go using Y/N/U.

    AI-CONVERTED NEED:
    Validate one of three explicit inputs and map it to PASS/FAIL/REVIEW.

    REQUIREMENT CREATED:
    P3-MAP-003 and P3-NAV-003.

    TECHNICAL DECISIONS:
    TD-P3-013, TD-P3-014.

    INPUTS:
    prompt: Human question displayed in the checker terminal.

    OUTPUTS:
    Tuple of mapped Status and original normalised answer.

    WORKFLOW:
    IN => [prompt] -read/normalise-> [Y/N/U] -map-> [status, answer] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Preserved the Program 2 human judgement contract.
    """
    mapping = {
        "Y": Status.PASS,
        "N": Status.FAIL,
        "U": Status.REVIEW,
    }

    while True:
        answer = input(prompt).strip().upper()
        if answer in mapping:
            return mapping[answer], answer
        print("Please enter Y, N or U.")


def wait_for_q(prompt: str) -> None:
    """
    OBJECTIVE:
    Pause navigation observation until the operator explicitly finishes because
    visual review time cannot be predetermined.

    TRACEABILITY:
    USER DEMAND:
    The user checks RViz and presses q once done.

    AI-CONVERTED NEED:
    Provide a manual completion gate distinct from the Y/N/U judgement.

    REQUIREMENT CREATED:
    P3-NAV-002.

    TECHNICAL DECISIONS:
    TD-P3-014.

    INPUTS:
    prompt: Checker-terminal instruction.

    OUTPUTS:
    None; returns only after normalised input equals q.

    WORKFLOW:
    IN => [prompt] -read/normalise-> [operator input] -validate q-> [repeat or return] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the explicit q gate from Program 2.
    """
    while True:
        answer = input(prompt).strip().lower()
        if answer == "q":
            return
        print("Enter q when the review is complete.")


def run_interactive_keyboard(
    workspace: Path,
    command: str,
    metadata_path: Path,
) -> tuple[int, float]:
    """
    OBJECTIVE:
    Run the mapping keyboard controller in the current terminal because the
    operator must move the robot while Cartographer and RViz remain active.

    TRACEABILITY:
    USER DEMAND:
    Run yahboom_keyboard as the third mapping terminal and press q when done.

    AI-CONVERTED NEED:
    Let the child inherit the real terminal, block until it exits, and record
    session metadata without adding a third-party pseudo-terminal library.

    REQUIREMENT CREATED:
    P3-MAP-001 and P3-MAP-002.

    TECHNICAL DECISIONS:
    TD-P3-003, TD-P3-015.

    INPUTS:
    workspace, keyboard command and metadata log path.

    OUTPUTS:
    Keyboard return code and elapsed duration.

    WORKFLOW:
    IN => [workspace, command] -run in current terminal-> [human control/q exit]
       -record metadata-> [return code, duration] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 zero-third-party interactive approach.
    """
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    started_at = now_iso()
    return_code = 1

    print(f"\n{CYAN}Mapping keyboard control is now active.{RESET}")
    print("Operate the robot carefully while observing RViz.")
    print("Press q inside the keyboard controller when the mapping review is complete.\n")

    try:
        completed = subprocess.run(
            ["bash", "-lc", shell_command(workspace, command)],
            cwd=workspace,
            check=False,
        )
        return_code = completed.returncode
    except KeyboardInterrupt:
        return_code = 130
        print("\nKeyboard controller interrupted.")

    duration = time.monotonic() - started
    metadata_path.write_text(
        "\n".join(
            [
                f"STARTED_AT={started_at}",
                f"ENDED_AT={now_iso()}",
                f"COMMAND={command}",
                f"RETURN_CODE={return_code}",
                f"DURATION_SECONDS={duration:.2f}",
                "NOTE=Interactive terminal output was displayed directly and was not captured.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return return_code, duration

def write_command_log(path: Path, command: str, code: int, output: str) -> None:
    """
    OBJECTIVE:
    Save bounded command evidence because build and ROS graph queries must be
    inspectable after the run.

    TRACEABILITY:
    USER DEMAND:
    Record the terminal process.

    AI-CONVERTED NEED:
    Preserve command, return code and raw output in one evidence file.

    REQUIREMENT CREATED:
    P3-EVID-001 and P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-020, TD-P3-023.

    INPUTS:
    File path, command, return code and output.

    OUTPUTS:
    None; writes the evidence file.

    WORKFLOW:
    IN => [command result] -format/write-> [evidence file] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Standardised bounded-command evidence formatting.
    """
    path.write_text(
        f"COMMAND={command}\nRETURN_CODE={code}\n\n{output}",
        encoding="utf-8",
    )


def collect_ros_snapshot(workspace: Path, path: Path) -> None:
    """
    OBJECTIVE:
    Capture the current ROS graph as supporting evidence because the source
    requests operational confirmation but does not define an interface whitelist.

    TRACEABILITY:
    USER DEMAND:
    Record what is running while the stack is active.

    AI-CONVERTED NEED:
    Save node and topic lists without converting undocumented names into
    mandatory acceptance criteria.

    REQUIREMENT CREATED:
    P3-EVID-001.

    TECHNICAL DECISIONS:
    TD-P3-020.

    INPUTS:
    workspace and evidence file path.

    OUTPUTS:
    None; writes node-list and topic-list command results.

    WORKFLOW:
    IN => [active ROS graph] -ros2 node/topic list-> [outputs] -write-> [snapshot] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added evidence without inventing unsupported readiness requirements.
    """
    node_code, node_output = run_command(workspace, "ros2 node list", timeout=10)
    topic_code, topic_output = run_command(workspace, "ros2 topic list", timeout=10)
    path.write_text(
        "\n".join(
            [
                f"TIME={now_iso()}",
                "",
                "[ROS2 NODE LIST]",
                f"RETURN_CODE={node_code}",
                node_output,
                "",
                "[ROS2 TOPIC LIST]",
                f"RETURN_CODE={topic_code}",
                topic_output,
            ]
        ),
        encoding="utf-8",
    )


def evaluate_launch(
    process: ManagedProcess,
    check_id: str,
    label: str,
    timeout: float,
) -> CheckResult:
    """
    OBJECTIVE:
    Classify one launch startup because every member of the three-process stack
    must remain active long enough for human review.

    TRACEABILITY:
    USER DEMAND:
    Run the corresponding code at the same time and check whether it operates.

    AI-CONVERTED NEED:
    Observe early exit and fatal patterns while treating continued survival as
    limited software evidence.

    REQUIREMENT CREATED:
    P3-READY-001.

    TECHNICAL DECISIONS:
    TD-P3-012, TD-P3-013.

    INPUTS:
    Managed process, check ID, label and observation timeout.

    OUTPUTS:
    CheckResult for the software launch state.

    WORKFLOW:
    IN => [started process] -observe output/state-> [RUNNING/ERROR/EXIT]
       -classify-> [CheckResult] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Avoids claiming physical success from process survival.
    """
    state = process.wait_for_state(
        ready_patterns=[],
        error_patterns=COMMON_ERROR_PATTERNS,
        timeout=timeout,
    )

    if state == "RUNNING":
        status_value = Status.PASS
        detail = "Process remained active without a detected fatal error"
    elif state == "ERROR_PATTERN":
        status_value = Status.FAIL
        detail = "Process output contains a fatal error pattern"
    else:
        status_value = Status.FAIL
        detail = "Process exited during startup observation"

    return CheckResult(
        check_id,
        label,
        status_value,
        detail,
        str(process.log_path),
    )


def block_check(check_id: str, label: str, reason: str) -> CheckResult:
    """
    OBJECTIVE:
    Record a dependency block because an unexecuted check must not disappear
    from the report or be mistaken for success.

    TRACEABILITY:
    USER DEMAND:
    Run each stack in the correct order.

    AI-CONVERTED NEED:
    Preserve skipped dependent checks with an explicit reason.

    REQUIREMENT CREATED:
    P3-PROC-001 and P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-025.

    INPUTS:
    Check ID, label and blocking reason.

    OUTPUTS:
    BLOCKED CheckResult.

    WORKFLOW:
    IN => [dependent check + failed prerequisite] -record reason-> [BLOCKED result] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 dependency record.
    """
    return CheckResult(check_id, label, Status.BLOCKED, reason)


def skip_check(check_id: str, label: str, reason: str) -> CheckResult:
    """
    OBJECTIVE:
    Record an intentional skip because CLI-selected scope must remain visible in
    the final report.

    TRACEABILITY:
    USER DEMAND:
    Support quick isolated checking when needed.

    AI-CONVERTED NEED:
    Distinguish deliberate omission from failure or blocking.

    REQUIREMENT CREATED:
    P3-FRAMEWORK-001.

    TECHNICAL DECISIONS:
    TD-P3-022, TD-P3-023.

    INPUTS:
    Check ID, label and skip reason.

    OUTPUTS:
    SKIPPED CheckResult.

    WORKFLOW:
    IN => [intentionally omitted check] -record reason-> [SKIPPED result] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Preserved Program 2 CLI/report semantics.
    """
    return CheckResult(check_id, label, Status.SKIPPED, reason)


def phase_result_to_dict(result: PhaseResult) -> dict[str, object]:
    """
    OBJECTIVE:
    Convert enums and dataclasses into JSON-safe values because the master
    framework cannot consume Python objects directly.

    TRACEABILITY:
    USER DEMAND:
    Put all phases into one framework and common note.

    AI-CONVERTED NEED:
    Serialise Program 3 using the same contract as Program 2.

    REQUIREMENT CREATED:
    P3-REPORT-001 and P3-FRAMEWORK-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    PhaseResult.

    OUTPUTS:
    JSON-serialisable dictionary.

    WORKFLOW:
    IN => [PhaseResult] -asdict/enum conversion-> [plain dictionary] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 JSON transformation.
    """
    data = asdict(result)
    data["status"] = result.status.value
    for check_data, check in zip(data["checks"], result.checks):
        check_data["status"] = check.status.value
    return data


def build_phase_text(result: PhaseResult, include_raw_evidence: bool = True) -> str:
    """
    OBJECTIVE:
    Build the shared-note-compatible Phase 3 text because the operator requires
    dotted result lines and an explicit phase conclusion.

    TRACEABILITY:
    USER DEMAND:
    Use the same report format as Program 2.

    AI-CONVERTED NEED:
    Present ordered checks, final phase status and raw evidence metadata.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    PhaseResult and evidence-inclusion flag.

    OUTPUTS:
    Formatted Phase 3 report text.

    WORKFLOW:
    IN => [PhaseResult] -format checks/status/evidence-> [report string] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Preserved the Phase 2 note contract while adding mapping/navigation groups.
    """
    lines = [
        f"[PHASE {result.phase_number}/{result.phase_total}: {result.phase_name}]",
        "",
    ]

    mapping_started = False
    navigation_started = False
    for check in result.checks:
        if check.check_id == "CARTOGRAPHER_LAUNCH" and not mapping_started:
            lines.extend(["", "--- CARTOGRAPHER MAPPING SUBPHASE ---"])
            mapping_started = True
        if check.check_id == "SERIAL_RELEASE_BEFORE_NAV" and not navigation_started:
            lines.extend(["", "--- NAVIGATION SUBPHASE ---"])
            navigation_started = True
        lines.append(format_result_line(check.label, check.status))

    lines.append("")
    phase_display = {
        Status.PASS: f"PHASE {result.phase_number}: COMPLETED",
        Status.FAIL: f"PHASE {result.phase_number}: FAILED",
        Status.REVIEW: f"PHASE {result.phase_number}: REVIEW REQUIRED",
        Status.ERROR: f"PHASE {result.phase_number}: PROGRAM ERROR",
        Status.BLOCKED: f"PHASE {result.phase_number}: BLOCKED",
        Status.SKIPPED: f"PHASE {result.phase_number}: SKIPPED",
    }[result.status]
    lines.extend([phase_display, "", f"(END OF PHASE {result.phase_number})", ""])

    if include_raw_evidence:
        lines.extend(
            [
                "=" * 72,
                f"RAW EVIDENCE — PHASE {result.phase_number}",
                "=" * 72,
                "",
            ]
        )
        for check in result.checks:
            lines.append(f"[{check.check_id}]")
            lines.append(f"STATUS={check.status.value}")
            if check.detail:
                lines.append(f"DETAIL={check.detail}")
            if check.human_input:
                lines.append(f"HUMAN_INPUT={check.human_input}")
            if check.evidence:
                lines.append(f"EVIDENCE={check.evidence}")
            lines.append("")

        lines.append("EVIDENCE FILES")
        for evidence in result.evidence_files:
            lines.append(evidence)
        lines.append("")

    return "\n".join(lines)


def open_report(path: Path) -> None:
    """
    OBJECTIVE:
    Open the completed report because automatic judgements must remain easy for
    the operator to inspect.

    TRACEABILITY:
    USER DEMAND:
    Review the collected note after each run.

    AI-CONVERTED NEED:
    Launch the default desktop viewer without blocking the checker.

    REQUIREMENT CREATED:
    P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023.

    INPUTS:
    Report file path.

    OUTPUTS:
    None; opens a viewer or prints REVIEW on error.

    WORKFLOW:
    IN => [report path] -xdg-open new session-> [viewer or warning] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Reused the Program 2 report-opening behaviour.
    """
    try:
        subprocess.Popen(
            ["xdg-open", str(path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        show("OPEN_REPORT", Status.REVIEW, str(exc))

# SECTION DECISION: Orchestrate two sequential three-process integration checks with human acceptance gates.
def run_phase(args: argparse.Namespace) -> tuple[PhaseResult, Path, Path]:
    """
    OBJECTIVE:
    Execute the complete Phase 3 workflow because mapping and navigation must be
    checked repeatably with common evidence, human judgement and cleanup.

    TRACEABILITY:
    USER DEMAND:
    Generate Program 3 in the same format as Program 2, with three commands
    running concurrently and the human deciding from RViz whether each is good
    to go.

    AI-CONVERTED NEED:
    Prepare paths, verify prerequisites, run Mapping, clean it up, verify serial
    release, run Navigation, clean it up, and write JSON/report outputs.

    REQUIREMENT CREATED:
    P3-ENV-001 through P3-SCOPE-001.

    TECHNICAL DECISIONS:
    TD-P3-001 through TD-P3-025.

    INPUTS:
    Parsed CLI namespace.

    OUTPUTS:
    PhaseResult, JSON result path and Phase report path.

    WORKFLOW:
    IN => [CLI configuration] -prechecks/build-> [mapping three-process stack]
       -human judgement/cleanup-> [serial release]
       -navigation three-process stack/human judgement/cleanup->
       [JSON + report] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A — no Program 3 hardware run has yet been recorded.

    IMPROVEMENT:
    Implements the clarified no-map-save/no-goal operational scope.
    """
    started_at = now_iso()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    workspace = args.workspace.expanduser().resolve()

    run_dir = args.result_root.expanduser() / args.robot_id / f"{timestamp}_phase3"
    run_dir.mkdir(parents=True, exist_ok=True)

    port_log = run_dir / "port_binding.log"
    build_log = run_dir / "workspace_build.log"
    cartographer_log = run_dir / "cartographer.log"
    map_rviz_log = run_dir / "map_rviz.log"
    keyboard_log = run_dir / "mapping_keyboard_session.log"
    mapping_graph_log = run_dir / "mapping_ros_graph.log"
    serial_release_log = run_dir / "serial_release_before_navigation.log"
    laser_bringup_log = run_dir / "laser_odom_bringup.log"
    nav_rviz_log = run_dir / "navigation_rviz.log"
    dwa_log = run_dir / "dwa_navigation.log"
    navigation_graph_log = run_dir / "navigation_ros_graph.log"

    result_json = args.result_json.expanduser() if args.result_json else run_dir / "phase3_result.json"
    phase_report = run_dir / "phase3_report.txt"

    checks: list[CheckResult] = []
    evidence_files: list[str] = []
    active_processes: list[ManagedProcess] = []

    if args.dry_run:
        checks.extend(
            [
                CheckResult(
                    "PROGRAM_INTERFACE",
                    "PROGRAM INTERFACE",
                    Status.PASS,
                    "Dry-run interface completed",
                ),
                CheckResult(
                    "DRY_RUN_MODE",
                    "HARDWARE EXECUTION",
                    Status.REVIEW,
                    "Dry run did not validate the physical robot or RViz",
                ),
                skip_check("WORKSPACE_EXISTS", "YAHBOOM WORKSPACE", "Dry run"),
                skip_check("USB_MYSERIAL", "MOTOR SERIAL LINK", "Dry run"),
                skip_check("USB_RPLIDAR", "LIDAR SERIAL LINK", "Dry run"),
                skip_check("PORT_BINDING_REVIEW", "PORT BINDING REVIEW", "Dry run"),
                skip_check("WORKSPACE_BUILD", "WORKSPACE BUILD", "Dry run"),
                skip_check("CARTOGRAPHER_LAUNCH", "CARTOGRAPHER LAUNCH", "Dry run"),
                skip_check("MAP_RVIZ_DISPLAY", "MAP RVIZ DISPLAY", "Dry run"),
                skip_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Dry run"),
                skip_check("MAPPING_STACK_OPERATION", "MAPPING STACK OPERATION", "Dry run"),
                skip_check(
                    "SERIAL_RELEASE_BEFORE_NAV",
                    "SERIAL RELEASE BEFORE NAVIGATION",
                    "Dry run",
                ),
                skip_check("LASER_ODOM_BRINGUP", "LASER / ODOM BRINGUP", "Dry run"),
                skip_check("NAV_RVIZ_DISPLAY", "NAVIGATION RVIZ DISPLAY", "Dry run"),
                skip_check("DWA_NAVIGATION_LAUNCH", "DWA NAVIGATION LAUNCH", "Dry run"),
                skip_check(
                    "NAVIGATION_STACK_OPERATION",
                    "NAVIGATION STACK OPERATION",
                    "Dry run",
                ),
            ]
        )
    else:
        # ----------------------------- Environment and port checks -----------------------------
        workspace_ok = workspace.exists()
        checks.append(
            CheckResult(
                "WORKSPACE_EXISTS",
                "YAHBOOM WORKSPACE",
                Status.PASS if workspace_ok else Status.FAIL,
                str(workspace) if workspace_ok else f"Workspace not found: {workspace}",
            )
        )
        show(
            "WORKSPACE_EXISTS",
            Status.PASS if workspace_ok else Status.FAIL,
            str(workspace),
        )

        with port_log.open("w", encoding="utf-8") as port_evidence:
            port_evidence.write(f"ROBOT_ID={args.robot_id}\nTIME={now_iso()}\n")
            myserial_result = inspect_serial_path(
                Path("/dev/myserial"),
                "USB_MYSERIAL",
                "MOTOR SERIAL LINK",
                port_evidence,
            )
            rplidar_result = inspect_serial_path(
                Path("/dev/rplidar"),
                "USB_RPLIDAR",
                "LIDAR SERIAL LINK",
                port_evidence,
            )

        evidence_files.append(str(port_log))
        myserial_result.evidence = str(port_log)
        rplidar_result.evidence = str(port_log)
        checks.extend([myserial_result, rplidar_result])
        show(myserial_result.check_id, myserial_result.status, myserial_result.detail)
        show(rplidar_result.check_id, rplidar_result.status, rplidar_result.detail)

        print(
            f"\n{CYAN}Port binding evidence is shown above. "
            f"Pausing {args.port_review_seconds:.1f} seconds for inspection...{RESET}"
        )
        time.sleep(max(0.0, args.port_review_seconds))
        port_human_status, port_human_input = ask_ynu(
            "Is the port binding within expectations [Y/N/U]? "
        )
        port_auto_status = worst_status(myserial_result.status, rplidar_result.status)
        port_combined = worst_status(port_auto_status, port_human_status)
        port_detail = (
            f"Automatic={port_auto_status.value}; "
            f"operator={port_human_input}"
        )
        port_review = CheckResult(
            "PORT_BINDING_REVIEW",
            "PORT BINDING REVIEW",
            port_combined,
            port_detail,
            str(port_log),
            port_human_input,
        )
        checks.append(port_review)
        show(port_review.check_id, port_review.status, port_review.detail)

        if not workspace_ok:
            checks.append(block_check("WORKSPACE_BUILD", "WORKSPACE BUILD", "Workspace missing"))
            build_ok = False
        elif args.skip_build:
            checks.append(skip_check("WORKSPACE_BUILD", "WORKSPACE BUILD", "--skip-build used"))
            build_ok = True
        else:
            build_command = "colcon build --symlink-install"
            print(f"\n{CYAN}Building workspace: {workspace}{RESET}")
            code, output = run_command(workspace, build_command, args.build_timeout)
            write_command_log(build_log, build_command, code, output)
            evidence_files.append(str(build_log))

            if code == 0:
                build_status = Status.PASS
                build_detail = "colcon build completed successfully"
                build_ok = True
            elif code == 124:
                build_status = Status.ERROR
                build_detail = f"colcon build exceeded {args.build_timeout} seconds"
                build_ok = False
            else:
                build_status = Status.FAIL
                build_detail = f"colcon build returned code {code}"
                build_ok = False

            build_result = CheckResult(
                "WORKSPACE_BUILD",
                "WORKSPACE BUILD",
                build_status,
                build_detail,
                str(build_log),
            )
            checks.append(build_result)
            show(build_result.check_id, build_result.status, build_result.detail)

        port_usable = port_review.status not in {
            Status.FAIL,
            Status.ERROR,
            Status.BLOCKED,
        }

        # ----------------------------- Mapping subphase -----------------------------
        if args.skip_mapping:
            checks.extend(
                [
                    skip_check("CARTOGRAPHER_LAUNCH", "CARTOGRAPHER LAUNCH", "--skip-mapping used"),
                    skip_check("MAP_RVIZ_DISPLAY", "MAP RVIZ DISPLAY", "--skip-mapping used"),
                    skip_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "--skip-mapping used"),
                    skip_check(
                        "MAPPING_STACK_OPERATION",
                        "MAPPING STACK OPERATION",
                        "--skip-mapping used",
                    ),
                ]
            )
        elif not build_ok:
            checks.extend(
                [
                    block_check("CARTOGRAPHER_LAUNCH", "CARTOGRAPHER LAUNCH", "Workspace build unavailable"),
                    block_check("MAP_RVIZ_DISPLAY", "MAP RVIZ DISPLAY", "Cartographer unavailable"),
                    block_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Mapping stack unavailable"),
                    block_check(
                        "MAPPING_STACK_OPERATION",
                        "MAPPING STACK OPERATION",
                        "Mapping stack unavailable",
                    ),
                ]
            )
        elif not port_usable:
            checks.extend(
                [
                    block_check("CARTOGRAPHER_LAUNCH", "CARTOGRAPHER LAUNCH", "Port binding failed"),
                    block_check("MAP_RVIZ_DISPLAY", "MAP RVIZ DISPLAY", "Cartographer unavailable"),
                    block_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Mapping stack unavailable"),
                    block_check(
                        "MAPPING_STACK_OPERATION",
                        "MAPPING STACK OPERATION",
                        "Mapping stack unavailable",
                    ),
                ]
            )
        else:
            cartographer = ManagedProcess(
                "cartographer",
                workspace,
                args.cartographer_command,
                cartographer_log,
                echo=args.echo_process_output,
            )
            map_rviz = ManagedProcess(
                "map-rviz",
                workspace,
                args.map_rviz_command,
                map_rviz_log,
                echo=args.echo_process_output,
            )

            try:
                print(f"\n{CYAN}Starting Cartographer mapping launch...{RESET}")
                cartographer.start()
                active_processes.append(cartographer)
                cartographer_result = evaluate_launch(
                    cartographer,
                    "CARTOGRAPHER_LAUNCH",
                    "CARTOGRAPHER LAUNCH",
                    args.startup_timeout,
                )
                checks.append(cartographer_result)
                evidence_files.append(str(cartographer_log))
                show(
                    cartographer_result.check_id,
                    cartographer_result.status,
                    cartographer_result.detail,
                )

                if cartographer_result.status == Status.FAIL:
                    checks.extend(
                        [
                            block_check("MAP_RVIZ_DISPLAY", "MAP RVIZ DISPLAY", "Cartographer launch failed"),
                            block_check("KEYBOARD_CONTROLLER", "KEYBOARD CONTROLLER", "Cartographer launch failed"),
                            block_check(
                                "MAPPING_STACK_OPERATION",
                                "MAPPING STACK OPERATION",
                                "Cartographer launch failed",
                            ),
                        ]
                    )
                else:
                    print(f"\n{CYAN}Starting mapping RViz...{RESET}")
                    map_rviz.start()
                    active_processes.append(map_rviz)
                    map_rviz_result = evaluate_launch(
                        map_rviz,
                        "MAP_RVIZ_DISPLAY",
                        "MAP RVIZ DISPLAY",
                        args.startup_timeout,
                    )
                    checks.append(map_rviz_result)
                    evidence_files.append(str(map_rviz_log))
                    show(
                        map_rviz_result.check_id,
                        map_rviz_result.status,
                        map_rviz_result.detail,
                    )

                    if map_rviz_result.status == Status.FAIL:
                        checks.extend(
                            [
                                block_check(
                                    "KEYBOARD_CONTROLLER",
                                    "KEYBOARD CONTROLLER",
                                    "Mapping RViz failed",
                                ),
                                block_check(
                                    "MAPPING_STACK_OPERATION",
                                    "MAPPING STACK OPERATION",
                                    "Mapping RViz failed",
                                ),
                            ]
                        )
                    else:
                        collect_ros_snapshot(workspace, mapping_graph_log)
                        evidence_files.append(str(mapping_graph_log))

                        keyboard_code, keyboard_duration = run_interactive_keyboard(
                            workspace,
                            args.keyboard_command,
                            keyboard_log,
                        )
                        evidence_files.append(str(keyboard_log))

                        if keyboard_code == 0:
                            keyboard_status = Status.PASS
                            keyboard_detail = "Keyboard controller exited normally after operator q"
                        elif keyboard_duration < 2.0:
                            keyboard_status = Status.FAIL
                            keyboard_detail = (
                                f"Keyboard controller exited quickly with code {keyboard_code}"
                            )
                        else:
                            keyboard_status = Status.REVIEW
                            keyboard_detail = (
                                f"Keyboard controller ended with code {keyboard_code}; review session"
                            )

                        keyboard_result = CheckResult(
                            "KEYBOARD_CONTROLLER",
                            "KEYBOARD CONTROLLER",
                            keyboard_status,
                            keyboard_detail,
                            str(keyboard_log),
                        )
                        checks.append(keyboard_result)
                        show(
                            keyboard_result.check_id,
                            keyboard_result.status,
                            keyboard_result.detail,
                        )

                        if keyboard_status == Status.FAIL:
                            checks.append(
                                block_check(
                                    "MAPPING_STACK_OPERATION",
                                    "MAPPING STACK OPERATION",
                                    "Keyboard controller failed before a valid observation",
                                )
                            )
                        else:
                            mapping_status, mapping_input = ask_ynu(
                                "Is the mapping stack good to go [Y/N/U]? "
                            )
                            mapping_detail = {
                                Status.PASS: "Operator confirmed Cartographer, RViz and keyboard operation",
                                Status.FAIL: "Operator reported the mapping stack is not good to go",
                                Status.REVIEW: "Operator requested further mapping-stack review",
                            }[mapping_status]
                            mapping_result = CheckResult(
                                "MAPPING_STACK_OPERATION",
                                "MAPPING STACK OPERATION",
                                mapping_status,
                                mapping_detail,
                                str(mapping_graph_log),
                                mapping_input,
                            )
                            checks.append(mapping_result)
                            show(
                                mapping_result.check_id,
                                mapping_result.status,
                                mapping_result.detail,
                            )
            finally:
                print("Stopping mapping processes...")
                for process in (map_rviz, cartographer):
                    process.stop()
                    if process in active_processes:
                        active_processes.remove(process)

        # ----------------------------- Transition and navigation subphase -----------------------------
        serial_release = check_serial_release(
            [Path("/dev/myserial"), Path("/dev/rplidar")],
            serial_release_log,
        )
        checks.append(serial_release)
        evidence_files.append(str(serial_release_log))
        show(serial_release.check_id, serial_release.status, serial_release.detail)

        if args.skip_navigation:
            checks.extend(
                [
                    skip_check("LASER_ODOM_BRINGUP", "LASER / ODOM BRINGUP", "--skip-navigation used"),
                    skip_check("NAV_RVIZ_DISPLAY", "NAVIGATION RVIZ DISPLAY", "--skip-navigation used"),
                    skip_check("DWA_NAVIGATION_LAUNCH", "DWA NAVIGATION LAUNCH", "--skip-navigation used"),
                    skip_check(
                        "NAVIGATION_STACK_OPERATION",
                        "NAVIGATION STACK OPERATION",
                        "--skip-navigation used",
                    ),
                ]
            )
        elif not build_ok:
            checks.extend(
                [
                    block_check("LASER_ODOM_BRINGUP", "LASER / ODOM BRINGUP", "Workspace build unavailable"),
                    block_check("NAV_RVIZ_DISPLAY", "NAVIGATION RVIZ DISPLAY", "Laser bring-up unavailable"),
                    block_check("DWA_NAVIGATION_LAUNCH", "DWA NAVIGATION LAUNCH", "Laser bring-up unavailable"),
                    block_check(
                        "NAVIGATION_STACK_OPERATION",
                        "NAVIGATION STACK OPERATION",
                        "Navigation stack unavailable",
                    ),
                ]
            )
        elif serial_release.status == Status.BLOCKED:
            checks.extend(
                [
                    block_check("LASER_ODOM_BRINGUP", "LASER / ODOM BRINGUP", "Serial device still held"),
                    block_check("NAV_RVIZ_DISPLAY", "NAVIGATION RVIZ DISPLAY", "Laser bring-up unavailable"),
                    block_check("DWA_NAVIGATION_LAUNCH", "DWA NAVIGATION LAUNCH", "Laser bring-up unavailable"),
                    block_check(
                        "NAVIGATION_STACK_OPERATION",
                        "NAVIGATION STACK OPERATION",
                        "Navigation stack unavailable",
                    ),
                ]
            )
        elif not port_usable:
            checks.extend(
                [
                    block_check("LASER_ODOM_BRINGUP", "LASER / ODOM BRINGUP", "Port binding failed"),
                    block_check("NAV_RVIZ_DISPLAY", "NAVIGATION RVIZ DISPLAY", "Laser bring-up unavailable"),
                    block_check("DWA_NAVIGATION_LAUNCH", "DWA NAVIGATION LAUNCH", "Laser bring-up unavailable"),
                    block_check(
                        "NAVIGATION_STACK_OPERATION",
                        "NAVIGATION STACK OPERATION",
                        "Navigation stack unavailable",
                    ),
                ]
            )
        else:
            laser_bringup = ManagedProcess(
                "laser-odom-bringup",
                workspace,
                args.laser_bringup_command,
                laser_bringup_log,
                echo=args.echo_process_output,
            )
            nav_rviz = ManagedProcess(
                "navigation-rviz",
                workspace,
                args.nav_rviz_command,
                nav_rviz_log,
                echo=args.echo_process_output,
            )
            dwa_navigation = ManagedProcess(
                "dwa-navigation",
                workspace,
                args.dwa_command,
                dwa_log,
                echo=args.echo_process_output,
            )

            try:
                print(f"\n{CYAN}Starting laser / odom bring-up...{RESET}")
                laser_bringup.start()
                active_processes.append(laser_bringup)
                laser_result = evaluate_launch(
                    laser_bringup,
                    "LASER_ODOM_BRINGUP",
                    "LASER / ODOM BRINGUP",
                    args.startup_timeout,
                )
                checks.append(laser_result)
                evidence_files.append(str(laser_bringup_log))
                show(laser_result.check_id, laser_result.status, laser_result.detail)

                if laser_result.status == Status.FAIL:
                    checks.extend(
                        [
                            block_check("NAV_RVIZ_DISPLAY", "NAVIGATION RVIZ DISPLAY", "Laser bring-up failed"),
                            block_check("DWA_NAVIGATION_LAUNCH", "DWA NAVIGATION LAUNCH", "Laser bring-up failed"),
                            block_check(
                                "NAVIGATION_STACK_OPERATION",
                                "NAVIGATION STACK OPERATION",
                                "Laser bring-up failed",
                            ),
                        ]
                    )
                else:
                    print(f"\n{CYAN}Starting navigation RViz...{RESET}")
                    nav_rviz.start()
                    active_processes.append(nav_rviz)
                    nav_rviz_result = evaluate_launch(
                        nav_rviz,
                        "NAV_RVIZ_DISPLAY",
                        "NAVIGATION RVIZ DISPLAY",
                        args.startup_timeout,
                    )
                    checks.append(nav_rviz_result)
                    evidence_files.append(str(nav_rviz_log))
                    show(
                        nav_rviz_result.check_id,
                        nav_rviz_result.status,
                        nav_rviz_result.detail,
                    )

                    if nav_rviz_result.status == Status.FAIL:
                        checks.extend(
                            [
                                block_check(
                                    "DWA_NAVIGATION_LAUNCH",
                                    "DWA NAVIGATION LAUNCH",
                                    "Navigation RViz failed",
                                ),
                                block_check(
                                    "NAVIGATION_STACK_OPERATION",
                                    "NAVIGATION STACK OPERATION",
                                    "Navigation RViz failed",
                                ),
                            ]
                        )
                    else:
                        print(f"\n{CYAN}Starting DWA navigation launch...{RESET}")
                        dwa_navigation.start()
                        active_processes.append(dwa_navigation)
                        dwa_result = evaluate_launch(
                            dwa_navigation,
                            "DWA_NAVIGATION_LAUNCH",
                            "DWA NAVIGATION LAUNCH",
                            args.startup_timeout,
                        )
                        checks.append(dwa_result)
                        evidence_files.append(str(dwa_log))
                        show(dwa_result.check_id, dwa_result.status, dwa_result.detail)

                        if dwa_result.status == Status.FAIL:
                            checks.append(
                                block_check(
                                    "NAVIGATION_STACK_OPERATION",
                                    "NAVIGATION STACK OPERATION",
                                    "DWA navigation launch failed",
                                )
                            )
                        else:
                            collect_ros_snapshot(workspace, navigation_graph_log)
                            evidence_files.append(str(navigation_graph_log))

                            print(
                                f"\n{CYAN}Laser/odom bring-up, navigation RViz and "
                                f"DWA navigation are now running concurrently.{RESET}"
                            )
                            wait_for_q(
                                "Observe RViz. Enter q here when the navigation review is complete: "
                            )
                            navigation_status, navigation_input = ask_ynu(
                                "Is the navigation stack good to go [Y/N/U]? "
                            )
                            navigation_detail = {
                                Status.PASS: "Operator confirmed the three-process navigation stack",
                                Status.FAIL: "Operator reported the navigation stack is not good to go",
                                Status.REVIEW: "Operator requested further navigation-stack review",
                            }[navigation_status]
                            navigation_result = CheckResult(
                                "NAVIGATION_STACK_OPERATION",
                                "NAVIGATION STACK OPERATION",
                                navigation_status,
                                navigation_detail,
                                str(navigation_graph_log),
                                navigation_input,
                            )
                            checks.append(navigation_result)
                            show(
                                navigation_result.check_id,
                                navigation_result.status,
                                navigation_result.detail,
                            )
            finally:
                print("Stopping navigation processes...")
                for process in (dwa_navigation, nav_rviz, laser_bringup):
                    process.stop()
                    if process in active_processes:
                        active_processes.remove(process)

    # Defensive cleanup for unexpected exceptions inside the main workflow.
    for process in reversed(active_processes):
        process.stop()

    phase_status = calculate_phase_status(checks)
    result = PhaseResult(
        program=PROGRAM_NAME,
        version=PROGRAM_VERSION,
        phase_number=PHASE_NUMBER,
        phase_total=PHASE_TOTAL,
        phase_name=PHASE_NAME,
        robot_id=args.robot_id,
        started_at=started_at,
        ended_at=now_iso(),
        status=phase_status,
        checks=checks,
        evidence_files=sorted(set(evidence_files)),
    )

    result_json.parent.mkdir(parents=True, exist_ok=True)
    result_json.write_text(
        json.dumps(phase_result_to_dict(result), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    phase_text = build_phase_text(result, include_raw_evidence=True)
    phase_report.write_text(phase_text, encoding="utf-8")

    if args.append_report:
        append_path = args.append_report.expanduser()
        append_path.parent.mkdir(parents=True, exist_ok=True)
        with append_path.open("a", encoding="utf-8") as shared_report:
            if append_path.stat().st_size > 0:
                shared_report.write("\n\n")
            shared_report.write(phase_text)

    return result, result_json, phase_report

def build_parser() -> argparse.ArgumentParser:
    """
    OBJECTIVE:
    Define the Program 3 command-line interface because the script must run
    independently and under the future master framework.

    TRACEABILITY:
    USER DEMAND:
    Run the checker with a robot number and preserve the Program 2 format.

    AI-CONVERTED NEED:
    Expose paths, timeouts, skips, output integration and vendor commands as
    validated CLI options.

    REQUIREMENT CREATED:
    P3-FRAMEWORK-001.

    TECHNICAL DECISIONS:
    TD-P3-022, TD-P3-023.

    INPUTS:
    None.

    OUTPUTS:
    Configured argparse.ArgumentParser.

    WORKFLOW:
    IN => [Program 3 interface requirements] -define arguments/defaults-> [parser] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Mirrors Program 2 CLI conventions for predictable use.
    """
    parser = argparse.ArgumentParser(
        description=(
            "Phase 3 Yahboom Cartographer and navigation-stack checker "
            "(standard library only)."
        )
    )
    parser.add_argument("robot_id", help="Robot number, for example R23")
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path.home() / "yahboomcar_ws",
        help="Yahboom ROS 2 workspace",
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path.home() / "robot_check_results",
        help="Root directory for results",
    )
    parser.add_argument(
        "--result-json",
        type=Path,
        help="Optional JSON result path supplied by the master framework",
    )
    parser.add_argument(
        "--append-report",
        type=Path,
        help="Append this Phase 3 section to a shared master report",
    )

    parser.add_argument("--skip-build", action="store_true")
    parser.add_argument("--skip-mapping", action="store_true")
    parser.add_argument("--skip-navigation", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-open-report", action="store_true")
    parser.add_argument("--echo-process-output", action="store_true")

    parser.add_argument("--build-timeout", type=int, default=900)
    parser.add_argument("--startup-timeout", type=float, default=10.0)
    parser.add_argument("--port-review-seconds", type=float, default=5.0)

    parser.add_argument(
        "--cartographer-command",
        default="ros2 launch yahboomcar_nav map_cartographer_launch.py",
    )
    parser.add_argument(
        "--map-rviz-command",
        default="ros2 launch yahboomcar_nav display_map_launch.py",
    )
    parser.add_argument(
        "--keyboard-command",
        default="ros2 run yahboomcar_ctrl yahboom_keyboard",
    )
    parser.add_argument(
        "--laser-bringup-command",
        default=(
            "ros2 launch yahboomcar_nav laser_bringup_launch.py "
            "pub_odom_tf:=true"
        ),
    )
    parser.add_argument(
        "--nav-rviz-command",
        default="ros2 launch yahboomcar_nav display_nav_launch.py",
    )
    parser.add_argument(
        "--dwa-command",
        default="ros2 launch yahboomcar_nav navigation_dwa_launch.py",
    )
    return parser


def main() -> int:
    """
    OBJECTIVE:
    Run Program 3 from CLI parsing to final report because the operator needs
    one command for the complete Phase 3 procedure.

    TRACEABILITY:
    USER DEMAND:
    Proceed to generate Program 3 in the same format as Program 2.

    AI-CONVERTED NEED:
    Parse configuration, execute the phase, handle interruption, print result
    locations and optionally open the report.

    REQUIREMENT CREATED:
    P3-FRAMEWORK-001 and P3-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P3-023, TD-P3-024.

    INPUTS:
    Process command-line arguments.

    OUTPUTS:
    Exit code 0 when the checker workflow completes, 130 on interruption and 1
    on unexpected program failure.

    WORKFLOW:
    IN => [CLI arguments] -parse/run phase-> [result + files]
       -print/open report-> [process exit code] => OUTPUT

    IMPROVEMENTS MADE:
    Initial implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Preserves Program 2's separation between checker completion and test status.
    """
    parser = build_parser()
    args = parser.parse_args()

    print(f"\n{CYAN}{PROGRAM_NAME} v{PROGRAM_VERSION}{RESET}")
    print(f"Robot: {args.robot_id}")
    print(f"Workspace: {args.workspace.expanduser()}")
    print("Standard-library-only build")
    print("Scope: launch/display operation only; no map save and no navigation goal\n")

    try:
        result, result_json, phase_report = run_phase(args)
    except KeyboardInterrupt:
        print("\nInterrupted by user. Owned processes were cleaned up where possible.")
        return 130
    except Exception as exc:
        print(f"\nUnexpected program error: {exc}", file=sys.stderr)
        return 1

    print("\n" + build_phase_text(result, include_raw_evidence=False))
    print(f"JSON result: {result_json}")
    print(f"Phase report: {phase_report}")

    if not args.no_open_report:
        open_report(phase_report)

    # The exit code reports checker completion; PASS/FAIL/REVIEW is in JSON/report.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
