#!/usr/bin/env python3
from __future__ import annotations

"""
PROGRAM 1 — ROS 2 QUICK CHECK
Version: 1.2.0.0
Python: 3.10+
Dependencies: Python standard library only.

USER INTENT
-----------
Automate the repeated ROS 2 environment, package and teaching-demo checks for
each robot, preserve raw evidence, and expose the same structured interface as
Programs 2 and 3 so one master command can execute the complete validation run.

USER DEMAND -> AI-CONVERTED NEED -> REQUIREMENTS
------------------------------------------------
USER DEMAND:
Run the first program together with Programs 2 and 3 from one unified command
and write all phases into one note.

AI-CONVERTED NEED:
Program 1 must retain its existing ROS checks while returning a machine-readable
PhaseResult JSON and appending a Phase 1 section to a master-supplied report.

REQUIREMENTS CREATED:
P1-FRAME-001:
The program shall accept master-supplied result JSON and shared-report paths.

P1-RESULT-001:
Every check shall return a structured status, detail and evidence reference.

P1-RESULT-002:
The process exit code shall report checker execution, while the PhaseResult JSON
shall report PASS, FAIL, REVIEW, ERROR, BLOCKED or SKIPPED.

P1-REPORT-001:
The program shall write one Phase 1 report using the same phase format as
Programs 2 and 3 and may append it to a shared master report.

P1-ENV-001:
The program shall report ROS distribution, Ubuntu description, Python 3 and
workspace existence.

P1-PKG-001:
The program shall verify pkg_helloworld_py, pkg_topic and pkg_action.

P1-FUNC-001:
The program shall perform the Hello World, publisher/subscriber and action
checks when --run-functional is supplied.

TECHNICAL DECISION REGISTER
---------------------------
TD-P1-001:
Keep Program 1 as an external black-box test harness so the teaching packages
remain unchanged.

TD-P1-002:
Use only Python standard-library components to minimise deployment friction.

TD-P1-003:
Execute commands through bash -lc so ROS 2 Humble and workspace setup can be
sourced consistently.

TD-P1-004:
Use subprocess.run for bounded commands and subprocess.Popen for supporting
nodes that must remain active during a paired check.

TD-P1-005:
Create a new process session for supporting nodes so cleanup targets only the
checker-owned process group.

TD-P1-006:
Attempt SIGINT before SIGKILL so ROS nodes receive a normal shutdown opportunity.

TD-P1-007:
Treat deliberately timed continuous demonstrations as evidence-producing checks
rather than assuming timeout return code 124 means functional failure.

TD-P1-008:
Use tolerant semantic output matchers so harmless whitespace differences do not
produce false failures.

TD-P1-009:
Require evidence from both action server and client before classifying the
complete action interaction as PASS.

TD-P1-010:
Represent each result as CheckResult and the phase as PhaseResult so the master
can consume the same contract used by Programs 2 and 3.

TD-P1-011:
Use JSON as the machine-readable source of truth and the text report as the
human-readable evidence summary.

TD-P1-012:
Open the Phase report only in standalone use; the master disables phase-level
opening and opens the final consolidated report once.

KNOWN LIMITATIONS
-----------------
KL-P1-001:
Text-pattern evidence does not prove all internal ROS behaviour.

KL-P1-002:
The fixed startup delay for publisher and action server is a readiness
assumption rather than an event-driven readiness proof.

IMPROVEMENT HISTORY
-------------------
[240726 1441]
REASON OF FAIL:
A valid subscriber output used "Hi,I send a message." while the earlier exact
spacing matcher expected "Hi, I send a message.", creating a false negative.

IMPROVEMENT:
Changed the matcher to accept optional whitespace without weakening the required
sentence meaning.

[240726 1441]
REASON OF FAIL:
The action check returned REVIEW despite server "Mission accomplished" and
client "Final calculation result" evidence.

IMPROVEMENT:
Required and detected both completion phrases for PASS.

[270726 1700]
REASON OF FAIL:
Program 1 produced only a standalone text log, so a master program could not
reliably determine its phase status or append it using the common contract.

IMPROVEMENT:
Added CheckResult, PhaseResult, JSON output, shared-report append support,
dry-run support and the common Phase 1 report format.
"""

import argparse
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

PROGRAM_NAME = "phase1_ros_quickcheck"
PROGRAM_VERSION = "1.2.0.0"
PHASE_NUMBER = 1
PHASE_TOTAL = 3
PHASE_NAME = "ROS CHECK"

GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
CYAN = "\033[36m"
RESET = "\033[0m"


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    REVIEW = "REVIEW"
    ERROR = "ERROR"
    SKIPPED = "SKIPPED"
    BLOCKED = "BLOCKED"


DISPLAY_STATUS = {
    Status.PASS: "SUCCESS",
    Status.FAIL: "FAILED",
    Status.REVIEW: "REVIEW REQUIRED",
    Status.ERROR: "PROGRAM ERROR",
    Status.SKIPPED: "SKIPPED",
    Status.BLOCKED: "BLOCKED",
}


@dataclass
class CheckResult:
    check_id: str
    label: str
    status: Status
    detail: str = ""
    evidence: str = ""
    human_input: str = ""


@dataclass
class PhaseResult:
    program: str
    version: str
    phase_number: int
    phase_total: int
    phase_name: str
    robot_id: str
    started_at: str
    ended_at: str
    status: Status
    checks: list[CheckResult] = field(default_factory=list)
    evidence_files: list[str] = field(default_factory=list)


def now_iso() -> str:
    """
    OBJECTIVE:
    Produce one timezone-aware timestamp because every phase result and evidence
    file must be traceable to a concrete execution time.

    USER DEMAND:
    Keep all checks in one traceable record.

    AI-CONVERTED NEED:
    Use a stable timestamp format throughout JSON and text outputs.

    REQUIREMENT CREATED:
    P1-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-011.

    INPUTS:
    None.

    OUTPUTS:
    Local ISO-8601 timestamp with timezone offset.

    WORKFLOW:
    IN => [system clock] -localise/format-> [ISO timestamp] => OUTPUT

    IMPROVEMENTS MADE:
    Initial common-contract implementation.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added one timestamp helper shared by logs and results.
    """
    return datetime.now().astimezone().isoformat(timespec="seconds")


def show(label: str, status: Status, detail: str = "") -> None:
    """
    OBJECTIVE:
    Display a consistent coloured result because the operator must recognise
    check outcomes quickly during repeated robot validation.

    USER DEMAND:
    Show clear PASS/FAIL/REVIEW results.

    AI-CONVERTED NEED:
    Convert internal status values into one terminal presentation.

    REQUIREMENT CREATED:
    P1-RESULT-001.

    TECHNICAL DECISIONS:
    TD-P1-010.

    INPUTS:
    Check label, Status and optional detail.

    OUTPUTS:
    None; prints one formatted terminal line.

    WORKFLOW:
    IN => [label, status, detail] -select colour/format-> [terminal line] => OUTPUT

    IMPROVEMENTS MADE:
    Migrated string statuses to the shared Status enum.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Added common status presentation.
    """
    colour = {
        Status.PASS: GREEN,
        Status.FAIL: RED,
        Status.REVIEW: YELLOW,
        Status.ERROR: RED,
        Status.SKIPPED: YELLOW,
        Status.BLOCKED: YELLOW,
    }.get(status, "")
    suffix = f" - {detail}" if detail else ""
    print(f"{colour}{label}: {status.value}{RESET}{suffix}")


def format_result_line(label: str, status: Status, width: int = 48) -> str:
    """
    OBJECTIVE:
    Produce the shared dotted report line because all three phases must use one
    readable note format.

    USER DEMAND:
    Write TEST........................ SUCCESS in the same note.

    AI-CONVERTED NEED:
    Centralise label alignment and display-status translation.

    REQUIREMENT CREATED:
    P1-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P1-011.

    INPUTS:
    Label, internal Status and dotted-field width.

    OUTPUTS:
    One formatted report line.

    WORKFLOW:
    IN => [label, status] -dot-fill/translate-> [report line] => OUTPUT

    IMPROVEMENTS MADE:
    Added common Phase report formatting.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Matches Programs 2 and 3.
    """
    return f"{label:.<{width}} {DISPLAY_STATUS[status]}"


def calculate_phase_status(checks: list[CheckResult]) -> Status:
    """
    OBJECTIVE:
    Derive one Phase 1 status because the master requires a single authoritative
    outcome in addition to individual check results.

    USER DEMAND:
    Let the unified program know whether Phase 1 completed, failed or needs review.

    AI-CONVERTED NEED:
    Apply deterministic status precedence while ignoring optional skipped checks.

    REQUIREMENT CREATED:
    P1-RESULT-002.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-011.

    INPUTS:
    List of CheckResult objects.

    OUTPUTS:
    Aggregate Status.

    WORKFLOW:
    IN => [check statuses] -remove skipped/apply precedence-> [phase status] => OUTPUT

    IMPROVEMENTS MADE:
    Added structured phase aggregation.

    REASON OF FAIL:
    Previous version did not expose an aggregate machine-readable status.

    IMPROVEMENT:
    Added ERROR > FAIL > REVIEW > BLOCKED > PASS precedence.
    """
    statuses = {check.status for check in checks if check.status != Status.SKIPPED}
    if not statuses:
        return Status.SKIPPED
    if Status.ERROR in statuses:
        return Status.ERROR
    if Status.FAIL in statuses:
        return Status.FAIL
    if Status.REVIEW in statuses:
        return Status.REVIEW
    if Status.BLOCKED in statuses:
        return Status.BLOCKED
    return Status.PASS


def shell_command(workspace: Path, command: str) -> str:
    """
    OBJECTIVE:
    Construct a ROS-aware shell command because every child shell must receive
    the ROS 2 Humble and selected workspace environment.

    USER DEMAND:
    Avoid repeatedly typing source commands.

    AI-CONVERTED NEED:
    Prepend available setup files to every requested command.

    REQUIREMENT CREATED:
    P1-ENV-001.

    TECHNICAL DECISIONS:
    TD-P1-001, TD-P1-003.

    INPUTS:
    Workspace path and command string.

    OUTPUTS:
    One bash command chain.

    WORKFLOW:
    IN => [workspace, command] -add setup sources-> [parts] -join with &&-> OUTPUT

    IMPROVEMENTS MADE:
    Preserved Program 1 v1.1 behaviour.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Workspace setup remains conditional.
    """
    parts = ["source /opt/ros/humble/setup.bash"]
    setup = workspace / "install" / "setup.bash"
    if setup.exists():
        parts.append(f"source {shlex.quote(str(setup))}")
    parts.append(command)
    return " && ".join(parts)


def run_command(
    workspace: Path,
    command: str,
    timeout: int = 12,
) -> tuple[int, str]:
    """
    OBJECTIVE:
    Run a bounded command and capture evidence because one-shot checks must not
    hang the complete validation workflow.

    USER DEMAND:
    Execute and record the ROS commands automatically.

    AI-CONVERTED NEED:
    Return a stable code/output tuple, including timeout evidence.

    REQUIREMENT CREATED:
    P1-RESULT-001, P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-003, TD-P1-004, TD-P1-007.

    INPUTS:
    Workspace, command and timeout seconds.

    OUTPUTS:
    Return code and combined stdout/stderr.

    WORKFLOW:
    IN => [command] -source/run/wait-> [code, output or timeout] => OUTPUT

    IMPROVEMENTS MADE:
    Preserved bounded command execution.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Uses a safe fallback working directory when the workspace is absent.
    """
    cwd = workspace if workspace.exists() else Path.home()
    try:
        completed = subprocess.run(
            ["bash", "-lc", shell_command(workspace, command)],
            cwd=cwd,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        return completed.returncode, (completed.stdout + completed.stderr).strip()
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        return 124, (stdout + stderr).strip()


def start_process(workspace: Path, command: str) -> subprocess.Popen[str]:
    """
    OBJECTIVE:
    Start a supporting ROS node asynchronously because publisher and action
    server must remain active while their paired process executes.

    USER DEMAND:
    Automate the multi-terminal functional checks.

    AI-CONVERTED NEED:
    Create a checker-owned process group with captured unbuffered output.

    REQUIREMENT CREATED:
    P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-004, TD-P1-005.

    INPUTS:
    Workspace and long-running ROS command.

    OUTPUTS:
    Live Popen handle.

    WORKFLOW:
    IN => [command] -source/start new session-> [owned process] => OUTPUT

    IMPROVEMENTS MADE:
    Preserved Program 1 v1.1 process ownership.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    None required.
    """
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    return subprocess.Popen(
        ["bash", "-lc", shell_command(workspace, command)],
        cwd=workspace,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
        start_new_session=True,
    )


def stop_process(process: subprocess.Popen[str]) -> str:
    """
    OBJECTIVE:
    Stop one checker-owned process and collect remaining output because support
    nodes must not survive their functional check.

    USER DEMAND:
    Close only the program started for the current test.

    AI-CONVERTED NEED:
    Signal the owned process group gracefully, then force termination if needed.

    REQUIREMENT CREATED:
    P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-005, TD-P1-006.

    INPUTS:
    Popen handle returned by start_process.

    OUTPUTS:
    Captured process output.

    WORKFLOW:
    IN => [owned process] -SIGINT/wait-> [stopped or timeout]
       -SIGKILL if required/communicate-> [output] => OUTPUT

    IMPROVEMENTS MADE:
    Preserved safe owned-process cleanup.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    None required.
    """
    if process.poll() is None:
        try:
            os.killpg(os.getpgid(process.pid), signal.SIGINT)
        except ProcessLookupError:
            pass
    try:
        output, _ = process.communicate(timeout=3)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        output, _ = process.communicate()
    return output or ""


def first_value(workspace: Path, command: str) -> Optional[str]:
    """
    OBJECTIVE:
    Extract one concise environment value because the report needs a readable
    summary in addition to raw evidence.

    USER DEMAND:
    Show the system configuration clearly.

    AI-CONVERTED NEED:
    Return the first successful output line or None.

    REQUIREMENT CREATED:
    P1-ENV-001.

    TECHNICAL DECISIONS:
    TD-P1-003, TD-P1-011.

    INPUTS:
    Workspace and query command.

    OUTPUTS:
    First line or None.

    WORKFLOW:
    IN => [query] -run-> [code, output] -validate/split-> [value or None] => OUTPUT

    IMPROVEMENTS MADE:
    Preserved existing helper.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    None required.
    """
    code, output = run_command(workspace, command)
    return output.splitlines()[0] if code == 0 and output else None


def check_environment(workspace: Path, evidence_path: Path) -> list[CheckResult]:
    """
    OBJECTIVE:
    Verify the minimum execution context because later functional evidence is
    meaningful only when ROS, Python and the workspace are available.

    USER DEMAND:
    Check ROS, Ubuntu, Python and workspace first.

    AI-CONVERTED NEED:
    Return structured environment checks and save the queried values.

    REQUIREMENT CREATED:
    P1-ENV-001, P1-RESULT-001.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-011.

    INPUTS:
    Workspace and environment evidence path.

    OUTPUTS:
    Four CheckResult objects.

    WORKFLOW:
    IN => [workspace] -query environment/path-> [values]
       -classify/write evidence-> [checks] => OUTPUT

    IMPROVEMENTS MADE:
    Converted printed-only results into CheckResult objects.

    REASON OF FAIL:
    Previous version did not expose machine-readable environment outcomes.

    IMPROVEMENT:
    Added structured results and evidence file.
    """
    distro = first_value(workspace, "printenv ROS_DISTRO")
    ubuntu = first_value(workspace, "lsb_release -ds")
    python_version = first_value(workspace, "python3 --version")
    workspace_ok = workspace.exists()

    checks = [
        CheckResult(
            "ROS_DISTRO",
            "ROS DISTRIBUTION",
            Status.PASS if distro == "humble" else Status.FAIL,
            str(distro),
            str(evidence_path),
        ),
        CheckResult(
            "UBUNTU",
            "UBUNTU VERSION",
            Status.PASS if ubuntu else Status.FAIL,
            str(ubuntu),
            str(evidence_path),
        ),
        CheckResult(
            "PYTHON3",
            "PYTHON 3",
            Status.PASS
            if python_version and python_version.startswith("Python 3")
            else Status.FAIL,
            str(python_version),
            str(evidence_path),
        ),
        CheckResult(
            "WORKSPACE",
            "ROS WORKSPACE",
            Status.PASS if workspace_ok else Status.FAIL,
            str(workspace),
            str(evidence_path),
        ),
    ]

    evidence_path.write_text(
        "\n".join(
            [
                f"TIME={now_iso()}",
                f"ROS_DISTRO={distro}",
                f"UBUNTU={ubuntu}",
                f"PYTHON={python_version}",
                f"WORKSPACE={workspace}",
                f"WORKSPACE_EXISTS={workspace_ok}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    for check in checks:
        show(check.check_id, check.status, check.detail)
    return checks


def check_packages(
    workspace: Path,
    evidence_path: Path,
) -> tuple[dict[str, bool], list[CheckResult]]:
    """
    OBJECTIVE:
    Verify required ROS packages because functional commands should execute only
    when their packages are discoverable.

    USER DEMAND:
    Confirm the three teaching packages before running them.

    AI-CONVERTED NEED:
    Query ros2 pkg prefix and return both availability and structured evidence.

    REQUIREMENT CREATED:
    P1-PKG-001, P1-RESULT-001.

    TECHNICAL DECISIONS:
    TD-P1-001, TD-P1-010, TD-P1-011.

    INPUTS:
    Workspace and package evidence path.

    OUTPUTS:
    Package availability dictionary and CheckResult list.

    WORKFLOW:
    IN => [package list] -ros2 pkg prefix each-> [code/output]
       -classify/write-> [availability, checks] => OUTPUT

    IMPROVEMENTS MADE:
    Converted package results to common CheckResult format.

    REASON OF FAIL:
    Previous version exposed only console output and raw text.

    IMPROVEMENT:
    Added structured package results.
    """
    packages = ["pkg_helloworld_py", "pkg_topic", "pkg_action"]
    availability: dict[str, bool] = {}
    checks: list[CheckResult] = []
    evidence_parts: list[str] = []

    for package in packages:
        code, output = run_command(
            workspace,
            f"ros2 pkg prefix {shlex.quote(package)}",
            timeout=8,
        )
        exists = code == 0
        availability[package] = exists
        first_line = output.splitlines()[0] if output else "Not found"
        check = CheckResult(
            f"PACKAGE_{package.upper()}",
            f"PACKAGE {package}",
            Status.PASS if exists else Status.FAIL,
            first_line,
            str(evidence_path),
        )
        checks.append(check)
        evidence_parts.append(f"[{package}]\nRETURN_CODE={code}\n{output}\n")
        show(check.check_id, check.status, check.detail)

    evidence_path.write_text("\n".join(evidence_parts), encoding="utf-8")
    return availability, checks


def check_helloworld(workspace: Path, evidence_path: Path) -> CheckResult:
    """
    OBJECTIVE:
    Confirm repeated Hello World output because one startup line is insufficient
    evidence of continuous execution.

    USER DEMAND:
    Run and verify the Hello World demonstration automatically.

    AI-CONVERTED NEED:
    Count accepted Hello occurrences during a bounded execution window.

    REQUIREMENT CREATED:
    P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-004, TD-P1-007.

    INPUTS:
    Workspace and evidence path.

    OUTPUTS:
    Hello World CheckResult.

    WORKFLOW:
    IN => [workspace] -run bounded node-> [output] -regex count/threshold-> OUTPUT

    IMPROVEMENTS MADE:
    Preserved the three-occurrence acceptance rule.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Converted the outcome to CheckResult.
    """
    code, output = run_command(
        workspace,
        "timeout --signal=INT 7s ros2 run pkg_helloworld_py helloworld",
        timeout=10,
    )
    count = len(re.findall(r"\bhello(?:\s+world)?\b", output, flags=re.IGNORECASE))
    status = Status.PASS if count >= 3 else Status.FAIL
    detail = f"Detected {count} Hello occurrence(s)"
    evidence_path.write_text(
        f"RETURN_CODE={code}\nCOUNT={count}\n\n{output}\n",
        encoding="utf-8",
    )
    result = CheckResult(
        "HELLOWORLD",
        "HELLO WORLD",
        status,
        detail,
        str(evidence_path),
    )
    show(result.check_id, result.status, result.detail)
    return result


def count_pubsub_messages(output: str) -> int:
    """
    OBJECTIVE:
    Count semantically equivalent subscriber messages because harmless
    whitespace variation must not create false failures.

    USER DEMAND:
    Accept both "Hi,I..." and "Hi, I..." as the same valid message.

    AI-CONVERTED NEED:
    Use one tolerant case-insensitive regular expression.

    REQUIREMENT CREATED:
    P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-008.

    INPUTS:
    Subscriber output text.

    OUTPUTS:
    Accepted message count.

    WORKFLOW:
    IN => [output] -regex find all-> [matches] -count-> OUTPUT

    IMPROVEMENTS MADE:
    [240726 1441] Corrected verified false negative.

    REASON OF FAIL:
    Exact spacing rejected valid output.

    IMPROVEMENT:
    Added optional whitespace matching around punctuation and words.
    """
    pattern = re.compile(
        r"\bhi\s*,\s*i\s+send\s+a\s+message\s*\.?",
        flags=re.IGNORECASE,
    )
    return len(pattern.findall(output))


def check_pubsub(workspace: Path, evidence_path: Path) -> CheckResult:
    """
    OBJECTIVE:
    Verify publisher/subscriber communication because package discovery alone
    does not prove message exchange.

    USER DEMAND:
    Start both programs, record them and determine whether messages arrive.

    AI-CONVERTED NEED:
    Overlap process lifetimes, count subscriber messages and clean up publisher.

    REQUIREMENT CREATED:
    P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-004, TD-P1-005, TD-P1-006, TD-P1-007, TD-P1-008.

    INPUTS:
    Workspace and evidence path.

    OUTPUTS:
    Publisher/subscriber CheckResult.

    WORKFLOW:
    IN => [workspace] -start publisher/wait-> [active publisher]
       -run subscriber/count-> [status] -stop publisher/write evidence-> OUTPUT

    IMPROVEMENTS MADE:
    [240726 1441] Revalidated with tolerant matcher.

    REASON OF FAIL:
    Valid messages were previously rejected due to spacing.

    IMPROVEMENT:
    Uses count_pubsub_messages().
    """
    publisher = start_process(workspace, "ros2 run pkg_topic publisher_demo")
    time.sleep(2)
    subscriber_code, subscriber_output = run_command(
        workspace,
        "timeout --signal=INT 8s ros2 run pkg_topic subscriber_demo",
        timeout=11,
    )
    publisher_output = stop_process(publisher)
    count = count_pubsub_messages(subscriber_output)
    status = Status.PASS if count >= 3 else Status.FAIL
    detail = f"Subscriber detected expected message {count} time(s)"
    evidence_path.write_text(
        (
            f"PUBLISHER OUTPUT:\n{publisher_output}\n\n"
            f"SUBSCRIBER RETURN_CODE={subscriber_code}\n{subscriber_output}\n"
        ),
        encoding="utf-8",
    )
    result = CheckResult(
        "PUBSUB",
        "PUBLISHER / SUBSCRIBER",
        status,
        detail,
        str(evidence_path),
    )
    show(result.check_id, result.status, result.detail)
    return result


def check_action(workspace: Path, evidence_path: Path) -> CheckResult:
    """
    OBJECTIVE:
    Verify the complete action interaction because either server or client
    evidence alone is insufficient.

    USER DEMAND:
    Recognise the successful server and client outputs shown in the real run.

    AI-CONVERTED NEED:
    Require both completion phrases for PASS and preserve partial evidence as
    REVIEW rather than fabricating success.

    REQUIREMENT CREATED:
    P1-FUNC-001.

    TECHNICAL DECISIONS:
    TD-P1-004, TD-P1-005, TD-P1-006, TD-P1-007, TD-P1-009.

    INPUTS:
    Workspace and evidence path.

    OUTPUTS:
    Action CheckResult.

    WORKFLOW:
    IN => [workspace] -start server/wait-> [active server]
       -run client/stop server-> [both outputs] -match/classify-> OUTPUT

    IMPROVEMENTS MADE:
    [240726 1441] Added verified server/client completion matchers.

    REASON OF FAIL:
    Earlier logic returned REVIEW despite complete success evidence.

    IMPROVEMENT:
    PASS now requires both "mission accomplished" and "final calculation result".
    """
    server = start_process(workspace, "ros2 run pkg_action action_server_demo")
    time.sleep(2)
    client_code, client_output = run_command(
        workspace,
        "timeout --signal=INT 12s ros2 run pkg_action action_client_demo",
        timeout=15,
    )
    server_output = stop_process(server)

    server_done = bool(
        re.search(r"mission\s+accomplished", server_output, re.IGNORECASE)
    )
    client_done = bool(
        re.search(r"final\s+calculation\s+result", client_output, re.IGNORECASE)
    )

    if server_done and client_done:
        status = Status.PASS
        detail = "Server mission completed and client returned final result"
    elif not client_output and client_code not in (0, 124):
        status = Status.FAIL
        detail = f"Client return code {client_code}"
    else:
        status = Status.REVIEW
        detail = "Action ran, but completion text was not fully detected"

    evidence_path.write_text(
        (
            f"SERVER OUTPUT:\n{server_output}\n\n"
            f"CLIENT RETURN_CODE={client_code}\n{client_output}\n"
        ),
        encoding="utf-8",
    )
    result = CheckResult(
        "ACTION",
        "ACTION SERVER / CLIENT",
        status,
        detail,
        str(evidence_path),
    )
    show(result.check_id, result.status, result.detail)
    return result


def blocked(check_id: str, label: str, reason: str) -> CheckResult:
    """
    OBJECTIVE:
    Represent an unexecuted dependent check because omission must remain visible
    in the consolidated report.

    USER DEMAND:
    Do not silently skip later work when a prerequisite is missing.

    AI-CONVERTED NEED:
    Return an explicit BLOCKED CheckResult.

    REQUIREMENT CREATED:
    P1-RESULT-001.

    TECHNICAL DECISIONS:
    TD-P1-010.

    INPUTS:
    Check ID, label and blocking reason.

    OUTPUTS:
    BLOCKED CheckResult.

    WORKFLOW:
    IN => [identity, reason] -construct-> [blocked result] => OUTPUT

    IMPROVEMENTS MADE:
    Added common dependency semantics.

    REASON OF FAIL:
    Previous version silently omitted a functional test when its package was absent.

    IMPROVEMENT:
    Missing package now creates a visible blocked check.
    """
    return CheckResult(check_id, label, Status.BLOCKED, reason)


def skipped(check_id: str, label: str, reason: str) -> CheckResult:
    """
    OBJECTIVE:
    Represent an intentionally disabled check because optional execution choices
    must remain traceable.

    USER DEMAND:
    Allow functional tests to be omitted when not requested.

    AI-CONVERTED NEED:
    Return an explicit SKIPPED CheckResult.

    REQUIREMENT CREATED:
    P1-RESULT-001.

    TECHNICAL DECISIONS:
    TD-P1-010.

    INPUTS:
    Check ID, label and skip reason.

    OUTPUTS:
    SKIPPED CheckResult.

    WORKFLOW:
    IN => [identity, reason] -construct-> [skipped result] => OUTPUT

    IMPROVEMENTS MADE:
    Added structured skip semantics.

    REASON OF FAIL:
    N/A.

    IMPROVEMENT:
    Functional-test omission is now visible in JSON and report.
    """
    return CheckResult(check_id, label, Status.SKIPPED, reason)


def phase_result_to_dict(result: PhaseResult) -> dict[str, object]:
    """
    OBJECTIVE:
    Convert dataclass results into JSON-safe values because Enum objects are not
    directly serialisable by the standard JSON encoder.

    USER DEMAND:
    Let the master read Phase 1 reliably.

    AI-CONVERTED NEED:
    Convert phase and check statuses to strings.

    REQUIREMENT CREATED:
    P1-FRAME-001, P1-RESULT-002.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-011.

    INPUTS:
    PhaseResult.

    OUTPUTS:
    JSON-safe dictionary.

    WORKFLOW:
    IN => [PhaseResult] -asdict/enum conversion-> [dictionary] => OUTPUT

    IMPROVEMENTS MADE:
    Added common machine-readable contract.

    REASON OF FAIL:
    Previous version had no JSON result.

    IMPROVEMENT:
    Added explicit Enum conversion.
    """
    data = asdict(result)
    data["status"] = result.status.value
    for check_data, check in zip(data["checks"], result.checks):
        check_data["status"] = check.status.value
    return data


def build_phase_text(
    result: PhaseResult,
    include_raw_evidence: bool = True,
) -> str:
    """
    OBJECTIVE:
    Build one Phase 1 report section because all phases must appear in the same
    human-readable note.

    USER DEMAND:
    Use [PHASE 1/2/3] headers, dotted status lines and explicit phase completion.

    AI-CONVERTED NEED:
    Render CheckResult objects and evidence references using the shared format.

    REQUIREMENT CREATED:
    P1-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P1-011.

    INPUTS:
    PhaseResult and raw-evidence inclusion flag.

    OUTPUTS:
    Complete Phase 1 text section.

    WORKFLOW:
    IN => [phase result] -format checks/status/evidence-> [phase text] => OUTPUT

    IMPROVEMENTS MADE:
    Added report compatibility with Programs 2 and 3.

    REASON OF FAIL:
    Previous standalone log was not formatted as a phase section.

    IMPROVEMENT:
    Added common header, completion line and evidence index.
    """
    lines = [
        f"[PHASE {result.phase_number}/{result.phase_total}: {result.phase_name}]",
        "",
    ]
    for check in result.checks:
        lines.append(format_result_line(check.label, check.status))

    phase_display = {
        Status.PASS: f"PHASE {result.phase_number}: COMPLETED",
        Status.FAIL: f"PHASE {result.phase_number}: FAILED",
        Status.REVIEW: f"PHASE {result.phase_number}: REVIEW REQUIRED",
        Status.ERROR: f"PHASE {result.phase_number}: PROGRAM ERROR",
        Status.BLOCKED: f"PHASE {result.phase_number}: BLOCKED",
        Status.SKIPPED: f"PHASE {result.phase_number}: SKIPPED",
    }[result.status]
    lines.extend(["", phase_display, "", f"(END OF PHASE {result.phase_number})", ""])

    if include_raw_evidence:
        lines.extend(
            [
                "=" * 72,
                f"RAW EVIDENCE — PHASE {result.phase_number}",
                "=" * 72,
                "",
            ]
        )
        for check in result.checks:
            lines.append(f"[{check.check_id}]")
            lines.append(f"STATUS={check.status.value}")
            if check.detail:
                lines.append(f"DETAIL={check.detail}")
            if check.evidence:
                lines.append(f"EVIDENCE={check.evidence}")
            lines.append("")
        lines.append("EVIDENCE FILES")
        lines.extend(result.evidence_files)
        lines.append("")
    return "\n".join(lines)


def open_report(path: Path) -> None:
    """
    OBJECTIVE:
    Open the standalone Phase report because automated conclusions must remain
    available for human inspection.

    USER DEMAND:
    Open the note after the run, but not when the master will open the final note.

    AI-CONVERTED NEED:
    Launch xdg-open only when phase-level opening is enabled.

    REQUIREMENT CREATED:
    P1-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P1-012.

    INPUTS:
    Report path.

    OUTPUTS:
    None; launches viewer or prints REVIEW.

    WORKFLOW:
    IN => [report path] -xdg-open-> [viewer or warning] => OUTPUT

    IMPROVEMENTS MADE:
    Added master-compatible disable option.

    REASON OF FAIL:
    Multiple phase reports would otherwise open during one unified run.

    IMPROVEMENT:
    Master passes --no-open-report.
    """
    try:
        subprocess.Popen(
            ["xdg-open", str(path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as exc:
        show("OPEN_REPORT", Status.REVIEW, str(exc))


def run_phase(args: argparse.Namespace) -> tuple[PhaseResult, Path, Path]:
    """
    OBJECTIVE:
    Execute the complete Phase 1 workflow and write the common result artifacts
    because the master requires one independently owned phase transaction.

    USER DEMAND:
    Run Program 1 as the first part of one complete robot-validation command.

    AI-CONVERTED NEED:
    Create a run directory, perform checks, aggregate status, write JSON/report
    and append the phase to a shared note when requested.

    REQUIREMENT CREATED:
    P1-FRAME-001, P1-RESULT-001, P1-RESULT-002, P1-REPORT-001.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-011, TD-P1-012.

    INPUTS:
    Parsed argparse Namespace.

    OUTPUTS:
    PhaseResult, JSON path and Phase report path.

    WORKFLOW:
    IN => [configuration] -prepare run directory/checks-> [results]
       -aggregate/write/append-> [result, JSON, report] => OUTPUT

    IMPROVEMENTS MADE:
    Added common Phase execution contract.

    REASON OF FAIL:
    Program 1 v1.1 could not participate in the master framework.

    IMPROVEMENT:
    Added result paths, shared report, dry run and structured phase status.
    """
    started_at = now_iso()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    workspace = args.workspace.expanduser().resolve()
    run_dir = args.result_root.expanduser() / args.robot_id / f"{timestamp}_phase1"
    run_dir.mkdir(parents=True, exist_ok=True)

    environment_log = run_dir / "environment.log"
    packages_log = run_dir / "packages.log"
    hello_log = run_dir / "helloworld.log"
    pubsub_log = run_dir / "pubsub.log"
    action_log = run_dir / "action.log"

    result_json = (
        args.result_json.expanduser()
        if args.result_json
        else run_dir / "phase1_result.json"
    )
    phase_report = run_dir / "phase1_report.txt"

    checks: list[CheckResult] = []
    evidence_files: list[str] = []

    if args.dry_run:
        checks.extend(
            [
                CheckResult(
                    "PROGRAM_INTERFACE",
                    "PROGRAM INTERFACE",
                    Status.PASS,
                    "Dry-run interface completed",
                ),
                CheckResult(
                    "HARDWARE_EXECUTION",
                    "ROS EXECUTION",
                    Status.REVIEW,
                    "Dry run did not execute ROS commands",
                ),
                skipped("ROS_DISTRO", "ROS DISTRIBUTION", "Dry run"),
                skipped("UBUNTU", "UBUNTU VERSION", "Dry run"),
                skipped("PYTHON3", "PYTHON 3", "Dry run"),
                skipped("WORKSPACE", "ROS WORKSPACE", "Dry run"),
                skipped("PACKAGE_HELLO", "PACKAGE pkg_helloworld_py", "Dry run"),
                skipped("PACKAGE_TOPIC", "PACKAGE pkg_topic", "Dry run"),
                skipped("PACKAGE_ACTION", "PACKAGE pkg_action", "Dry run"),
                skipped("HELLOWORLD", "HELLO WORLD", "Dry run"),
                skipped("PUBSUB", "PUBLISHER / SUBSCRIBER", "Dry run"),
                skipped("ACTION", "ACTION SERVER / CLIENT", "Dry run"),
            ]
        )
    else:
        environment_checks = check_environment(workspace, environment_log)
        checks.extend(environment_checks)
        evidence_files.append(str(environment_log))

        workspace_ok = any(
            check.check_id == "WORKSPACE" and check.status == Status.PASS
            for check in checks
        )

        if workspace_ok:
            availability, package_checks = check_packages(workspace, packages_log)
            checks.extend(package_checks)
            evidence_files.append(str(packages_log))
        else:
            availability = {
                "pkg_helloworld_py": False,
                "pkg_topic": False,
                "pkg_action": False,
            }
            checks.extend(
                [
                    blocked(
                        "PACKAGE_PKG_HELLOWORLD_PY",
                        "PACKAGE pkg_helloworld_py",
                        "Workspace missing",
                    ),
                    blocked(
                        "PACKAGE_PKG_TOPIC",
                        "PACKAGE pkg_topic",
                        "Workspace missing",
                    ),
                    blocked(
                        "PACKAGE_PKG_ACTION",
                        "PACKAGE pkg_action",
                        "Workspace missing",
                    ),
                ]
            )

        if args.run_functional:
            if availability["pkg_helloworld_py"]:
                checks.append(check_helloworld(workspace, hello_log))
                evidence_files.append(str(hello_log))
            else:
                checks.append(
                    blocked(
                        "HELLOWORLD",
                        "HELLO WORLD",
                        "pkg_helloworld_py unavailable",
                    )
                )

            if availability["pkg_topic"]:
                checks.append(check_pubsub(workspace, pubsub_log))
                evidence_files.append(str(pubsub_log))
            else:
                checks.append(
                    blocked(
                        "PUBSUB",
                        "PUBLISHER / SUBSCRIBER",
                        "pkg_topic unavailable",
                    )
                )

            if availability["pkg_action"]:
                checks.append(check_action(workspace, action_log))
                evidence_files.append(str(action_log))
            else:
                checks.append(
                    blocked(
                        "ACTION",
                        "ACTION SERVER / CLIENT",
                        "pkg_action unavailable",
                    )
                )
        else:
            checks.extend(
                [
                    skipped("HELLOWORLD", "HELLO WORLD", "--run-functional not used"),
                    skipped(
                        "PUBSUB",
                        "PUBLISHER / SUBSCRIBER",
                        "--run-functional not used",
                    ),
                    skipped(
                        "ACTION",
                        "ACTION SERVER / CLIENT",
                        "--run-functional not used",
                    ),
                ]
            )

    result = PhaseResult(
        program=PROGRAM_NAME,
        version=PROGRAM_VERSION,
        phase_number=PHASE_NUMBER,
        phase_total=PHASE_TOTAL,
        phase_name=PHASE_NAME,
        robot_id=args.robot_id,
        started_at=started_at,
        ended_at=now_iso(),
        status=calculate_phase_status(checks),
        checks=checks,
        evidence_files=sorted(set(evidence_files)),
    )

    result_json.parent.mkdir(parents=True, exist_ok=True)
    result_json.write_text(
        json.dumps(phase_result_to_dict(result), indent=2, ensure_ascii=False)
        + "\n",
        encoding="utf-8",
    )

    phase_text = build_phase_text(result, include_raw_evidence=True)
    phase_report.write_text(phase_text, encoding="utf-8")

    if args.append_report:
        append_path = args.append_report.expanduser()
        append_path.parent.mkdir(parents=True, exist_ok=True)
        with append_path.open("a", encoding="utf-8") as shared_report:
            if append_path.stat().st_size > 0:
                shared_report.write("\n\n")
            shared_report.write(phase_text)

    return result, result_json, phase_report


def build_parser() -> argparse.ArgumentParser:
    """
    OBJECTIVE:
    Define the standalone and master-framework interface because Program 1 must
    operate predictably in both contexts.

    USER DEMAND:
    Run Phase 1 alone or through the unified program.

    AI-CONVERTED NEED:
    Expose robot, workspace, result paths, functional, dry-run and report-opening
    controls using the same conventions as Programs 2 and 3.

    REQUIREMENT CREATED:
    P1-FRAME-001.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-012.

    INPUTS:
    None.

    OUTPUTS:
    Configured ArgumentParser.

    WORKFLOW:
    IN => [interface requirements] -declare options/defaults-> [parser] => OUTPUT

    IMPROVEMENTS MADE:
    Added common master-supplied paths.

    REASON OF FAIL:
    Program 1 v1.1 lacked --result-json and --append-report.

    IMPROVEMENT:
    Added the common Phase CLI contract.
    """
    parser = argparse.ArgumentParser(
        description="Phase 1 ROS 2 quick checker with common master interface."
    )
    parser.add_argument("robot_id", help="Robot number, for example R23")
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path.home() / "ros2_ws",
        help="ROS 2 teaching workspace",
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path.home() / "robot_check_results",
    )
    parser.add_argument("--result-json", type=Path)
    parser.add_argument("--append-report", type=Path)
    parser.add_argument("--run-functional", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-open-report", action="store_true")
    parser.add_argument(
        "--no-open-log",
        action="store_true",
        help="Backward-compatible alias for --no-open-report",
    )
    return parser


def main() -> int:
    """
    OBJECTIVE:
    Provide a safe Phase 1 entry point because checker execution status and robot
    validation status must remain separate.

    USER DEMAND:
    Use Program 1 as the first step of the one-command suite.

    AI-CONVERTED NEED:
    Parse configuration, execute the phase, print artifact paths and optionally
    open the standalone report.

    REQUIREMENT CREATED:
    P1-FRAME-001, P1-RESULT-002.

    TECHNICAL DECISIONS:
    TD-P1-010, TD-P1-011, TD-P1-012.

    INPUTS:
    sys.argv.

    OUTPUTS:
    0 for completed checker execution, 1 for unexpected error and 130 for
    operator interruption.

    WORKFLOW:
    IN => [CLI] -parse/run-> [result artifacts] -print/open-> [exit code] => OUTPUT

    IMPROVEMENTS MADE:
    Added master-compatible execution semantics.

    REASON OF FAIL:
    Previous Program 1 exposed no machine-readable result.

    IMPROVEMENT:
    Checker completion is now separate from PASS/FAIL/REVIEW.
    """
    args = build_parser().parse_args()
    print(f"\n{CYAN}{PROGRAM_NAME} v{PROGRAM_VERSION}{RESET}")
    print(f"Robot: {args.robot_id}")
    print(f"Workspace: {args.workspace.expanduser()}")
    print("Standard-library-only build\n")

    try:
        result, result_json, phase_report = run_phase(args)
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return 130
    except Exception as exc:
        print(f"\nUnexpected Program 1 error: {exc}", file=sys.stderr)
        return 1

    print("\n" + build_phase_text(result, include_raw_evidence=False))
    print(f"JSON result: {result_json}")
    print(f"Phase report: {phase_report}")

    if not args.no_open_report and not args.no_open_log:
        open_report(phase_report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
